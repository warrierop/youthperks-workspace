import { getServerSession } from 'next-auth';
import { authOptions } from './auth';
import clientPromise from './mongodb';
import { User, Role, Permission } from '@/types';
import { ObjectId } from 'mongodb';

export async function getCurrentUser(): Promise<User | null> {
  const session = await getServerSession(authOptions);
  
  if (!session?.user?.id) {
    return null;
  }

  const client = await clientPromise;
  const users = client.db().collection('users');
  
  const user = await users.findOne({ email: session.user.email }) as any;
  
  return user as User | null;
}

export async function getUserPermissions(userId: string): Promise<Permission[]> {
  const client = await clientPromise;
  const users = client.db().collection('users');
  const roles = client.db().collection('roles');
  
  const user = await users.findOne({ _id: new ObjectId(userId) }) as any;
  
  if (!user) {
    return [];
  }
  
  const role = await roles.findOne({ name: user.role });
  
  return role?.permissions || [];
}

export async function hasPermission(
  userId: string,
  module: string,
  action: 'view' | 'create' | 'edit' | 'delete'
): Promise<boolean> {
  const permissions = await getUserPermissions(userId);
  
  const modulePermission = permissions.find(p => p.module === module);
  
  if (!modulePermission) {
    return false;
  }
  
  return modulePermission.actions.includes(action);
}

export async function canAccessData(
  userId: string,
  module: string,
  dataOwnerId?: string
): Promise<boolean> {
  const permissions = await getUserPermissions(userId);
  
  const modulePermission = permissions.find(p => p.module === module);
  
  if (!modulePermission) {
    return false;
  }
  
  switch (modulePermission.dataVisibility) {
    case 'all':
      return true;
    case 'team':
      // For simplicity, allow access to same role users
      const client = await clientPromise;
      const users = client.db().collection('users');
      const currentUser = await users.findOne({ _id: new ObjectId(userId) }) as any;
      const dataOwner = dataOwnerId ? await users.findOne({ _id: new ObjectId(dataOwnerId) }) as any : null;
      
      return currentUser?.role === dataOwner?.role;
    case 'own':
      return dataOwnerId === userId;
    default:
      return false;
  }
}

export function createAuthGuard(requiredPermission: {
  module: string;
  action: 'view' | 'create' | 'edit' | 'delete';
}) {
  return async function checkPermission() {
    const user = await getCurrentUser();
    
    if (!user) {
      throw new Error('Unauthorized');
    }
    
    const hasAccess = await hasPermission(
      (user as any)._id?.toString() || '',
      requiredPermission.module,
      requiredPermission.action
    );
    
    if (!hasAccess) {
      throw new Error('Forbidden');
    }
    
    return user;
  };
}
