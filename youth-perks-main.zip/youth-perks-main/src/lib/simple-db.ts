import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

const DB_PATH = path.join(process.cwd(), 'data');
const USERS_FILE = path.join(DB_PATH, 'users.json');
const ROLES_FILE = path.join(DB_PATH, 'roles.json');

// Ensure data directory exists
if (!fs.existsSync(DB_PATH)) {
  fs.mkdirSync(DB_PATH, { recursive: true });
}

// Simple file-based database for development
class SimpleDB {
  private readFile(filePath: string): any[] {
    try {
      if (!fs.existsSync(filePath)) {
        return [];
      }
      const data = fs.readFileSync(filePath, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      console.error(`Error reading file ${filePath}:`, error);
      return [];
    }
  }

  private writeFile(filePath: string, data: any[]): void {
    try {
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    } catch (error) {
      console.error(`Error writing file ${filePath}:`, error);
    }
  }

  async seedDatabase() {
    console.log('Seeding simple file-based database...');
    
    // Seed roles
    const defaultRoles = [
      {
        _id: 'super-admin',
        name: 'Super Admin',
        permissions: {
          tasks: { view: true, create: true, edit: true, delete: true },
          documents: { view: true, create: true, edit: true, delete: true },
          users: { view: true, create: true, edit: true, delete: true },
          budget: { view: true, create: true, edit: true, delete: true },
          brands: { view: true, create: true, edit: true, delete: true },
          announcements: { view: true, create: true, edit: true, delete: true },
          reports: { view: true, create: true, edit: true, delete: true },
          polls: { view: true, create: true, edit: true, delete: true },
          ideas: { view: true, create: true, edit: true, delete: true },
        },
        dataVisibility: 'all',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        _id: 'admin',
        name: 'Admin',
        permissions: {
          tasks: { view: true, create: true, edit: true, delete: false },
          documents: { view: true, create: true, edit: true, delete: false },
          users: { view: true, create: true, edit: true, delete: false },
          budget: { view: true, create: true, edit: true, delete: false },
          brands: { view: true, create: true, edit: true, delete: false },
          announcements: { view: true, create: true, edit: true, delete: false },
          reports: { view: true, create: true, edit: true, delete: false },
          polls: { view: true, create: true, edit: true, delete: false },
          ideas: { view: true, create: true, edit: true, delete: false },
        },
        dataVisibility: 'all',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        _id: 'executive',
        name: 'Executive',
        permissions: {
          tasks: { view: true, create: true, edit: true, delete: false },
          documents: { view: true, create: true, edit: true, delete: false },
          users: { view: true, create: false, edit: false, delete: false },
          budget: { view: true, create: false, edit: true, delete: false },
          brands: { view: true, create: true, edit: true, delete: false },
          announcements: { view: true, create: false, edit: false, delete: false },
          reports: { view: true, create: true, edit: true, delete: false },
          polls: { view: true, create: true, edit: true, delete: false },
          ideas: { view: true, create: true, edit: true, delete: false },
        },
        dataVisibility: 'team',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        _id: 'staff',
        name: 'Staff',
        permissions: {
          tasks: { view: true, create: false, edit: false, delete: false },
          documents: { view: true, create: false, edit: false, delete: false },
          users: { view: false, create: false, edit: false, delete: false },
          budget: { view: false, create: false, edit: false, delete: false },
          brands: { view: false, create: false, edit: false, delete: false },
          announcements: { view: true, create: false, edit: false, delete: false },
          reports: { view: true, create: true, edit: false, delete: false },
          polls: { view: true, create: false, edit: false, delete: false },
          ideas: { view: true, create: true, edit: false, delete: false },
        },
        dataVisibility: 'own',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    this.writeFile(ROLES_FILE, defaultRoles);

    // Seed Super Admin user
    const hashedPassword = await bcrypt.hash('1234Aa5678mc', 12);
    
    const superAdminUser = {
      _id: 'super-admin-user',
      email: 'abcsuperyouthperks@youthperks.com',
      password: hashedPassword,
      name: 'Super Admin',
      role: 'Super Admin',
      rank: 'Founder',
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const existingUsers = this.readFile(USERS_FILE);
    const userExists = existingUsers.some((user: any) => user.email === superAdminUser.email);
    
    if (!userExists) {
      existingUsers.push(superAdminUser);
      this.writeFile(USERS_FILE, existingUsers);
    }

    console.log('✅ Database seeded successfully!');
  }

  // User operations
  async findUserByEmail(email: string) {
    const users = this.readFile(USERS_FILE);
    return users.find((user: any) => user.email === email);
  }

  async findUserById(id: string) {
    const users = this.readFile(USERS_FILE);
    return users.find((user: any) => user._id === id);
  }

  // Role operations
  async findRoleByName(name: string) {
    const roles = this.readFile(ROLES_FILE);
    return roles.find((role: any) => role.name === name);
  }

  async getAllUsers() {
    const users = this.readFile(USERS_FILE);
    return users.map((user: any) => {
      const { password, ...userWithoutPassword } = user;
      return userWithoutPassword;
    });
  }

  async getAllRoles() {
    return this.readFile(ROLES_FILE);
  }
}

export const simpleDB = new SimpleDB();
