// Centralized API client for all backend interactions
const getBaseUrl = () => {
  return process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';
};

const getAuthHeaders = () => {
  const token = localStorage.getItem('token');
  return {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
  };
};

export const api = {
  // Auth endpoints
  login: (credentials: { email: string; password: string }) =>
    fetch(`${getBaseUrl()}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials),
    }),

  getProfile: () =>
    fetch(`${getBaseUrl()}/api/users/me`, {
      headers: getAuthHeaders(),
    }),

  // User endpoints
  getUsers: () =>
    fetch(`${getBaseUrl()}/api/users`, {
      headers: getAuthHeaders(),
    }),

  createUser: (userData: any) =>
    fetch(`${getBaseUrl()}/api/users`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(userData),
    }),

  updateUser: (id: string, userData: any) =>
    fetch(`${getBaseUrl()}/api/users/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(userData),
    }),

  toggleUserStatus: (id: string) =>
    fetch(`${getBaseUrl()}/api/users/${id}/toggle-status`, {
      method: 'PUT',
      headers: getAuthHeaders(),
    }),

  updateUserPermissions: (id: string, permissions: any) =>
    fetch(`${getBaseUrl()}/api/users/${id}/permissions`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ permissions }),
    }),

  resetUserPermissions: (id: string) =>
    fetch(`${getBaseUrl()}/api/users/${id}/reset-permissions`, {
      method: 'PUT',
      headers: getAuthHeaders(),
    }),

  deleteUser: (id: string) =>
    fetch(`${getBaseUrl()}/api/users/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    }),

  // Task endpoints
  getTasks: () =>
    fetch(`${getBaseUrl()}/api/tasks`, {
      headers: getAuthHeaders(),
    }),

  createTask: (taskData: any) =>
    fetch(`${getBaseUrl()}/api/tasks`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(taskData),
    }),

  updateTask: (id: string, taskData: any) =>
    fetch(`${getBaseUrl()}/api/tasks/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(taskData),
    }),

  deleteTask: (id: string) =>
    fetch(`${getBaseUrl()}/api/tasks/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    }),

  // Document endpoints
  getDocuments: () =>
    fetch(`${getBaseUrl()}/api/documents`, {
      headers: getAuthHeaders(),
    }),

  createDocument: (formData: FormData) =>
    fetch(`${getBaseUrl()}/api/documents`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
      body: formData,
    }),

  deleteDocument: (id: string) =>
    fetch(`${getBaseUrl()}/api/documents/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    }),

  downloadDocument: (id: string) =>
    `${getBaseUrl()}/api/documents/download/${id}?token=${localStorage.getItem('token')}`,

  // Announcement endpoints
  getAnnouncements: () =>
    fetch(`${getBaseUrl()}/api/announcements`, {
      headers: getAuthHeaders(),
    }),

  createAnnouncement: (data: any) =>
    fetch(`${getBaseUrl()}/api/announcements`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),

  updateAnnouncement: (id: string, data: any) =>
    fetch(`${getBaseUrl()}/api/announcements/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),

  toggleAnnouncement: (id: string) =>
    fetch(`${getBaseUrl()}/api/announcements/${id}/toggle`, {
      method: 'PUT',
      headers: getAuthHeaders(),
    }),

  deleteAnnouncement: (id: string) =>
    fetch(`${getBaseUrl()}/api/announcements/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    }),

  // Brand endpoints
  getBrands: () =>
    fetch(`${getBaseUrl()}/api/brands`, {
      headers: getAuthHeaders(),
    }),

  createBrand: (data: any) =>
    fetch(`${getBaseUrl()}/api/brands`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),

  updateBrand: (id: string, data: any) =>
    fetch(`${getBaseUrl()}/api/brands/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),

  deleteBrand: (id: string) =>
    fetch(`${getBaseUrl()}/api/brands/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    }),

  toggleBrandFollowUp: (id: string) =>
    fetch(`${getBaseUrl()}/api/brands/${id}/followup`, {
      method: 'PUT',
      headers: getAuthHeaders(),
    }),

  // Budget endpoints
  getBudget: () =>
    fetch(`${getBaseUrl()}/api/budget`, {
      headers: getAuthHeaders(),
    }),

  createBudget: (data: any) =>
    fetch(`${getBaseUrl()}/api/budget`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),

  updateBudget: (id: string, data: any) =>
    fetch(`${getBaseUrl()}/api/budget/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),

  deleteBudget: (id: string) =>
    fetch(`${getBaseUrl()}/api/budget/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    }),

  // Poll endpoints
  getPolls: () =>
    fetch(`${getBaseUrl()}/api/polls`, {
      headers: getAuthHeaders(),
    }),

  createPoll: (data: any) =>
    fetch(`${getBaseUrl()}/api/polls`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),

  updatePoll: (id: string, data: any) =>
    fetch(`${getBaseUrl()}/api/polls/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),

  deletePoll: (id: string) =>
    fetch(`${getBaseUrl()}/api/polls/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    }),

  votePoll: (id: string, option: string) =>
    fetch(`${getBaseUrl()}/api/polls/${id}/vote`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ option }),
    }),

  // Report endpoints
  getReports: () =>
    fetch(`${getBaseUrl()}/api/reports`, {
      headers: getAuthHeaders(),
    }),

  createReport: (data: any) =>
    fetch(`${getBaseUrl()}/api/reports`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),

  updateReport: (id: string, data: any) =>
    fetch(`${getBaseUrl()}/api/reports/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),

  submitReport: (id: string) =>
    fetch(`${getBaseUrl()}/api/reports/${id}/submit`, {
      method: 'POST',
      headers: getAuthHeaders(),
    }),

  reviewReport: (id: string, data: any) =>
    fetch(`${getBaseUrl()}/api/reports/${id}/review`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),

  deleteReport: (id: string) =>
    fetch(`${getBaseUrl()}/api/reports/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    }),

  exportReport: () =>
    `${getBaseUrl()}/api/reports/export?token=${localStorage.getItem('token')}`,

  downloadReportAttachment: (reportId: string, attachmentId: string) =>
    `${getBaseUrl()}/api/reports/attachment/${reportId}/${attachmentId}?token=${localStorage.getItem('token')}`,

  // Dashboard / metrics endpoint
  getMetrics: () =>
    fetch(`${getBaseUrl()}/api/dashboard`, {
      headers: getAuthHeaders(),
    }),

  // Ideas endpoints
  getIdeas: () =>
    fetch(`${getBaseUrl()}/api/ideas`, {
      headers: getAuthHeaders(),
    }),

  createIdea: (data: any) =>
    fetch(`${getBaseUrl()}/api/ideas`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),

  toggleIdeaReaction: (id: string) =>
    fetch(`${getBaseUrl()}/api/ideas/${id}/reaction`, {
      method: 'POST',
      headers: getAuthHeaders(),
    }),

  createIdeaComment: (id: string, comment: string) =>
    fetch(`${getBaseUrl()}/api/ideas/${id}/comment`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ comment }),
    }),

  deleteIdea: (id: string) =>
    fetch(`${getBaseUrl()}/api/ideas/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    }),
};