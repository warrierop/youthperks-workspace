import clientPromise from './mongodb';
import bcrypt from 'bcryptjs';
import { User, Role, Permission } from '@/types';

export async function seedDatabase() {
  const client = await clientPromise;
  const db = client.db();

  // Clear existing data
  await db.collection('users').deleteMany({});
  await db.collection('roles').deleteMany({});

  // Create default roles with permissions
  const defaultRoles: Role[] = [
    {
      name: 'Super Admin',
      permissions: [
        { module: 'users', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'all' },
        { module: 'roles', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'all' },
        { module: 'tasks', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'all' },
        { module: 'documents', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'all' },
        { module: 'budgets', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'all' },
        { module: 'brands', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'all' },
        { module: 'reports', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'all' },
        { module: 'announcements', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'all' },
        { module: 'polls', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'all' },
        { module: 'notifications', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'all' },
        { module: 'ideas', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'all' },
      ],
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      name: 'Admin',
      permissions: [
        { module: 'users', actions: ['view', 'create', 'edit'], dataVisibility: 'team' },
        { module: 'tasks', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'team' },
        { module: 'documents', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'team' },
        { module: 'budgets', actions: ['view', 'create', 'edit'], dataVisibility: 'team' },
        { module: 'brands', actions: ['view', 'create', 'edit', 'delete'], dataVisibility: 'team' },
        { module: 'reports', actions: ['view', 'create', 'edit'], dataVisibility: 'team' },
        { module: 'announcements', actions: ['view', 'create', 'edit'], dataVisibility: 'team' },
        { module: 'polls', actions: ['view', 'create', 'edit'], dataVisibility: 'team' },
        { module: 'notifications', actions: ['view', 'create'], dataVisibility: 'team' },
        { module: 'ideas', actions: ['view', 'create', 'edit'], dataVisibility: 'team' },
      ],
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      name: 'Executive',
      permissions: [
        { module: 'users', actions: ['view'], dataVisibility: 'team' },
        { module: 'tasks', actions: ['view', 'create', 'edit'], dataVisibility: 'team' },
        { module: 'documents', actions: ['view', 'create', 'edit'], dataVisibility: 'team' },
        { module: 'budgets', actions: ['view'], dataVisibility: 'team' },
        { module: 'brands', actions: ['view', 'create', 'edit'], dataVisibility: 'team' },
        { module: 'reports', actions: ['view', 'create', 'edit'], dataVisibility: 'team' },
        { module: 'announcements', actions: ['view', 'create'], dataVisibility: 'team' },
        { module: 'polls', actions: ['view', 'create'], dataVisibility: 'team' },
        { module: 'notifications', actions: ['view'], dataVisibility: 'team' },
        { module: 'ideas', actions: ['view', 'create'], dataVisibility: 'team' },
      ],
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      name: 'Staff',
      permissions: [
        { module: 'tasks', actions: ['view'], dataVisibility: 'own' },
        { module: 'documents', actions: ['view'], dataVisibility: 'own' },
        { module: 'reports', actions: ['view', 'create'], dataVisibility: 'own' },
        { module: 'announcements', actions: ['view'], dataVisibility: 'own' },
        { module: 'polls', actions: ['view'], dataVisibility: 'own' },
        { module: 'notifications', actions: ['view'], dataVisibility: 'own' },
        { module: 'ideas', actions: ['view', 'create'], dataVisibility: 'team' },
      ],
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];

  // Insert roles
  const insertedRoles = await db.collection('roles').insertMany(defaultRoles);

  // Create Super Admin user
  const hashedPassword = await bcrypt.hash('1234Aa5678mc', 12);
  
  const superAdminUser = {
    email: 'abcsuperyouthperks@youthperks.com',
    password: hashedPassword,
    name: 'Super Admin',
    role: 'Super Admin',
    rank: 'Founder',
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  await db.collection('users').insertOne(superAdminUser);

  console.log('Database seeded successfully!');
  console.log('Super Admin login: abcsuperyouthperks@youthperks.com');
  console.log('Password: 1234Aa5678mc');
}

// Run seed if called directly
if (require.main === module) {
  seedDatabase().catch(console.error);
}
