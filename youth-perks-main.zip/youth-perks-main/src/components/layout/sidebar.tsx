'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/hooks/useAuth';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard, CheckSquare, FileText, Users, DollarSign,
  Handshake, FileBarChart, Megaphone, MessageSquare, Lightbulb, Settings,
  Briefcase, TrendingUp, X, ChevronDown
} from 'lucide-react';
import { useState } from 'react';

const allNavigation = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard, page: 'dashboard' },
  { name: 'Tasks', href: '/tasks', icon: CheckSquare, page: 'tasks' },
  { name: 'Documents', href: '/documents', icon: FileText, page: 'documents' },
  { name: 'Team', href: '/team', icon: Users, page: 'team' },
  { name: 'Budget', href: '/budget', icon: DollarSign, page: 'budget' },
  { name: 'Reports', href: '/reports', icon: FileBarChart, page: 'reports' },
  { name: 'Polls', href: '/polls', icon: MessageSquare, page: 'polls' },
  { name: 'Announcements', href: '/announcements', icon: Megaphone, page: 'announcements' },
  { name: 'Ideas', href: '/ideas', icon: Lightbulb, page: 'ideas' },
  { name: 'Settings', href: '/settings', icon: Settings, page: 'settings' },
];

const crmNavigation = [
  { name: 'Pipeline', href: '/brands', icon: TrendingUp, page: 'brands' },
  { name: 'Clients', href: '/clients', icon: Briefcase, page: 'clients' },
  { name: 'Campaigns', href: '/campaigns', icon: Megaphone, page: 'campaigns' },
];

interface SidebarProps {
  onClose?: () => void;
}

export function Sidebar({ onClose }: SidebarProps) {
  const pathname = usePathname();
  const { user, canView } = useAuth();
  const [crmOpen, setCrmOpen] = useState(true);

  const navigation = allNavigation.filter(item => canView(item.page));
  const crmItems = crmNavigation.filter(item => canView(item.page));

  const handleNavigation = (href: string) => {
    if (onClose) onClose();
  };

  return (
    <div className="flex h-screen flex-col bg-gray-900">
      {/* Brand Header - Fixed at top */}
      <div className="flex h-16 shrink-0 items-center justify-between px-4 border-b border-gray-800">
        <Link href="/dashboard" onClick={() => onClose?.()} className="flex items-center gap-2.5">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
            <span className="text-white font-bold text-sm">YP</span>
          </div>
          <span className="text-lg font-bold text-white">YouthPerks</span>
        </Link>
        <button
          onClick={onClose}
          className="lg:hidden p-1.5 hover:bg-gray-800 rounded-lg text-gray-400 hover:text-white transition-colors"
          aria-label="Close sidebar"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Scrollable Navigation - Takes remaining space */}
      <nav className="flex-1 overflow-y-auto py-4 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent">
        <ul role="list" className="flex flex-col gap-y-1 px-3">
          {navigation.map((item) => {
            const isActive = pathname === item.href || pathname?.startsWith(item.href + '/');
            return (
              <li key={item.name}>
                <Link
                  href={item.href}
                  onClick={() => handleNavigation(item.href)}
                  className={cn(
                    isActive
                      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800',
                    'group flex gap-x-3 rounded-lg p-2.5 text-sm leading-6 font-semibold transition-all'
                  )}
                >
                  <item.icon
                    className={cn(
                      isActive ? 'text-white' : 'text-gray-400 group-hover:text-white',
                      'h-5 w-5 shrink-0 transition-colors'
                    )}
                    aria-hidden="true"
                  />
                  {item.name}
                </Link>
              </li>
            );
          })}

          {/* CRM Section */}
          {crmItems.length > 0 && (
            <li className="mt-2">
              <button
                onClick={() => setCrmOpen(!crmOpen)}
                className="w-full flex items-center justify-between px-2 py-1.5 text-xs font-bold text-gray-500 uppercase tracking-wider hover:text-gray-300 transition-colors"
              >
                <span>CRM</span>
                <ChevronDown
                  className={cn(
                    'h-3.5 w-3.5 transition-transform duration-200',
                    crmOpen ? 'rotate-0' : '-rotate-90'
                  )}
                />
              </button>

              {crmOpen && (
                <ul className="mt-1 space-y-1">
                  {crmItems.map((item) => {
                    const isActive = pathname === item.href || pathname?.startsWith(item.href + '/');
                    return (
                      <li key={item.name}>
                        <Link
                          href={item.href}
                          onClick={() => handleNavigation(item.href)}
                          className={cn(
                            isActive
                              ? 'bg-indigo-600/80 text-white shadow-lg shadow-indigo-600/10'
                              : 'text-gray-400 hover:text-white hover:bg-gray-800',
                            'group flex gap-x-3 rounded-lg py-2 pl-4 pr-3 text-sm leading-6 font-medium transition-all'
                          )}
                        >
                          <item.icon
                            className={cn(
                              isActive ? 'text-white' : 'text-gray-400 group-hover:text-white',
                              'h-4.5 w-4.5 shrink-0 transition-colors'
                            )}
                            aria-hidden="true"
                          />
                          {item.name}
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              )}
            </li>
          )}
        </ul>
      </nav>

      {/* User Info - Fixed at bottom */}
      {user && (
        <div className="shrink-0 p-4 border-t border-gray-800">
          <p className="text-sm font-medium text-gray-300 truncate">{user.name || user.email}</p>
          <p className="text-xs text-gray-500 capitalize">{user.role?.replace(/_/g, ' ')}</p>
        </div>
      )}
    </div>
  );
}