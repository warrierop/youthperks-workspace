'use client';

import { useAuth } from '@/hooks/useAuth';
import { useRouter } from 'next/navigation';
import { LogOut, Bell, Settings } from 'lucide-react';
import { NotificationBell } from '../notifications/NotificationBell';

export function Header() {
  const { user, logout } = useAuth();
  const router = useRouter();

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    router.push('/login');
  };

  return (
    <header className="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-6 shrink-0">
      <div>
        <p className="text-sm text-gray-500">Welcome back,</p>
        <p className="text-sm font-semibold text-gray-900">{user?.name || 'User'}</p>
      </div>
      <div className="flex items-center gap-3">
        {/* <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-500"> */}
          <NotificationBell />
        {/* </button> */}
        <button
          onClick={() => router.push('/settings')}
          className="p-2 hover:bg-gray-100 rounded-lg text-gray-500"
        >
          <Settings className="h-5 w-5" />
        </button>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors"
        >
          <LogOut className="h-4 w-4" />
          Sign out
        </button>
      </div>
    </header>
  );
}