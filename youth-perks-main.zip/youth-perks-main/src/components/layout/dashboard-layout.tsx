'use client';

import { useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import { Sidebar } from './sidebar';
import { Header } from './header';
import { Menu, LogOut, Building2, Sparkles } from 'lucide-react';

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const router = useRouter();

  const isClient = user?.role === 'client';

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');

    if (!token) {
      router.push('/login');
      return;
    }

    try {
      if (userData) {
        const parsed = JSON.parse(userData);
        setUser(parsed);

        if (parsed.role === 'client') {
          const clientId = parsed.assignedClientId;
          if (clientId && !window.location.pathname.startsWith('/clients/')) {
            router.push(`/clients/${clientId}`);
          }
        }
      }
    } catch (e) {
      console.error('Failed to parse user data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    function handleResize() {
      if (window.innerWidth >= 1024) setIsSidebarOpen(false);
    }
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-600 border-t-transparent" />
      </div>
    );
  }

  if (!user) return null;

  // ==========================================
  // CLIENT LAYOUT - Clean, no sidebar
  // ==========================================
  if (isClient) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Client Header */}
        <header className="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-6 shadow-sm shrink-0">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-sm">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-bold text-gray-900">YouthPerks</p>
              <p className="text-xs text-gray-500">Brand Portal • {user?.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs font-medium text-gray-400 bg-gray-100 px-2.5 py-1 rounded-full capitalize">
              {user?.role?.replace(/_/g, ' ')}
            </span>
            <button
              onClick={() => {
                localStorage.removeItem('token');
                localStorage.removeItem('user');
                router.push('/login');
              }}
              className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            >
              <LogOut className="h-4 w-4" /> Sign out
            </button>
          </div>
        </header>

        {/* Client Content - Scrollable */}
        <main className="flex-1 overflow-y-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {children}
          </div>
        </main>
      </div>
    );
  }

  // ==========================================
  // ADMIN/STAFF LAYOUT - Fixed sidebar, scrollable content
  // ==========================================
  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Mobile backdrop */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/40 z-40 lg:hidden backdrop-blur-sm" 
          onClick={() => setIsSidebarOpen(false)} 
        />
      )}

      <div className="flex h-full overflow-hidden">
        {/* Sidebar - Fixed position, independent scroll */}
        <div
          className={`fixed inset-y-0 left-0 z-50 w-64 lg:static lg:z-0 transform transition-transform duration-300 ease-in-out ${
            isSidebarOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full lg:translate-x-0'
          }`}
        >
          <Sidebar onClose={() => setIsSidebarOpen(false)} />
        </div>

        {/* Main content area - Scrollable */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          {/* Mobile header */}
          <header className="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-4 lg:hidden shrink-0 shadow-sm">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <Menu className="h-5 w-5 text-gray-600" />
            </button>
            <p className="text-sm font-semibold text-gray-900 truncate max-w-[180px]">
              {user?.name || 'User'}
            </p>
          </header>

          {/* Desktop header */}
          <header className="hidden lg:block bg-white border-b border-gray-200 shrink-0 shadow-sm">
            <Header />
          </header>

          {/* Scrollable content area */}
          <main className="flex-1 overflow-y-auto">
            <div className="p-4 lg:p-6">
              {children}
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}