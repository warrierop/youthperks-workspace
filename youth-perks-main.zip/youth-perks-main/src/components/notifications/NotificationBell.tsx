'use client';

import { useState, useEffect, useRef } from 'react';
import { Bell, CheckCheck, Trash2, X, Settings, CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import { useRouter } from 'next/navigation';

interface Notification {
  _id: string;
  type: string;
  title: string;
  message: string;
  link: string;
  isRead: boolean;
  priority: string;
  createdAt: string;
  sender?: { name: string; avatar?: string };
}

export function NotificationBell() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showDropdown, setShowDropdown] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'unread'>('all');
  const dropdownRef = useRef<HTMLDivElement>(null);
  const router = useRouter();
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

  useEffect(() => {
    fetchUnreadCount();
    fetchNotifications();

    const interval = setInterval(() => {
      fetchUnreadCount();
    }, 30000);

    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      clearInterval(interval);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
  };

  const fetchUnreadCount = async () => {
    try {
      const res = await fetch(`${API_URL}/api/notifications/unread-count`, { headers: getAuthHeaders() });
      if (res.ok) {
        const data = await res.json();
        setUnreadCount(data.count);
      }
    } catch (e) { /* silent */ }
  };

  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_URL}/api/notifications?limit=30`, { headers: getAuthHeaders() });
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications);
      }
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const markAsRead = async (id: string) => {
    try {
      await fetch(`${API_URL}/api/notifications/${id}/read`, {
        method: 'PUT',
        headers: getAuthHeaders(),
      });
      setNotifications(prev => prev.map(n => n._id === id ? { ...n, isRead: true } : n));
      fetchUnreadCount();
    } catch (e) { /* silent */ }
  };

  const markAllAsRead = async () => {
    try {
      await fetch(`${API_URL}/api/notifications/read-all`, {
        method: 'PUT',
        headers: getAuthHeaders(),
      });
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
      setUnreadCount(0);
    } catch (e) { /* silent */ }
  };

  const deleteNotification = async (id: string) => {
    try {
      await fetch(`${API_URL}/api/notifications/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });
      setNotifications(prev => prev.filter(n => n._id !== id));
      fetchUnreadCount();
    } catch (e) { /* silent */ }
  };

  const clearAll = async () => {
    if (!confirm('Clear all notifications permanently?')) return;
    try {
      await fetch(`${API_URL}/api/notifications/clear-all`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });
      setNotifications([]);
      setUnreadCount(0);
    } catch (e) { /* silent */ }
  };

  const handleNotificationClick = (notification: Notification) => {
    markAsRead(notification._id);
    if (notification.link) {
      router.push(notification.link);
      setShowDropdown(false);
    }
  };

  const getTimeAgo = (date: string) => {
    const seconds = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
    if (seconds < 60) return 'Just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
    return new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const getNotificationTypeInfo = (type: string) => {
    const types: Record<string, { icon: any; color: string; bg: string; label: string }> = {
      task_assigned: { icon: Clock, color: 'text-blue-600', bg: 'bg-blue-50', label: 'Task' },
      task_completed: { icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50', label: 'Task' },
      task_due_soon: { icon: AlertCircle, color: 'text-amber-600', bg: 'bg-amber-50', label: 'Task' },
      task_overdue: { icon: AlertCircle, color: 'text-red-600', bg: 'bg-red-50', label: 'Task' },
      report_submitted: { icon: CheckCircle2, color: 'text-blue-600', bg: 'bg-blue-50', label: 'Report' },
      report_reviewed: { icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50', label: 'Report' },
      report_changes_requested: { icon: AlertCircle, color: 'text-amber-600', bg: 'bg-amber-50', label: 'Report' },
      document_uploaded: { icon: CheckCircle2, color: 'text-purple-600', bg: 'bg-purple-50', label: 'Document' },
      document_shared: { icon: CheckCircle2, color: 'text-indigo-600', bg: 'bg-indigo-50', label: 'Document' },
      brand_followup_due: { icon: Clock, color: 'text-orange-600', bg: 'bg-orange-50', label: 'Brand' },
      announcement_created: { icon: CheckCircle2, color: 'text-cyan-600', bg: 'bg-cyan-50', label: 'Announcement' },
      poll_created: { icon: CheckCircle2, color: 'text-violet-600', bg: 'bg-violet-50', label: 'Poll' },
      idea_comment: { icon: CheckCircle2, color: 'text-pink-600', bg: 'bg-pink-50', label: 'Idea' },
      followup_due: { icon: Clock, color: 'text-rose-600', bg: 'bg-rose-50', label: 'Follow-up' },
      system: { icon: Settings, color: 'text-gray-600', bg: 'bg-gray-50', label: 'System' },
    };
    return types[type] || { icon: Bell, color: 'text-gray-500', bg: 'bg-gray-50', label: 'Update' };
  };

  const getPriorityStyles = (priority: string) => {
    switch (priority) {
      case 'high': return 'border-l-red-400';
      case 'medium': return 'border-l-amber-400';
      default: return 'border-l-gray-200';
    }
  };

  const filteredNotifications = activeTab === 'unread' 
    ? notifications.filter(n => !n.isRead) 
    : notifications;

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Bell Button */}
      <button
        onClick={() => { 
          setShowDropdown(!showDropdown); 
          if (!showDropdown) {
            fetchNotifications();
            setActiveTab('all');
          }
        }}
        className="relative p-2 hover:bg-gray-100 rounded-xl transition-all duration-200 active:scale-95"
      >
        <Bell className="h-5 w-5 text-gray-500 hover:text-gray-700 transition-colors" />
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 min-w-[20px] h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-sm px-1">
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown */}
      {showDropdown && (
        <div className="absolute right-0 mt-2 w-[420px] bg-white rounded-2xl shadow-xl border border-gray-200 z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
          
          {/* Header */}
          <div className="px-5 py-3.5 border-b border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-base font-bold text-gray-900">Notifications</h3>
                {unreadCount > 0 && (
                  <p className="text-xs text-gray-500 mt-0.5">{unreadCount} unread</p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={markAllAsRead}
                  className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold hover:bg-indigo-50 px-2.5 py-1.5 rounded-lg transition-colors"
                >
                  Mark all read
                </button>
                <button 
                  onClick={clearAll}
                  className="text-xs text-gray-400 hover:text-red-600 font-medium hover:bg-red-50 px-2.5 py-1.5 rounded-lg transition-colors"
                >
                  Clear all
                </button>
              </div>
            </div>
            
            {/* Tabs */}
            <div className="flex bg-gray-100 rounded-lg p-0.5">
              <button
                onClick={() => setActiveTab('all')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-all ${
                  activeTab === 'all' 
                    ? 'bg-white text-gray-900 shadow-sm' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setActiveTab('unread')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-all ${
                  activeTab === 'unread' 
                    ? 'bg-white text-gray-900 shadow-sm' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Unread {unreadCount > 0 && `(${unreadCount})`}
              </button>
            </div>
          </div>

          {/* List */}
          <div className="max-h-[420px] overflow-y-auto">
            {loading ? (
              <div className="flex flex-col items-center justify-center py-16 gap-3">
                <div className="animate-spin rounded-full h-7 w-7 border-2 border-indigo-600 border-t-transparent" />
                <p className="text-sm text-gray-400 font-medium">Loading notifications...</p>
              </div>
            ) : filteredNotifications.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 px-8">
                <div className="h-16 w-16 rounded-2xl bg-gray-100 flex items-center justify-center mb-4">
                  <Bell className="h-7 w-7 text-gray-300" />
                </div>
                <h4 className="text-sm font-semibold text-gray-900 mb-1">
                  {activeTab === 'unread' ? 'No unread notifications' : 'All caught up!'}
                </h4>
                <p className="text-xs text-gray-500 text-center">
                  {activeTab === 'unread' 
                    ? 'You\'ve read all your notifications.' 
                    : 'Notifications from your team will appear here.'}
                </p>
              </div>
            ) : (
              <div className="divide-y divide-gray-50">
                {filteredNotifications.map((notification) => {
                  const typeInfo = getNotificationTypeInfo(notification.type);
                  const TypeIcon = typeInfo.icon;
                  
                  return (
                    <div
                      key={notification._id}
                      className={`group relative pl-4 pr-5 py-3.5 border-l-4 ${getPriorityStyles(notification.priority)} hover:bg-gray-50/80 cursor-pointer transition-all duration-150 ${
                        !notification.isRead ? 'bg-indigo-50/20' : ''
                      }`}
                    >
                      <div className="flex items-start gap-3" onClick={() => handleNotificationClick(notification)}>
                        {/* Icon */}
                        <div className={`shrink-0 h-9 w-9 rounded-xl ${typeInfo.bg} flex items-center justify-center`}>
                          <TypeIcon className={`h-4.5 w-4.5 ${typeInfo.color}`} />
                        </div>
                        
                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 mb-0.5">
                                <span className={`text-[10px] font-bold uppercase tracking-wider ${typeInfo.color}`}>
                                  {typeInfo.label}
                                </span>
                                {!notification.isRead && (
                                  <span className="h-1.5 w-1.5 rounded-full bg-indigo-500 shrink-0" />
                                )}
                              </div>
                              <p className={`text-sm leading-snug text-gray-900 line-clamp-2 ${
                                !notification.isRead ? 'font-semibold' : 'font-medium'
                              }`}>
                                {notification.title}
                              </p>
                              {notification.message && (
                                <p className="text-xs text-gray-500 mt-0.5 line-clamp-1">
                                  {notification.message}
                                </p>
                              )}
                            </div>
                            
                            {/* Delete button */}
                            <button
                              onClick={(e) => { 
                                e.stopPropagation(); 
                                deleteNotification(notification._id); 
                              }}
                              className="shrink-0 p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg opacity-0 group-hover:opacity-100 transition-all"
                            >
                              <X className="h-3.5 w-3.5" />
                            </button>
                          </div>
                          
                          {/* Footer */}
                          <div className="flex items-center gap-2 mt-1.5">
                            <span className="text-[10px] text-gray-400 font-medium">
                              {getTimeAgo(notification.createdAt)}
                            </span>
                            {notification.sender?.name && (
                              <>
                                <span className="text-gray-200">·</span>
                                <span className="text-[10px] text-gray-400 font-medium">
                                  {notification.sender.name}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Footer */}
          {notifications.length > 0 && (
            <div className="px-5 py-3 border-t border-gray-100 bg-gray-50/50">
              <button
                onClick={() => {
                  setShowDropdown(false);
                  router.push('/notifications');
                }}
                className="w-full text-center text-xs font-semibold text-indigo-600 hover:text-indigo-800 py-1.5 rounded-lg hover:bg-indigo-50 transition-colors"
              >
                View all notifications
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}