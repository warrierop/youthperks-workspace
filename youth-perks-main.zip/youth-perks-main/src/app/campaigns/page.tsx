'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { ProtectedPage } from '@/components/auth/ProtectedPage';
import { useAuth } from '@/hooks/useAuth';
import {
  Plus, Search, Megaphone, Calendar, DollarSign, TrendingUp,
  Edit, Trash2, X, Users, Target, Flag, Filter, ChevronRight,
  Clock, CheckCircle2, AlertCircle, PauseCircle, PlayCircle,
  BarChart3, Link, Building2, Sparkles, Gift, GraduationCap,
  Smartphone, Handshake, Palette, ClipboardList, ArrowUpRight
} from 'lucide-react';

interface Deliverable {
  _id: string;
  title: string;
  description: string;
  status: string;
  dueDate?: string;
  completedAt?: string;
}

interface Campaign {
  _id: string;
  name: string;
  description: string;
  type: string;
  brands: { _id: string; brandName: string; logo: string; status: string }[];
  clientBrands: { _id: string; brandName: string; logo: string; partnerType: string }[];
  startDate: string;
  endDate: string;
  budget: { allocated: number; spent: number };
  budgetRemaining: number;
  budgetUsagePercent: number;
  expectedROI: number;
  actualROI: number;
  status: string;
  priority: string;
  deliverables: Deliverable[];
  teamMembers: { _id: string; name: string; email: string; role: string }[];
  tags: string[];
  notes: any[];
  createdBy: { _id: string; name: string };
  createdAt: string;
}

const CAMPAIGN_TYPES: Record<string, { label: string; icon: any; color: string; bg: string }> = {
  influencer:    { label: 'Influencer',      icon: Sparkles,       color: 'text-pink-600',    bg: 'bg-pink-50' },
  ambassador:    { label: 'Ambassador',      icon: GraduationCap,  color: 'text-amber-600',   bg: 'bg-amber-50' },
  seasonal:      { label: 'Seasonal',        icon: Gift,           color: 'text-red-600',     bg: 'bg-red-50' },
  social_push:   { label: 'Social Push',     icon: Smartphone,     color: 'text-blue-600',    bg: 'bg-blue-50' },
  cross_promo:   { label: 'Cross Promo',     icon: Handshake,      color: 'text-purple-600',  bg: 'bg-purple-50' },
  ad_hoc:        { label: 'Ad Hoc',          icon: Palette,        color: 'text-teal-600',    bg: 'bg-teal-50' },
  other:         { label: 'Other',           icon: Megaphone,      color: 'text-gray-600',    bg: 'bg-gray-50' },
};

const STATUS_OPTIONS: Record<string, { label: string; color: string; bg: string; icon: any }> = {
  planning:   { label: 'Planning',   color: 'text-blue-700',    bg: 'bg-blue-50',    icon: ClipboardList },
  active:     { label: 'Active',     color: 'text-emerald-700', bg: 'bg-emerald-50', icon: PlayCircle },
  paused:     { label: 'Paused',     color: 'text-amber-700',   bg: 'bg-amber-50',   icon: PauseCircle },
  completed:  { label: 'Completed',  color: 'text-green-700',   bg: 'bg-green-50',   icon: CheckCircle2 },
  cancelled:  { label: 'Cancelled',  color: 'text-red-700',     bg: 'bg-red-50',     icon: AlertCircle },
};

const PRIORITY_COLORS: Record<string, string> = {
  low: 'bg-gray-100 text-gray-600',
  medium: 'bg-blue-100 text-blue-600',
  high: 'bg-orange-100 text-orange-600',
  urgent: 'bg-red-100 text-red-600',
};

export default function CampaignsPage() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState<Campaign | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    name: '', description: '', type: 'other',
    startDate: '', endDate: '',
    budgetAllocated: '', expectedROI: '',
    priority: 'medium', tags: '',
  });

  const { canCreate, canEdit, canDelete } = useAuth();
  const router = useRouter();
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

  useEffect(() => { fetchCampaigns(); }, []);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
  };

  const fetchCampaigns = async () => {
    try {
      const params = new URLSearchParams();
      if (statusFilter !== 'all') params.append('status', statusFilter);
      if (typeFilter !== 'all') params.append('type', typeFilter);
      if (searchTerm) params.append('search', searchTerm);
      const res = await fetch(`${API_URL}/api/campaigns?${params}`, { headers: getAuthHeaders() });
      if (res.ok) setCampaigns(await res.json());
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchCampaigns(); }, [statusFilter, typeFilter, searchTerm]);

  const handleSubmit = async () => {
    if (!formData.name) { setError('Campaign name is required'); return; }
    setSubmitting(true); setError('');
    try {
      const url = editingCampaign ? `${API_URL}/api/campaigns/${editingCampaign._id}` : `${API_URL}/api/campaigns`;
      const method = editingCampaign ? 'PUT' : 'POST';
      const body = {
        name: formData.name, description: formData.description,
        type: formData.type, startDate: formData.startDate || undefined,
        endDate: formData.endDate || undefined,
        budget: { allocated: parseFloat(formData.budgetAllocated) || 0, spent: editingCampaign?.budget?.spent || 0 },
        expectedROI: parseFloat(formData.expectedROI) || 0,
        priority: formData.priority,
        tags: formData.tags ? formData.tags.split(',').map(t => t.trim()).filter(Boolean) : [],
      };
      const res = await fetch(url, { method, headers: getAuthHeaders(), body: JSON.stringify(body) });
      if (res.ok) {
        fetchCampaigns();
        closeModal();
        setSuccess(editingCampaign ? 'Campaign updated!' : 'Campaign created!');
        setTimeout(() => setSuccess(''), 3000);
      } else {
        const d = await res.json();
        setError(d.message || 'Failed');
      }
    } catch { setError('Failed to save'); }
    finally { setSubmitting(false); }
  };

  const handleStatusChange = async (campaign: Campaign, newStatus: string) => {
    try {
      await fetch(`${API_URL}/api/campaigns/${campaign._id}`, {
        method: 'PUT', headers: getAuthHeaders(),
        body: JSON.stringify({ status: newStatus }),
      });
      fetchCampaigns();
    } catch { setError('Failed to update status'); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Deactivate this campaign?')) return;
    try {
      await fetch(`${API_URL}/api/campaigns/${id}`, { method: 'DELETE', headers: getAuthHeaders() });
      fetchCampaigns();
      setSuccess('Campaign deactivated');
      setTimeout(() => setSuccess(''), 3000);
    } catch { setError('Failed'); }
  };

  const openEditModal = (campaign: Campaign) => {
    setEditingCampaign(campaign);
    setFormData({
      name: campaign.name, description: campaign.description || '',
      type: campaign.type,
      startDate: campaign.startDate ? new Date(campaign.startDate).toISOString().split('T')[0] : '',
      endDate: campaign.endDate ? new Date(campaign.endDate).toISOString().split('T')[0] : '',
      budgetAllocated: campaign.budget?.allocated?.toString() || '',
      expectedROI: campaign.expectedROI?.toString() || '',
      priority: campaign.priority, tags: campaign.tags?.join(', ') || '',
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false); setEditingCampaign(null); setError('');
    setFormData({ name: '', description: '', type: 'other', startDate: '', endDate: '', budgetAllocated: '', expectedROI: '', priority: 'medium', tags: '' });
  };

  const formatCurrency = (val: number) => val >= 1000 ? `$${(val / 1000).toFixed(1)}k` : `$${val}`;
  const totalBudget = campaigns.reduce((s, c) => s + (c.budget?.allocated || 0), 0);
  const totalSpent = campaigns.reduce((s, c) => s + (c.budget?.spent || 0), 0);
  const totalDeliverables = campaigns.reduce((s, c) => s + (c.deliverables?.length || 0), 0);

  if (loading) {
    return (
      <ProtectedPage page="campaigns">
        <DashboardLayout>
          <div className="flex justify-center items-center h-96">
            <div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-600 border-t-transparent" />
          </div>
        </DashboardLayout>
      </ProtectedPage>
    );
  }

  return (
    <ProtectedPage page="campaigns">
      <DashboardLayout>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
          {/* Toast */}
          {success && (
            <div className="fixed top-6 right-6 z-50 bg-white border border-emerald-200 shadow-lg rounded-xl px-5 py-3 text-sm font-medium text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-500" />{success}
            </div>
          )}

          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-gray-900">Campaigns</h1>
              <p className="text-sm text-gray-500 mt-1">
                {campaigns.length} campaign{campaigns.length !== 1 ? 's' : ''} • {formatCurrency(totalBudget)} budget • {totalDeliverables} deliverables
              </p>
            </div>
            {canCreate('campaigns') && (
              <button onClick={() => setShowModal(true)}
                className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white text-sm font-semibold rounded-xl shadow-sm hover:bg-indigo-700 transition-colors">
                <Plus className="h-4 w-4" /> Create Campaign
              </button>
            )}
          </div>

          {/* Stats Pipeline */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {Object.entries(STATUS_OPTIONS).map(([key, val]) => {
              const count = campaigns.filter(c => c.status === key).length;
              const Icon = val.icon;
              return (
                <button key={key} onClick={() => setStatusFilter(statusFilter === key ? 'all' : key)}
                  className={`p-3 rounded-xl border-2 text-left transition-all ${statusFilter === key ? `${val.bg} ring-2 ring-indigo-400 scale-[1.02]` : 'bg-white border-gray-100 hover:border-gray-200'}`}>
                  <div className="flex items-center gap-2 mb-1">
                    <Icon className={`h-4 w-4 ${val.color}`} />
                    <span className="text-xs font-medium text-gray-500">{val.label}</span>
                  </div>
                  <p className="text-xl font-bold text-gray-900">{count}</p>
                </button>
              );
            })}
          </div>

          {/* Filters */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input type="text" placeholder="Search campaigns..." className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
              </div>
              <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)}
                className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium text-gray-700">
                <option value="all">All Types</option>
                {Object.entries(CAMPAIGN_TYPES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>
          </div>

          {/* Campaigns Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {campaigns.map(campaign => {
              const typeInfo = CAMPAIGN_TYPES[campaign.type] || CAMPAIGN_TYPES.other;
              const statusInfo = STATUS_OPTIONS[campaign.status] || STATUS_OPTIONS.planning;
              const TypeIcon = typeInfo.icon;
              const StatusIcon = statusInfo.icon;
              const usagePercent = campaign.budgetUsagePercent || 0;

              return (
                <div key={campaign._id} 
                  onClick={() => router.push(`/campaigns/${campaign._id}`)}
                  className="group bg-white rounded-2xl border border-gray-200 p-5 hover:shadow-lg hover:border-gray-300 transition-all cursor-pointer">
                  
                  {/* Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className={`h-10 w-10 rounded-xl ${typeInfo.bg} flex items-center justify-center shrink-0`}>
                        <TypeIcon className={`h-5 w-5 ${typeInfo.color}`} />
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-semibold text-gray-900 truncate">{campaign.name}</h3>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className={`text-xs font-medium ${typeInfo.color}`}>{typeInfo.label}</span>
                          <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${statusInfo.bg} ${statusInfo.color}`}>
                            {statusInfo.label}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Description */}
                  {campaign.description && (
                    <p className="text-sm text-gray-500 mb-3 line-clamp-2">{campaign.description}</p>
                  )}

                  {/* Budget Bar */}
                  {campaign.budget?.allocated > 0 && (
                    <div className="mb-3">
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-gray-500">Budget</span>
                        <span className="font-semibold text-gray-700">{formatCurrency(campaign.budget.spent)} / {formatCurrency(campaign.budget.allocated)}</span>
                      </div>
                      <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                        <div className={`h-full rounded-full transition-all ${usagePercent >= 90 ? 'bg-red-500' : usagePercent >= 75 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                          style={{ width: `${Math.min(usagePercent, 100)}%` }} />
                      </div>
                    </div>
                  )}

                  {/* Linked Brands */}
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {campaign.clientBrands?.slice(0, 3).map(b => (
                      <span key={b._id} className="inline-flex items-center gap-1 px-2 py-0.5 bg-green-50 text-green-700 text-xs rounded-full font-medium">
                        <Building2 className="h-3 w-3" /> {b.brandName}
                      </span>
                    ))}
                    {campaign.brands?.slice(0, 3).map(b => (
                      <span key={b._id} className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-50 text-amber-700 text-xs rounded-full font-medium">
                        <Link className="h-3 w-3" /> {b.brandName}
                      </span>
                    ))}
                    {(campaign.clientBrands?.length + campaign.brands?.length) > 6 && (
                      <span className="text-xs text-gray-400">+{campaign.clientBrands.length + campaign.brands.length - 6} more</span>
                    )}
                  </div>

                  {/* Meta */}
                  <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                    {campaign.startDate && (
                      <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />{new Date(campaign.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                    )}
                    <span className="flex items-center gap-1"><Users className="h-3 w-3" />{campaign.teamMembers?.length || 0} members</span>
                    <span className="flex items-center gap-1"><ClipboardList className="h-3 w-3" />{campaign.deliverables?.length || 0} tasks</span>
                  </div>

                  {/* Priority & Actions */}
                  <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                    <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${PRIORITY_COLORS[campaign.priority]}`}>
                      {campaign.priority}
                    </span>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {canEdit('campaigns') && (
                        <button onClick={(e) => { e.stopPropagation(); openEditModal(campaign); }}
                          className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg"><Edit className="h-4 w-4" /></button>
                      )}
                      {canDelete('campaigns') && (
                        <button onClick={(e) => { e.stopPropagation(); handleDelete(campaign._id); }}
                          className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg"><Trash2 className="h-4 w-4" /></button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {campaigns.length === 0 && (
            <div className="text-center py-20 bg-white rounded-2xl border border-gray-200">
              <div className="h-16 w-16 rounded-2xl bg-gray-100 flex items-center justify-center mx-auto mb-4">
                <Megaphone className="h-8 w-8 text-gray-300" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">No campaigns yet</h3>
              <p className="text-sm text-gray-500 mt-1">Create your first marketing campaign.</p>
              {canCreate('campaigns') && (
                <button onClick={() => setShowModal(true)}
                  className="mt-4 px-5 py-2.5 bg-indigo-600 text-white text-sm font-semibold rounded-xl">Create Campaign</button>
              )}
            </div>
          )}

          {/* Create/Edit Modal */}
          {showModal && (
            <div className="fixed inset-0 z-50 overflow-y-auto">
              <div className="flex min-h-full items-center justify-center p-4">
                <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={closeModal} />
                <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg border border-gray-100">
                  <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 rounded-t-2xl flex items-center justify-between">
                    <h2 className="text-lg font-bold text-gray-900">{editingCampaign ? 'Edit' : 'Create'} Campaign</h2>
                    <button onClick={closeModal} className="p-2 hover:bg-gray-100 rounded-xl"><X className="h-5 w-5 text-gray-400" /></button>
                  </div>
                  <div className="p-6 space-y-4">
                    {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm">{error}</div>}
                    
                    <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Campaign Name <span className="text-red-500">*</span></label><input type="text" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g., Summer Fest 2026" /></div>
                    <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Description</label><textarea className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 resize-none" rows={2} value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} /></div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Type</label><select className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.type} onChange={e => setFormData({...formData, type: e.target.value})}>{Object.entries(CAMPAIGN_TYPES).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}</select></div>
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Priority</label><select className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.priority} onChange={e => setFormData({...formData, priority: e.target.value})}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="urgent">Urgent</option></select></div>
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Start Date</label><input type="date" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.startDate} onChange={e => setFormData({...formData, startDate: e.target.value})} /></div>
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">End Date</label><input type="date" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.endDate} onChange={e => setFormData({...formData, endDate: e.target.value})} /></div>
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Budget ($)</label><input type="number" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.budgetAllocated} onChange={e => setFormData({...formData, budgetAllocated: e.target.value})} /></div>
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Expected ROI ($)</label><input type="number" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.expectedROI} onChange={e => setFormData({...formData, expectedROI: e.target.value})} /></div>
                    </div>
                    <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Tags</label><input type="text" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.tags} onChange={e => setFormData({...formData, tags: e.target.value})} placeholder="summer, fest, 2026" /></div>
                  </div>
                  <div className="sticky bottom-0 bg-white border-t border-gray-100 px-6 py-4 rounded-b-2xl flex justify-end gap-3">
                    <button onClick={closeModal} className="px-5 py-2.5 text-sm font-semibold text-gray-700 border rounded-xl">Cancel</button>
                    <button onClick={handleSubmit} disabled={submitting} className="px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700">{submitting ? 'Saving...' : editingCampaign ? 'Update' : 'Create Campaign'}</button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedPage>
  );
}