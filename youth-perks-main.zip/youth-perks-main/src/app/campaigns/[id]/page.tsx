'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { ProtectedPage } from '@/components/auth/ProtectedPage';
import { useAuth } from '@/hooks/useAuth';
import {
  ArrowLeft, Edit, Calendar, DollarSign, Users, Target, Plus,
  X, CheckCircle2, Clock, AlertCircle, ClipboardList, Megaphone,
  Building2, Link, Trash2, Save, PlayCircle, PauseCircle,
  Sparkles, GraduationCap, Gift, Smartphone, Handshake,
  Palette, TrendingUp, Flag, ArrowUpRight, Download, Upload,
  MessageSquare, BarChart3
} from 'lucide-react';

interface Deliverable {
  _id: string;
  title: string;
  description: string;
  status: string;
  dueDate?: string;
  completedAt?: string;
  assignedTo?: { _id: string; name: string };
}

interface Note {
  _id: string;
  content: string;
  createdBy: { _id: string; name: string; email: string };
  createdAt: string;
}

interface Campaign {
  _id: string;
  name: string;
  description: string;
  type: string;
  brands: { _id: string; brandName: string; logo: string; status: string }[];
  clientBrands: { _id: string; brandName: string; logo: string; partnerType: string }[];
  startDate: string;
  endDate: string;
  budget: { allocated: number; spent: number };
  budgetRemaining: number;
  budgetUsagePercent: number;
  expectedROI: number;
  actualROI: number;
  status: string;
  priority: string;
  deliverables: Deliverable[];
  teamMembers: { _id: string; name: string; email: string; role: string }[];
  notes: Note[];
  tags: string[];
  contentCalendar: string;
  socialLinks: { instagram: string; twitter: string; youtube: string };
  createdBy: { _id: string; name: string; email: string };
  createdAt: string;
}

const CAMPAIGN_TYPES: Record<string, { label: string; icon: any; color: string; bg: string }> = {
  influencer:    { label: 'Influencer',      icon: Sparkles,       color: 'text-pink-600',    bg: 'bg-pink-50' },
  ambassador:    { label: 'Ambassador',      icon: GraduationCap,  color: 'text-amber-600',   bg: 'bg-amber-50' },
  seasonal:      { label: 'Seasonal',        icon: Gift,           color: 'text-red-600',     bg: 'bg-red-50' },
  social_push:   { label: 'Social Push',     icon: Smartphone,     color: 'text-blue-600',    bg: 'bg-blue-50' },
  cross_promo:   { label: 'Cross Promo',     icon: Handshake,      color: 'text-purple-600',  bg: 'bg-purple-50' },
  ad_hoc:        { label: 'Ad Hoc',          icon: Palette,        color: 'text-teal-600',    bg: 'bg-teal-50' },
  other:         { label: 'Other',           icon: Megaphone,      color: 'text-gray-600',    bg: 'bg-gray-50' },
};

const STATUS_OPTIONS: Record<string, { label: string; color: string; bg: string; icon: any }> = {
  planning:   { label: 'Planning',   color: 'text-blue-700',    bg: 'bg-blue-50',    icon: ClipboardList },
  active:     { label: 'Active',     color: 'text-emerald-700', bg: 'bg-emerald-50', icon: PlayCircle },
  paused:     { label: 'Paused',     color: 'text-amber-700',   bg: 'bg-amber-50',   icon: PauseCircle },
  completed:  { label: 'Completed',  color: 'text-green-700',   bg: 'bg-green-50',   icon: CheckCircle2 },
  cancelled:  { label: 'Cancelled',  color: 'text-red-700',     bg: 'bg-red-50',     icon: AlertCircle },
};

const TABS = ['Overview', 'Deliverables', 'Team', 'Brands', 'Notes'];

export default function CampaignDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const { user, canEdit, canDelete } = useAuth();
  const [campaign, setCampaign] = useState<Campaign | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('Overview');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [noteText, setNoteText] = useState('');
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeliverableModal, setShowDeliverableModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [editForm, setEditForm] = useState<any>({});
  const [deliverableForm, setDeliverableForm] = useState({
    title: '', description: '', dueDate: '', status: 'pending',
  });

  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';
  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';

  useEffect(() => { fetchCampaign(); }, [id]);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
  };

  const fetchCampaign = async () => {
    try {
      const res = await fetch(`${API_URL}/api/campaigns/${id}`, { headers: getAuthHeaders() });
      if (res.ok) setCampaign(await res.json());
      else router.push('/campaigns');
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const handleNoteAdd = async () => {
    if (!noteText.trim()) return;
    try {
      const res = await fetch(`${API_URL}/api/campaigns/${id}/notes`, {
        method: 'POST', headers: getAuthHeaders(), body: JSON.stringify({ content: noteText }),
      });
      if (res.ok) { setCampaign(await res.json()); setNoteText(''); }
    } catch { /* skip */ }
  };

  const handleStatusChange = async (newStatus: string) => {
    try {
      const res = await fetch(`${API_URL}/api/campaigns/${id}`, {
        method: 'PUT', headers: getAuthHeaders(), body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) { setCampaign(await res.json()); setSuccess('Status updated!'); setTimeout(() => setSuccess(''), 2000); }
    } catch { setError('Failed'); }
  };

  const handleDeliverableAdd = async () => {
    if (!deliverableForm.title) return;
    try {
      const updatedDeliverables = [...(campaign?.deliverables || []), { ...deliverableForm }];
      const res = await fetch(`${API_URL}/api/campaigns/${id}`, {
        method: 'PUT', headers: getAuthHeaders(), body: JSON.stringify({ deliverables: updatedDeliverables }),
      });
      if (res.ok) {
        setCampaign(await res.json());
        setShowDeliverableModal(false);
        setDeliverableForm({ title: '', description: '', dueDate: '', status: 'pending' });
      }
    } catch { setError('Failed'); }
  };

  const handleDeliverableStatus = async (deliverableId: string, newStatus: string) => {
    const updated = campaign?.deliverables.map(d => 
      d._id === deliverableId ? { ...d, status: newStatus, completedAt: newStatus === 'completed' ? new Date().toISOString() : undefined } : d
    );
    try {
      const res = await fetch(`${API_URL}/api/campaigns/${id}`, {
        method: 'PUT', headers: getAuthHeaders(), body: JSON.stringify({ deliverables: updated }),
      });
      if (res.ok) setCampaign(await res.json());
    } catch { /* skip */ }
  };

  const handleUpdate = async () => {
    setSubmitting(true);
    try {
      const res = await fetch(`${API_URL}/api/campaigns/${id}`, {
        method: 'PUT', headers: getAuthHeaders(), body: JSON.stringify(editForm),
      });
      if (res.ok) { setCampaign(await res.json()); setShowEditModal(false); setSuccess('Updated!'); setTimeout(() => setSuccess(''), 2000); }
    } catch { setError('Failed'); }
    finally { setSubmitting(false); }
  };

  const formatCurrency = (val: number) => val >= 1000 ? `$${(val / 1000).toFixed(1)}k` : `$${val}`;

  if (loading) {
    return (
      <ProtectedPage page="campaigns">
        <DashboardLayout>
          <div className="flex justify-center items-center h-96">
            <div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-600 border-t-transparent" />
          </div>
        </DashboardLayout>
      </ProtectedPage>
    );
  }

  if (!campaign) {
    return (
      <ProtectedPage page="campaigns">
        <DashboardLayout><div className="text-center py-20 text-gray-500">Campaign not found</div></DashboardLayout>
      </ProtectedPage>
    );
  }

  const typeInfo = CAMPAIGN_TYPES[campaign.type] || CAMPAIGN_TYPES.other;
  const statusInfo = STATUS_OPTIONS[campaign.status] || STATUS_OPTIONS.planning;
  const TypeIcon = typeInfo.icon;
  const StatusIcon = statusInfo.icon;
  const usagePercent = campaign.budgetUsagePercent || 0;
  const daysRemaining = campaign.endDate ? Math.ceil((new Date(campaign.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : null;

  return (
    <ProtectedPage page="campaigns">
      <DashboardLayout>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
          {success && <div className="fixed top-6 right-6 z-50 bg-white border border-emerald-200 shadow-lg rounded-xl px-5 py-3 text-sm font-medium text-emerald-800">{success}</div>}
          {error && <div className="fixed top-6 right-6 z-50 bg-white border border-red-200 shadow-lg rounded-xl px-5 py-3 text-sm font-medium text-red-800">{error}</div>}

          {/* Header */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <button onClick={() => router.push('/campaigns')} className="p-2 hover:bg-gray-100 rounded-xl">
                  <ArrowLeft className="h-5 w-5 text-gray-500" />
                </button>
                <div className={`h-14 w-14 rounded-2xl ${typeInfo.bg} flex items-center justify-center`}>
                  <TypeIcon className={`h-7 w-7 ${typeInfo.color}`} />
                </div>
                <div>
                  <div className="flex items-center gap-3">
                    <h1 className="text-2xl font-bold text-gray-900">{campaign.name}</h1>
                    <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${typeInfo.bg} ${typeInfo.color}`}>{typeInfo.label}</span>
                    <select value={campaign.status} onChange={e => handleStatusChange(e.target.value)}
                      className={`text-xs font-semibold rounded-lg px-2.5 py-1 border cursor-pointer ${statusInfo.bg} ${statusInfo.color}`}>
                      {Object.entries(STATUS_OPTIONS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                    </select>
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-sm text-gray-500">
                    {campaign.createdBy && <span>Created by {campaign.createdBy.name}</span>}
                    {campaign.startDate && <span>• {new Date(campaign.startDate).toLocaleDateString()}</span>}
                  </div>
                </div>
              </div>
              {canEdit('campaigns') && (
                <button onClick={() => {
                  setEditForm({
                    name: campaign.name, description: campaign.description || '',
                    type: campaign.type, priority: campaign.priority,
                    startDate: campaign.startDate ? new Date(campaign.startDate).toISOString().split('T')[0] : '',
                    endDate: campaign.endDate ? new Date(campaign.endDate).toISOString().split('T')[0] : '',
                    budgetAllocated: campaign.budget?.allocated || 0,
                    expectedROI: campaign.expectedROI || 0,
                    tags: campaign.tags?.join(', ') || '',
                  });
                  setShowEditModal(true);
                }} className="px-4 py-2 text-sm font-semibold text-gray-700 bg-white border rounded-xl hover:bg-gray-50 flex items-center gap-2">
                  <Edit className="h-4 w-4" /> Edit
                </button>
              )}
            </div>
          </div>

          {/* KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Budget', value: `${formatCurrency(campaign.budget?.spent || 0)} / ${formatCurrency(campaign.budget?.allocated || 0)}`, sub: `${usagePercent}% used`, icon: DollarSign, color: 'bg-indigo-500' },
              { label: 'Deliverables', value: `${campaign.deliverables?.filter(d => d.status === 'completed').length || 0}/${campaign.deliverables?.length || 0}`, sub: 'completed', icon: ClipboardList, color: 'bg-emerald-500' },
              { label: 'Team', value: campaign.teamMembers?.length || 0, sub: 'members', icon: Users, color: 'bg-blue-500' },
              { label: 'Time Left', value: daysRemaining !== null ? `${daysRemaining} days` : 'N/A', sub: campaign.endDate ? new Date(campaign.endDate).toLocaleDateString() : 'No end date', icon: Calendar, color: daysRemaining !== null && daysRemaining < 7 ? 'bg-red-500' : 'bg-teal-500' },
            ].map(kpi => (
              <div key={kpi.label} className="bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow">
                <div className={`h-10 w-10 ${kpi.color} rounded-xl flex items-center justify-center mb-3`}>
                  <kpi.icon className="h-5 w-5 text-white" />
                </div>
                <p className="text-xl font-bold text-gray-900">{kpi.value}</p>
                <p className="text-xs text-gray-500">{kpi.label}</p>
                <p className="text-[10px] text-gray-400 mt-0.5">{kpi.sub}</p>
              </div>
            ))}
          </div>

          {/* Budget Bar */}
          {campaign.budget?.allocated > 0 && (
            <div className="bg-white rounded-2xl border border-gray-200 p-5">
              <div className="flex justify-between mb-2">
                <h3 className="text-sm font-bold text-gray-900">Budget Usage</h3>
                <span className="text-sm font-semibold text-gray-700">{formatCurrency(campaign.budget.spent)} of {formatCurrency(campaign.budget.allocated)}</span>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden">
                <div className={`h-full rounded-full transition-all duration-500 ${usagePercent >= 90 ? 'bg-red-500' : usagePercent >= 75 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                  style={{ width: `${Math.min(usagePercent, 100)}%` }} />
              </div>
            </div>
          )}

          {/* Tabs */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="flex border-b border-gray-200 overflow-x-auto">
              {TABS.map(tab => (
                <button key={tab} onClick={() => setActiveTab(tab)}
                  className={`px-5 py-3.5 text-sm font-semibold whitespace-nowrap border-b-2 transition-all ${
                    activeTab === tab ? 'text-indigo-600 border-indigo-600' : 'text-gray-500 border-transparent hover:text-gray-700'
                  }`}>
                  {tab}
                </button>
              ))}
            </div>

            <div className="p-6">
              {/* OVERVIEW */}
              {activeTab === 'Overview' && (
                <div className="space-y-6">
                  {campaign.description && <p className="text-gray-600">{campaign.description}</p>}
                  
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-gray-50 rounded-xl">
                      <p className="text-xs text-gray-500">Priority</p>
                      <p className="text-sm font-semibold text-gray-900 capitalize mt-1">{campaign.priority}</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-xl">
                      <p className="text-xs text-gray-500">Expected ROI</p>
                      <p className="text-sm font-semibold text-gray-900 mt-1">{formatCurrency(campaign.expectedROI)}</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-xl">
                      <p className="text-xs text-gray-500">Actual ROI</p>
                      <p className="text-sm font-semibold text-gray-900 mt-1">{formatCurrency(campaign.actualROI)}</p>
                    </div>
                    {campaign.startDate && (
                      <div className="p-4 bg-gray-50 rounded-xl">
                        <p className="text-xs text-gray-500">Start Date</p>
                        <p className="text-sm font-semibold text-gray-900 mt-1">{new Date(campaign.startDate).toLocaleDateString()}</p>
                      </div>
                    )}
                    {campaign.endDate && (
                      <div className="p-4 bg-gray-50 rounded-xl">
                        <p className="text-xs text-gray-500">End Date</p>
                        <p className="text-sm font-semibold text-gray-900 mt-1">{new Date(campaign.endDate).toLocaleDateString()}</p>
                      </div>
                    )}
                    {campaign.tags?.length > 0 && (
                      <div className="p-4 bg-gray-50 rounded-xl">
                        <p className="text-xs text-gray-500">Tags</p>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {campaign.tags.map(tag => <span key={tag} className="px-2 py-0.5 bg-white text-xs rounded-full">{tag}</span>)}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Notes */}
                  <div>
                    <h3 className="text-sm font-bold text-gray-900 mb-3">Notes</h3>
                    <div className="space-y-2 max-h-48 overflow-y-auto mb-3">
                      {campaign.notes?.length > 0 ? campaign.notes.map(note => (
                        <div key={note._id} className="p-3 bg-gray-50 rounded-xl text-sm">
                          <p className="text-gray-700">{note.content}</p>
                          <p className="text-xs text-gray-400 mt-1">{note.createdBy?.name} • {new Date(note.createdAt).toLocaleDateString()}</p>
                        </div>
                      )) : <p className="text-sm text-gray-400 py-4 text-center">No notes yet</p>}
                    </div>
                    <div className="flex gap-2">
                      <input type="text" placeholder="Add a note..." className="flex-1 border rounded-xl px-4 py-2.5 text-sm bg-gray-50" value={noteText} onChange={e => setNoteText(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleNoteAdd()} />
                      <button onClick={handleNoteAdd} className="px-4 py-2.5 bg-indigo-600 text-white text-sm font-semibold rounded-xl">Add</button>
                    </div>
                  </div>
                </div>
              )}

              {/* DELIVERABLES */}
              {activeTab === 'Deliverables' && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-bold text-gray-900">Deliverables ({campaign.deliverables?.length || 0})</h3>
                    <button onClick={() => setShowDeliverableModal(true)} className="px-4 py-2 bg-indigo-600 text-white text-sm font-semibold rounded-xl flex items-center gap-2"><Plus className="h-4 w-4" /> Add</button>
                  </div>
                  <div className="space-y-2">
                    {campaign.deliverables?.map(d => (
                      <div key={d._id} className="flex items-center justify-between p-4 border border-gray-200 rounded-xl hover:bg-gray-50">
                        <div className="flex items-center gap-3">
                          <select value={d.status} onChange={e => handleDeliverableStatus(d._id, e.target.value)}
                            className="text-xs font-semibold rounded-lg px-2 py-1 border bg-gray-50">
                            <option value="pending">Pending</option>
                            <option value="in_progress">In Progress</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                          <div>
                            <p className="text-sm font-semibold text-gray-900">{d.title}</p>
                            {d.description && <p className="text-xs text-gray-500">{d.description}</p>}
                            {d.dueDate && <p className="text-xs text-gray-400 mt-0.5">Due: {new Date(d.dueDate).toLocaleDateString()}</p>}
                          </div>
                        </div>
                        {d.status === 'completed' ? <CheckCircle2 className="h-5 w-5 text-emerald-500" /> : d.status === 'in_progress' ? <Clock className="h-5 w-5 text-amber-500" /> : <AlertCircle className="h-5 w-5 text-gray-400" />}
                      </div>
                    ))}
                    {(!campaign.deliverables || campaign.deliverables.length === 0) && <p className="text-gray-400 text-sm text-center py-8">No deliverables yet</p>}
                  </div>
                </div>
              )}

              {/* TEAM */}
              {activeTab === 'Team' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-gray-900">Team Members ({campaign.teamMembers?.length || 0})</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {campaign.teamMembers?.map(member => (
                      <div key={member._id} className="flex items-center gap-3 p-4 border border-gray-200 rounded-xl">
                        <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center text-sm font-bold text-indigo-600">
                          {member.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-gray-900">{member.name}</p>
                          <p className="text-xs text-gray-500">{member.email}</p>
                          <p className="text-xs text-gray-400 capitalize">{member.role?.replace(/_/g, ' ')}</p>
                        </div>
                      </div>
                    ))}
                    {(!campaign.teamMembers || campaign.teamMembers.length === 0) && <p className="text-gray-400 text-sm col-span-2 text-center py-8">No team members assigned</p>}
                  </div>
                </div>
              )}

              {/* BRANDS */}
              {activeTab === 'Brands' && (
                <div className="space-y-6">
                  {campaign.clientBrands?.length > 0 && (
                    <div>
                      <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-3">Signed Clients ({campaign.clientBrands.length})</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {campaign.clientBrands.map(brand => (
                          <div key={brand._id} className="flex items-center gap-3 p-4 border border-emerald-200 bg-emerald-50/30 rounded-xl cursor-pointer hover:shadow-md"
                            onClick={() => router.push(`/clients/${brand._id}`)}>
                            <Building2 className="h-5 w-5 text-emerald-600" />
                            <div>
                              <p className="text-sm font-semibold text-gray-900">{brand.brandName}</p>
                              <p className="text-xs text-emerald-600 capitalize">{brand.partnerType?.replace(/_/g, ' ')}</p>
                            </div>
                            <span className="ml-auto text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">Signed</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {campaign.brands?.length > 0 && (
                    <div>
                      <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-3">Pipeline Brands ({campaign.brands.length})</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {campaign.brands.map(brand => (
                          <div key={brand._id} className="flex items-center gap-3 p-4 border border-amber-200 bg-amber-50/30 rounded-xl cursor-pointer hover:shadow-md"
                            onClick={() => router.push(`/brands`)}>
                            <Link className="h-5 w-5 text-amber-600" />
                            <div>
                              <p className="text-sm font-semibold text-gray-900">{brand.brandName}</p>
                              <p className="text-xs text-amber-600 capitalize">{brand.status?.replace(/_/g, ' ')}</p>
                            </div>
                            <span className="ml-auto text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">Pitching</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {(!campaign.brands || campaign.brands.length === 0) && (!campaign.clientBrands || campaign.clientBrands.length === 0) && (
                    <p className="text-gray-400 text-sm text-center py-12">No brands linked to this campaign</p>
                  )}
                </div>
              )}

              {/* NOTES */}
              {activeTab === 'Notes' && (
                <div className="space-y-4">
                  <div className="flex gap-2 mb-4">
                    <input type="text" placeholder="Add a note..." className="flex-1 border rounded-xl px-4 py-2.5 text-sm bg-gray-50" value={noteText} onChange={e => setNoteText(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleNoteAdd()} />
                    <button onClick={handleNoteAdd} className="px-4 py-2.5 bg-indigo-600 text-white text-sm font-semibold rounded-xl">Add</button>
                  </div>
                  <div className="space-y-2">
                    {campaign.notes?.length > 0 ? campaign.notes.map(note => (
                      <div key={note._id} className="p-4 bg-gray-50 rounded-xl">
                        <p className="text-sm text-gray-700">{note.content}</p>
                        <p className="text-xs text-gray-400 mt-1">{note.createdBy?.name} • {new Date(note.createdAt).toLocaleString()}</p>
                      </div>
                    )) : <p className="text-gray-400 text-sm text-center py-8">No notes yet</p>}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Deliverable Modal */}
          {showDeliverableModal && (
            <div className="fixed inset-0 z-50 overflow-y-auto">
              <div className="flex min-h-full items-center justify-center p-4">
                <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setShowDeliverableModal(false)} />
                <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md border border-gray-100">
                  <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                    <h2 className="text-lg font-bold">Add Deliverable</h2>
                    <button onClick={() => setShowDeliverableModal(false)} className="p-2 hover:bg-gray-100 rounded-xl"><X className="h-5 w-5 text-gray-400" /></button>
                  </div>
                  <div className="p-6 space-y-3">
                    <input type="text" placeholder="Title *" className="w-full border rounded-xl px-4 py-2.5 text-sm bg-gray-50" value={deliverableForm.title} onChange={e => setDeliverableForm({...deliverableForm, title: e.target.value})} />
                    <input type="text" placeholder="Description" className="w-full border rounded-xl px-4 py-2.5 text-sm bg-gray-50" value={deliverableForm.description} onChange={e => setDeliverableForm({...deliverableForm, description: e.target.value})} />
                    <input type="date" className="w-full border rounded-xl px-4 py-2.5 text-sm bg-gray-50" value={deliverableForm.dueDate} onChange={e => setDeliverableForm({...deliverableForm, dueDate: e.target.value})} />
                  </div>
                  <div className="px-6 py-4 border-t flex justify-end gap-3">
                    <button onClick={() => setShowDeliverableModal(false)} className="px-4 py-2 text-sm font-semibold text-gray-700 border rounded-xl">Cancel</button>
                    <button onClick={handleDeliverableAdd} className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-xl">Add</button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Edit Modal */}
          {showEditModal && (
            <div className="fixed inset-0 z-50 overflow-y-auto">
              <div className="flex min-h-full items-center justify-center p-4">
                <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setShowEditModal(false)} />
                <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg border border-gray-100">
                  <div className="px-6 py-4 border-b flex items-center justify-between">
                    <h2 className="text-lg font-bold">Edit Campaign</h2>
                    <button onClick={() => setShowEditModal(false)} className="p-2 hover:bg-gray-100 rounded-xl"><X className="h-5 w-5 text-gray-400" /></button>
                  </div>
                  <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
                    <div><label className="block text-xs font-semibold mb-1">Name</label><input type="text" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.name || ''} onChange={e => setEditForm({...editForm, name: e.target.value})} /></div>
                    <div><label className="block text-xs font-semibold mb-1">Description</label><textarea className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" rows={2} value={editForm.description || ''} onChange={e => setEditForm({...editForm, description: e.target.value})} /></div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className="block text-xs font-semibold mb-1">Type</label><select className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.type || ''} onChange={e => setEditForm({...editForm, type: e.target.value})}>{Object.entries(CAMPAIGN_TYPES).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}</select></div>
                      <div><label className="block text-xs font-semibold mb-1">Priority</label><select className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.priority || ''} onChange={e => setEditForm({...editForm, priority: e.target.value})}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="urgent">Urgent</option></select></div>
                      <div><label className="block text-xs font-semibold mb-1">Start Date</label><input type="date" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.startDate || ''} onChange={e => setEditForm({...editForm, startDate: e.target.value})} /></div>
                      <div><label className="block text-xs font-semibold mb-1">End Date</label><input type="date" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.endDate || ''} onChange={e => setEditForm({...editForm, endDate: e.target.value})} /></div>
                      <div><label className="block text-xs font-semibold mb-1">Budget ($)</label><input type="number" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.budgetAllocated || ''} onChange={e => setEditForm({...editForm, budgetAllocated: e.target.value})} /></div>
                      <div><label className="block text-xs font-semibold mb-1">Expected ROI ($)</label><input type="number" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.expectedROI || ''} onChange={e => setEditForm({...editForm, expectedROI: e.target.value})} /></div>
                    </div>
                  </div>
                  <div className="px-6 py-4 border-t flex justify-end gap-3">
                    <button onClick={() => setShowEditModal(false)} className="px-4 py-2 text-sm font-semibold text-gray-700 border rounded-xl">Cancel</button>
                    <button onClick={handleUpdate} disabled={submitting} className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-xl">{submitting ? 'Saving...' : 'Save Changes'}</button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedPage>
  );
}