'use client';

import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Button } from '@/components/ui/button';
import { Plus, Search, Lightbulb, MessageSquare, Heart, ThumbsUp, Star, X, Send, Laugh, Frown, Angry } from 'lucide-react';
import { ProtectedPage } from '@/components/auth/ProtectedPage';

interface Idea {
  _id: string;
  title: string;
  description: string;
  postedBy: { _id: string; name: string; email: string };
  status: 'open' | 'in_progress' | 'implemented';
  category: string;
  tags: string[];
  comments: Array<{
    _id: string;
    userId: { _id: string; name: string; email: string };
    content: string;
    createdAt: string;
  }>;
  reactions: Array<{
    _id: string;
    userId: { _id: string; name: string } | string; // Allow both types
    type: 'like' | 'love' | 'laugh' | 'wow' | 'sad' | 'angry';
    createdAt: string;
  }>;
  reactionCounts?: Record<string, number>;
  createdAt: string;
}

export default function IdeasPage() {
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedIdea, setSelectedIdea] = useState<Idea | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'general',
    tags: '',
  });

  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

  useEffect(() => {
    fetchIdeas();

    // Safely access localStorage only on the client
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        setCurrentUserId(payload.id);
      } catch {
        setCurrentUserId(null);
      }
    }
  }, []);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    };
  };

  const fetchIdeas = async () => {
    try {
      const response = await fetch(`${API_URL}/api/ideas`, {
        headers: getAuthHeaders(),
      });
      if (response.ok) {
        const data = await response.json();
        setIdeas(data);
      } else if (response.status === 401) {
        localStorage.removeItem('token');
        window.location.href = '/login';
      }
    } catch (error) {
      console.error('Failed to fetch ideas:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateIdea = async () => {
    if (!formData.title || !formData.description) {
      setError('Title and description are required');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      const response = await fetch(`${API_URL}/api/ideas`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          title: formData.title,
          description: formData.description,
          category: formData.category,
          tags: formData.tags ? formData.tags.split(',').map((t: string) => t.trim()) : [],
        }),
      });
      if (response.ok) {
        const data = await response.json();
        setIdeas([data, ...ideas]);
        closeCreateModal();
        setSuccess('Idea shared successfully!');
        setTimeout(() => setSuccess(''), 3000);
      } else {
        const data = await response.json();
        setError(data.message || 'Failed to create idea');
      }
    } catch {
      setError('Failed to create idea');
    } finally {
      setSubmitting(false);
    }
  };

  const handleReaction = async (ideaId: string, type: string) => {
    try {
      const response = await fetch(`${API_URL}/api/ideas/${ideaId}/reaction`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ type }),
      });
      if (response.ok) {
        const data = await response.json();
        setIdeas(ideas.map(i => i._id === ideaId ? data : i));
        if (selectedIdea?._id === ideaId) {
          setSelectedIdea(data);
        }
      }
    } catch (error) {
      console.error('Failed to react:', error);
    }
  };

  const handleAddComment = async () => {
    if (!selectedIdea || !commentText.trim()) return;
    setSubmitting(true);
    try {
      const response = await fetch(`${API_URL}/api/ideas/${selectedIdea._id}/comment`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ content: commentText }),
      });
      if (response.ok) {
        const data = await response.json();
        setIdeas(ideas.map(i => i._id === data._id ? data : i));
        setSelectedIdea(data);
        setCommentText('');
        setSuccess('Comment added!');
        setTimeout(() => setSuccess(''), 2000);
      }
    } catch {
      setError('Failed to add comment');
    } finally {
      setSubmitting(false);
    }
  };

  const handleStatusChange = async (ideaId: string, newStatus: string) => {
    try {
      const response = await fetch(`${API_URL}/api/ideas/${ideaId}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({ status: newStatus }),
      });
      if (response.ok) {
        const data = await response.json();
        setIdeas(ideas.map(i => i._id === ideaId ? data : i));
        if (selectedIdea?._id === ideaId) {
          setSelectedIdea(data);
        }
      }
    } catch (error) {
      console.error('Failed to update status:', error);
    }
  };

  const handleDeleteIdea = async (ideaId: string) => {
    if (!confirm('Delete this idea?')) return;
    try {
      await fetch(`${API_URL}/api/ideas/${ideaId}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });
      setIdeas(ideas.filter(i => i._id !== ideaId));
      setShowDetailModal(false);
      setSuccess('Idea deleted!');
      setTimeout(() => setSuccess(''), 3000);
    } catch {
      setError('Failed to delete idea');
    }
  };

  const openDetailModal = (idea: Idea) => {
    setSelectedIdea(idea);
    setShowDetailModal(true);
  };

  const closeCreateModal = () => {
    setShowCreateModal(false);
    setError('');
    setFormData({ title: '', description: '', category: 'general', tags: '' });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'implemented': return 'bg-green-100 text-green-800';
      case 'in_progress': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getReactionCount = (idea: Idea, type: string) => {
    return idea.reactions?.filter(r => r.type === type).length || 0;
  };

  const getTotalReactions = (idea: Idea) => {
    return idea.reactions?.length || 0;
  };

  const reactionButtons = [
    { type: 'like', icon: Heart, color: 'hover:text-red-500', activeColor: 'text-red-500' },
    { type: 'love', icon: Star, color: 'hover:text-yellow-500', activeColor: 'text-yellow-500' },
    { type: 'laugh', icon: Laugh, color: 'hover:text-orange-500', activeColor: 'text-orange-500' },
    { type: 'wow', icon: ThumbsUp, color: 'hover:text-blue-500', activeColor: 'text-blue-500' },
    { type: 'sad', icon: Frown, color: 'hover:text-purple-500', activeColor: 'text-purple-500' },
    { type: 'angry', icon: Angry, color: 'hover:text-red-700', activeColor: 'text-red-700' },
  ];

  const getUserReaction = (idea: Idea) => {
    return idea.reactions?.find(r => {
      // Handle both cases: userId as object or as string
      if (typeof r.userId === 'object' && r.userId !== null) {
        return r.userId._id === currentUserId;
      }
      return r.userId === currentUserId;
    });
  };

  const filteredIdeas = ideas.filter(idea => {
    const matchesSearch = idea.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      idea.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || idea.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <ProtectedPage page="ideas">
        <DashboardLayout>
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
          </div>
        </DashboardLayout>
      </ProtectedPage>
    );
  }

  return (
    <ProtectedPage page="ideas">
      <DashboardLayout>
        <div className="p-4 lg:p-6 space-y-6">
          {success && <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">{success}</div>}
          {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">{error}</div>}

          {/* Header */}
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Ideas & Brainstorming</h1>
              <p className="text-gray-500 mt-1">Collaborative innovation and idea sharing platform</p>
            </div>
            <Button onClick={() => setShowCreateModal(true)} className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Share Idea
            </Button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Total Ideas', value: ideas.length, color: 'bg-blue-500' },
              { label: 'Open', value: ideas.filter(i => i.status === 'open').length, color: 'bg-yellow-500' },
              { label: 'In Progress', value: ideas.filter(i => i.status === 'in_progress').length, color: 'bg-orange-500' },
              { label: 'Total Reactions', value: ideas.reduce((sum, idea) => sum + getTotalReactions(idea), 0), color: 'bg-green-500' },
            ].map(s => (
              <div key={s.label} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${s.color}`}><Lightbulb className="h-5 w-5 text-white" /></div>
                  <div>
                    <p className="text-xl font-bold text-gray-900">{s.value}</p>
                    <p className="text-sm text-gray-500">{s.label}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Filters */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text" placeholder="Search ideas..."
                  className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <select className="px-4 py-2.5 border border-gray-200 rounded-lg" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                <option value="all">All Status</option>
                <option value="open">Open</option>
                <option value="in_progress">In Progress</option>
                <option value="implemented">Implemented</option>
              </select>
            </div>
          </div>

          {/* Ideas Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredIdeas.map((idea) => {
              const userReaction = getUserReaction(idea);
              return (
                <div key={idea._id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => openDetailModal(idea)}>
                  <div className="flex items-start justify-between mb-3">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(idea.status)}`}>
                      {idea.status.replace('_', ' ')}
                    </span>
                    <span className="text-xs text-gray-400">{new Date(idea.createdAt).toLocaleDateString()}</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{idea.title}</h3>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-3">{idea.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {reactionButtons.slice(0, 3).map(({ type, icon: Icon, color, activeColor }) => {
                        const count = getReactionCount(idea, type);
                        const isActive = userReaction?.type === type;
                        return (
                          <button key={type}
                            onClick={(e) => { e.stopPropagation(); handleReaction(idea._id, type); }}
                            className={`flex items-center gap-1 text-xs transition-colors ${isActive ? activeColor : 'text-gray-400'} ${color}`}>
                            <Icon className="h-4 w-4" />
                            {count > 0 && <span>{count}</span>}
                          </button>
                        );
                      })}
                    </div>
                    <div className="flex items-center gap-1 text-gray-400 text-xs">
                      <MessageSquare className="h-4 w-4" />
                      <span>{idea.comments?.length || 0}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredIdeas.length === 0 && (
            <div className="text-center py-16 bg-white rounded-xl border border-gray-100">
              <Lightbulb className="mx-auto h-12 w-12 text-gray-300" />
              <h3 className="mt-4 text-lg font-medium text-gray-900">No ideas found</h3>
              <Button className="mt-4" onClick={() => setShowCreateModal(true)}>
                <Plus className="h-4 w-4 mr-2" /> Share Idea
              </Button>
            </div>
          )}

          {/* Create Idea Modal */}
          {showCreateModal && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-xl shadow-xl max-w-lg w-full">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-bold">Share an Idea</h2>
                    <button onClick={closeCreateModal} className="p-2 hover:bg-gray-100 rounded-lg"><X className="h-5 w-5" /></button>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
                      <input type="text" className="w-full border border-gray-200 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        value={formData.title} onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        placeholder="What's your idea?" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Description *</label>
                      <textarea className="w-full border border-gray-200 rounded-lg px-3 py-2.5 min-h-[150px] focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        placeholder="Describe your idea in detail..." />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                        <select className="w-full border border-gray-200 rounded-lg px-3 py-2.5"
                          value={formData.category} onChange={(e) => setFormData({ ...formData, category: e.target.value })}>
                          <option value="general">General</option>
                          <option value="product">Product</option>
                          <option value="marketing">Marketing</option>
                          <option value="operations">Operations</option>
                          <option value="technology">Technology</option>
                          <option value="culture">Culture</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Tags (comma separated)</label>
                        <input type="text" className="w-full border border-gray-200 rounded-lg px-3 py-2.5"
                          value={formData.tags} onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                          placeholder="e.g., innovation, growth" />
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end gap-3 mt-6 pt-6 border-t">
                    <Button variant="outline" onClick={closeCreateModal}>Cancel</Button>
                    <Button onClick={handleCreateIdea} disabled={submitting}>
                      {submitting ? 'Sharing...' : 'Share Idea'}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Detail Modal */}
          {showDetailModal && selectedIdea && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(selectedIdea.status)}`}>
                        {selectedIdea.status.replace('_', ' ')}
                      </span>
                      <select
                        className="text-xs border rounded-lg px-2 py-1"
                        value={selectedIdea.status}
                        onChange={(e) => handleStatusChange(selectedIdea._id, e.target.value)}
                        onClick={(e) => e.stopPropagation()}
                      >
                        <option value="open">Open</option>
                        <option value="in_progress">In Progress</option>
                        <option value="implemented">Implemented</option>
                      </select>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => handleDeleteIdea(selectedIdea._id)}
                        className="px-3 py-1 text-sm text-red-600 hover:bg-red-50 rounded-lg">Delete</button>
                      <button onClick={() => setShowDetailModal(false)}
                        className="p-2 hover:bg-gray-100 rounded-lg"><X className="h-5 w-5" /></button>
                    </div>
                  </div>

                  <h2 className="text-xl font-bold text-gray-900 mb-2">{selectedIdea.title}</h2>
                  <p className="text-sm text-gray-500 mb-4">
                    Posted by {selectedIdea.postedBy?.name || 'Unknown'} on {new Date(selectedIdea.createdAt).toLocaleDateString()}
                  </p>
                  <p className="text-gray-700 mb-6 whitespace-pre-wrap">{selectedIdea.description}</p>

                  {/* Reactions */}
                  <div className="flex items-center gap-3 mb-6 pb-6 border-b">
                    {reactionButtons.map(({ type, icon: Icon, color, activeColor }) => {
                      const count = getReactionCount(selectedIdea, type);
                      const userReaction = getUserReaction(selectedIdea);
                      const isActive = userReaction?.type === type;
                      return (
                        <button key={type}
                          onClick={() => handleReaction(selectedIdea._id, type)}
                          className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-sm border transition-colors ${isActive ? `${activeColor} border-current bg-gray-50` : 'border-gray-200 text-gray-500'} ${color}`}>
                          <Icon className="h-4 w-4" />
                          <span>{count}</span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Comments */}
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-4">Comments ({selectedIdea.comments?.length || 0})</h3>
                    <div className="space-y-3 mb-4 max-h-64 overflow-y-auto">
                      {selectedIdea.comments?.map((comment) => (
                        <div key={comment._id} className="bg-gray-50 rounded-lg p-3">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-gray-900">
                              {comment.userId?.name || 'Unknown'}
                            </span>
                            <span className="text-xs text-gray-400">
                              {new Date(comment.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600">{comment.content}</p>
                        </div>
                      ))}
                      {(!selectedIdea.comments || selectedIdea.comments.length === 0) && (
                        <p className="text-sm text-gray-400 text-center py-4">No comments yet. Be the first!</p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        className="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="Write a comment..."
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAddComment()}
                      />
                      <Button size="sm" onClick={handleAddComment} disabled={submitting || !commentText.trim()}>
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedPage>
  );
}
