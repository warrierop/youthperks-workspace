'use client';

import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Plus, Search, Users, Edit, Trash2, Shield, ShieldOff, Key, X, Save, Check, Settings, RotateCcw } from 'lucide-react';
import { ProtectedPage } from '@/components/auth/ProtectedPage';

interface Permission {
  page: string;
  canView: boolean;
  canCreate: boolean;
  canEdit: boolean;
  canDelete: boolean;
}

interface User {
  _id: string;
  name: string;
  email: string;
  role: 'super_admin' | 'admin' | 'executive' | 'staff_level3' | 'staff_level2' | 'staff_level1' | 'support';
  rank?: string;
  department?: string;
  isActive: boolean;
  permissions: Permission[];
  phone?: string;
  bio?: string;
  lastLogin?: string;
  createdAt: string;
}

const availablePages = [
  { key: 'dashboard', label: 'Dashboard' },
  { key: 'tasks', label: 'Tasks' },
  { key: 'documents', label: 'Documents' },
  { key: 'reports', label: 'Reports' },
  { key: 'brands', label: 'Brands' },
  { key: 'budget', label: 'Budget' },
  { key: 'polls', label: 'Polls' },
  { key: 'announcements', label: 'Announcements' },
  { key: 'ideas', label: 'Ideas' },
  { key: 'team', label: 'Team' },
  { key: 'settings', label: 'Settings' },
];

const roleOptions = [
  { value: 'super_admin', label: 'CEO / Super Admin' },
  { value: 'admin', label: 'COO / CTO / Admin' },
  { value: 'executive', label: 'Executive' },
  { value: 'staff_level3', label: 'Staff Level 3 (Senior)' },
  { value: 'staff_level2', label: 'Staff Level 2 (Mid)' },
  { value: 'staff_level1', label: 'Staff Level 1 (Junior)' },
  { value: 'support', label: 'Support Team' },
  { value: 'client', label: 'Client / Brand Manager' },  
];

export default function TeamPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [showModal, setShowModal] = useState(false);
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [permissionUser, setPermissionUser] = useState<User | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    name: '', email: '', password: '', role: 'staff_level1' as string,
    rank: '', department: '', phone: '',
  });

  const [editPermissions, setEditPermissions] = useState<Permission[]>([]);

  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

  useEffect(() => { fetchUsers(); }, []);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
  };

  const fetchUsers = async () => {
    try {
      const res = await fetch(`${API_URL}/api/users`, { headers: getAuthHeaders() });
      if (res.ok) setUsers(await res.json());
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const handleCreateUser = async () => {
    if (!formData.name || !formData.email || !formData.password) {
      setError('Name, email, and password are required'); return;
    }
    if (formData.password.length < 8) {
      setError('Password must be at least 8 characters'); return;
    }
    setSubmitting(true); setError('');
    try {
      const res = await fetch(`${API_URL}/api/users`, {
        method: 'POST', headers: getAuthHeaders(),
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        const data = await res.json();
        setUsers([data, ...users]);
        closeModal();
        setSuccess('User created successfully!');
        setTimeout(() => setSuccess(''), 3000);
      } else {
        const d = await res.json();
        setError(d.message || 'Failed to create user');
      }
    } catch { setError('Failed to create user'); }
    finally { setSubmitting(false); }
  };

  const handleUpdateUser = async () => {
    if (!editingUser) return;
    setSubmitting(true); setError('');
    try {
      const body: any = { ...formData };
      if (!body.password) delete body.password;

      const res = await fetch(`${API_URL}/api/users/${editingUser._id}`, {
        method: 'PUT', headers: getAuthHeaders(), body: JSON.stringify(body),
      });
      if (res.ok) {
        const data = await res.json();
        setUsers(users.map(u => u._id === data._id ? data : u));
        closeModal();
        setSuccess('User updated successfully!');
        setTimeout(() => setSuccess(''), 3000);
      } else {
        const d = await res.json();
        setError(d.message || 'Failed to update user');
      }
    } catch { setError('Failed to update user'); }
    finally { setSubmitting(false); }
  };

  const handleToggleStatus = async (user: User) => {
    try {
      const res = await fetch(`${API_URL}/api/users/${user._id}/toggle-status`, {
        method: 'PUT', headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setUsers(users.map(u => u._id === user._id ? { ...u, isActive: data.isActive } : u));
        setSuccess(data.message);
        setTimeout(() => setSuccess(''), 2000);
      }
    } catch { setError('Failed to toggle status'); }
  };

  const handleSavePermissions = async () => {
    if (!permissionUser) return;
    setSubmitting(true);
    try {
      const res = await fetch(`${API_URL}/api/users/${permissionUser._id}/permissions`, {
        method: 'PUT', headers: getAuthHeaders(),
        body: JSON.stringify({ permissions: editPermissions }),
      });
      if (res.ok) {
        const data = await res.json();
        setUsers(users.map(u => u._id === data._id ? data : u));
        setShowPermissionModal(false);
        setSuccess('Permissions updated!');
        setTimeout(() => setSuccess(''), 2000);
      }
    } catch { setError('Failed to update permissions'); }
    finally { setSubmitting(false); }
  };

  const handleResetPermissions = async (user: User) => {
    if (!confirm(`Reset permissions for ${user.name} to role defaults?`)) return;
    try {
      const res = await fetch(`${API_URL}/api/users/${user._id}/reset-permissions`, {
        method: 'PUT', headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setUsers(users.map(u => u._id === data.user._id ? data.user : u));
        setSuccess('Permissions reset to defaults!');
        setTimeout(() => setSuccess(''), 2000);
      }
    } catch { setError('Failed to reset permissions'); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) return;
    try {
      await fetch(`${API_URL}/api/users/${id}`, { method: 'DELETE', headers: getAuthHeaders() });
      setUsers(users.filter(u => u._id !== id));
      setSuccess('User deleted successfully!');
      setTimeout(() => setSuccess(''), 3000);
    } catch { setError('Failed to delete user'); }
  };

  const openEditModal = (user: User) => {
    setEditingUser(user);
    setFormData({
      name: user.name, email: user.email, password: '',
      role: user.role, rank: user.rank || '', department: user.department || '',
      phone: user.phone || '',
    });
    setShowModal(true);
  };

  const openPermissionModal = (user: User) => {
    setPermissionUser(user);
    const merged = availablePages.map(page => {
      const existing = user.permissions?.find(p => p.page === page.key);
      return existing || { page: page.key, canView: false, canCreate: false, canEdit: false, canDelete: false };
    });
    setEditPermissions(merged);
    setShowPermissionModal(true);
  };

  const updatePermission = (pageKey: string, field: keyof Permission, value: boolean) => {
    setEditPermissions(prev => prev.map(p =>
      p.page === pageKey ? { ...p, [field]: value, ...(field === 'canView' && !value ? { canCreate: false, canEdit: false, canDelete: false } : {}) } : p
    ));
  };

  const closeModal = () => {
    setShowModal(false); setEditingUser(null); setError('');
    setFormData({ name: '', email: '', password: '', role: 'staff_level1', rank: '', department: '', phone: '' });
  };

  const getRoleColor = (role: string) => {
    const c: Record<string, string> = {
      super_admin: 'bg-red-100 text-red-700 border-red-300 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800',
      admin: 'bg-purple-100 text-purple-700 border-purple-300 dark:bg-purple-900/30 dark:text-purple-400 dark:border-purple-800',
      executive: 'bg-indigo-100 text-indigo-700 border-indigo-300 dark:bg-indigo-900/30 dark:text-indigo-400 dark:border-indigo-800',
      staff_level3: 'bg-blue-100 text-blue-700 border-blue-300 dark:bg-blue-900/30 dark:text-blue-400 dark:border-blue-800',
      staff_level2: 'bg-teal-100 text-teal-700 border-teal-300 dark:bg-teal-900/30 dark:text-teal-400 dark:border-teal-800',
      staff_level1: 'bg-green-100 text-green-700 border-green-300 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800',
      support: 'bg-orange-100 text-orange-700 border-orange-300 dark:bg-orange-900/30 dark:text-orange-400 dark:border-orange-800',
    };
    return c[role] || 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400';
  };

  const getRoleLabel = (role: string) => {
    const option = roleOptions.find(r => r.value === role);
    return option?.label || role;
  };

  const filteredUsers = users.filter(u => {
    const ms = u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase());
    return ms && (roleFilter === 'all' || u.role === roleFilter);
  });

  if (loading) {
    return (
      <ProtectedPage page="team">
        <DashboardLayout>
          <div className="flex justify-center h-64 items-center">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto"></div>
              <p className="mt-4 text-gray-500 dark:text-gray-400 font-medium">Loading team members...</p>
            </div>
          </div>
        </DashboardLayout>
      </ProtectedPage>
    );
  }

  return (
    <ProtectedPage page="team">
      <DashboardLayout>
        <div className="p-4 lg:p-8 space-y-6">
          {/* Success/Error Messages */}
          {success && (
            <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400 px-4 py-3 rounded-lg font-semibold flex items-center gap-2">
              <Check className="h-5 w-5" /> {success}
            </div>
          )}
          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 px-4 py-3 rounded-lg font-semibold flex items-center gap-2">
              <X className="h-5 w-5" /> {error}
            </div>
          )}

          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-xl lg:text-3xl font-bold text-gray-900 dark:text-black">Team Management</h1>
              <p className="text-gray-500 dark:text-gray-400 mt-1">Manage users, roles, and permissions</p>
            </div>
            <button
              onClick={() => { closeModal(); setShowModal(true); }}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg shadow-sm transition-colors whitespace-nowrap"
            >
              <Plus className="h-4 w-4" /> Add User
            </button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
            {[
              { label: 'Total Users', value: users.length, icon: Users, color: 'bg-blue-500' },
              { label: 'Active', value: users.filter(u => u.isActive).length, icon: Shield, color: 'bg-green-500' },
              { label: 'Management', value: users.filter(u => ['super_admin', 'admin', 'executive'].includes(u.role)).length, icon: Key, color: 'bg-purple-500' },
              { label: 'Staff', value: users.filter(u => ['staff_level3', 'staff_level2', 'staff_level1'].includes(u.role)).length, icon: Users, color: 'bg-orange-500' },
            ].map(s => (
              <div key={s.label} className="bg-white dark:bg-gray-900 rounded-xl shadow-sm border border-gray-200 dark:border-gray-800 p-4">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${s.color}`}>
                    <s.icon className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xl font-bold text-gray-900 dark:text-white">{s.value}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">{s.label}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Filters */}
          <div className="bg-white dark:bg-gray-900 rounded-xl shadow-sm border border-gray-200 dark:border-gray-800 p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 dark:text-gray-500" />
                <input
                  type="text"
                  placeholder="Search users by name, email, or department..."
                  className="w-full pl-10 pr-4 py-2.5 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                />
              </div>
              <select
                className="px-4 py-2.5 border border-gray-300 dark:border-gray-700 rounded-lg font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                value={roleFilter}
                onChange={e => setRoleFilter(e.target.value)}
              >
                <option value="all">All Roles</option>
                {roleOptions.map(r => (
                  <option key={r.value} value={r.value}>{r.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Users Table */}
          <div className="p-4 lg:p-6 bg-white dark:bg-gray-900 rounded-xl shadow-sm border border-gray-200 dark:border-gray-800 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-800">
                <thead className="bg-gray-50 dark:bg-gray-800/50">
                  <tr>
                    <th className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">User</th>
                    <th className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Role</th>
                    <th className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Department</th>
                    <th className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Last Login</th>
                    <th className="px-6 py-3.5 text-right text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 dark:divide-gray-800">
                  {filteredUsers.map(user => (
                    <tr key={user._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center shrink-0">
                            <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400">
                              {user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
                            </span>
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-gray-900 dark:text-white">{user.name}</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{user.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex px-2.5 py-1 text-xs font-semibold rounded-full border ${getRoleColor(user.role)}`}>
                          {getRoleLabel(user.role)}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-700 dark:text-gray-300">
                        {user.department || '—'}
                      </td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => handleToggleStatus(user)}
                          className={`inline-flex px-2.5 py-1 text-xs font-semibold rounded-full border transition-colors ${user.isActive
                            ? 'bg-green-100 text-green-700 border-green-300 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800 dark:hover:bg-green-900/50'
                            : 'bg-red-100 text-red-700 border-red-300 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800 dark:hover:bg-red-900/50'
                            }`}
                        >
                          {user.isActive ? 'Active' : 'Inactive'}
                        </button>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">
                        {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Never'}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => openPermissionModal(user)}
                            className="p-2 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
                            title="Edit Permissions"
                          >
                            <Settings className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleResetPermissions(user)}
                            className="p-2 text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-900/20 rounded-lg transition-colors"
                            title="Reset Permissions to Default"
                          >
                            <RotateCcw className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => openEditModal(user)}
                            className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                            title="Edit User"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(user._id)}
                            className="p-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                            title="Delete User"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {filteredUsers.length === 0 && (
              <div className="text-center py-16">
                <Users className="mx-auto h-12 w-12 text-gray-300 dark:text-gray-600" />
                <h3 className="mt-4 text-lg font-semibold text-gray-900 dark:text-white">No users found</h3>
                <p className="text-gray-500 dark:text-gray-400 mt-1">
                  {searchTerm ? 'Try adjusting your search or filters.' : 'Get started by adding a new team member.'}
                </p>
                <button
                  onClick={() => { closeModal(); setShowModal(true); }}
                  className="mt-4 inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg shadow-sm transition-colors"
                >
                  <Plus className="h-4 w-4" /> Add User
                </button>
              </div>
            )}
          </div>

          {/* Create/Edit User Modal */}
          {showModal && (
            <div className="fixed inset-0 bg-black/60 dark:bg-black/80 flex items-center justify-center z-50 p-4">
              <div className="bg-white dark:bg-gray-900 rounded-xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto border border-gray-200 dark:border-gray-800">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                      {editingUser ? 'Edit User' : 'Create New User'}
                    </h2>
                    <button onClick={closeModal} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg text-gray-500 dark:text-gray-400 transition-colors">
                      <X className="h-5 w-5" />
                    </button>
                  </div>

                  {error && (
                    <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 px-4 py-3 rounded-lg mb-4 text-sm font-medium">
                      {error}
                    </div>
                  )}

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Full Name *</label>
                      <input
                        type="text"
                        className="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2.5 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        value={formData.name}
                        onChange={e => setFormData({ ...formData, name: e.target.value })}
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Email Address *</label>
                      <input
                        type="email"
                        className="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2.5 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        value={formData.email}
                        onChange={e => setFormData({ ...formData, email: e.target.value })}
                        placeholder="john@youthperks.com"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">
                        Password {editingUser ? '(leave blank to keep current)' : '*'}
                      </label>
                      <input
                        type="password"
                        className="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2.5 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        value={formData.password}
                        onChange={e => setFormData({ ...formData, password: e.target.value })}
                        placeholder={editingUser ? '••••••••' : 'Min 8 characters'}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Role *</label>
                        <select
                          className="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2.5 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          value={formData.role}
                          onChange={e => setFormData({ ...formData, role: e.target.value })}
                        >
                          {roleOptions.map(r => (
                            <option key={r.value} value={r.value}>{r.label}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Department</label>
                        <input
                          type="text"
                          className="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2.5 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          value={formData.department}
                          onChange={e => setFormData({ ...formData, department: e.target.value })}
                          placeholder="e.g., Engineering"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Rank / Title</label>
                        <input
                          type="text"
                          className="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2.5 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          value={formData.rank}
                          onChange={e => setFormData({ ...formData, rank: e.target.value })}
                          placeholder="e.g., Senior Developer"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Phone</label>
                        <input
                          type="text"
                          className="w-full border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2.5 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          value={formData.phone}
                          onChange={e => setFormData({ ...formData, phone: e.target.value })}
                          placeholder="+1 (555) 000-0000"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-gray-200 dark:border-gray-800">
                    <button
                      onClick={closeModal}
                      className="px-4 py-2.5 border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={editingUser ? handleUpdateUser : handleCreateUser}
                      disabled={submitting}
                      className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-2"
                    >
                      {submitting ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          Saving...
                        </>
                      ) : editingUser ? 'Update User' : 'Create User'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Permissions Modal */}
          {showPermissionModal && permissionUser && (
            <div className="fixed inset-0 bg-black/60 dark:bg-black/80 flex items-center justify-center z-50 p-4">
              <div className="bg-white dark:bg-gray-900 rounded-xl shadow-2xl max-w-3xl w-full max-h-[85vh] overflow-y-auto border border-gray-200 dark:border-gray-800">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                        Permissions: {permissionUser.name}
                      </h2>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {permissionUser.email} • <span className="capitalize">{getRoleLabel(permissionUser.role)}</span>
                      </p>
                    </div>
                    <button
                      onClick={() => setShowPermissionModal(false)}
                      className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg text-gray-500 dark:text-gray-400 transition-colors"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b border-gray-200 dark:border-gray-800">
                          <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700 dark:text-gray-300">Page</th>
                          <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700 dark:text-gray-300">View</th>
                          <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700 dark:text-gray-300">Create</th>
                          <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700 dark:text-gray-300">Edit</th>
                          <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700 dark:text-gray-300">Delete</th>
                        </tr>
                      </thead>
                      <tbody>
                        {editPermissions.map(perm => (
                          <tr key={perm.page} className="border-b border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors">
                            <td className="py-3 px-4 text-sm font-semibold text-gray-900 dark:text-white capitalize">
                              {availablePages.find(p => p.key === perm.page)?.label || perm.page}
                            </td>
                            {(['canView', 'canCreate', 'canEdit', 'canDelete'] as const).map(field => (
                              <td key={field} className="py-3 px-4 text-center">
                                <button
                                  onClick={() => updatePermission(perm.page, field, !perm[field])}
                                  disabled={field !== 'canView' && !perm.canView}
                                  className={`p-2 rounded-lg transition-all ${perm[field]
                                    ? 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 shadow-sm'
                                    : 'bg-gray-100 dark:bg-gray-800 text-gray-400 dark:text-gray-600 hover:bg-gray-200 dark:hover:bg-gray-700'
                                    } disabled:opacity-30 disabled:cursor-not-allowed`}
                                  title={`${perm[field] ? 'Revoke' : 'Grant'} ${field.replace('can', '')} permission`}
                                >
                                  {perm[field] ? (
                                    <Check className="h-4 w-4" />
                                  ) : (
                                    <X className="h-4 w-4" />
                                  )}
                                </button>
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="flex items-center justify-between mt-6 pt-6 border-t border-gray-200 dark:border-gray-800">
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Disabling <strong>View</strong> hides all other permissions for that page.
                    </p>
                    <div className="flex gap-3">
                      <button
                        onClick={() => setShowPermissionModal(false)}
                        className="px-4 py-2.5 border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleSavePermissions}
                        disabled={submitting}
                        className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-2"
                      >
                        {submitting ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="h-4 w-4" /> Save Permissions
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedPage>
  );
}