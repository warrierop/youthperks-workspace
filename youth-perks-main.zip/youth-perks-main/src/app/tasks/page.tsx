'use client';

import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { useAuth } from '@/hooks/useAuth';
import {
  Plus, Search, CheckSquare, Clock, AlertCircle, Edit, Trash2,
  X, Calendar, User, Users, ChevronRight, Filter, SlidersHorizontal,
  ArrowUp, ArrowDown, GripVertical, MoreHorizontal, LayoutList,
  CheckCircle2, Circle, Timer, Flag, Tag
} from 'lucide-react';

// --------------- TYPES ---------------
interface AssignedUser {
  _id: string; name: string; email: string; role: string; department?: string;
}
interface Task {
  _id: string; title: string; description: string;
  assignedTo: AssignedUser[]; assignedBy: AssignedUser;
  dueDate?: string; priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  type: string; category: string; tags: string[];
  fileUrl?: string; completionNote?: string;
  completedAt?: string; completedBy?: AssignedUser; createdAt: string;
}
interface AvailableUser {
  _id: string; name: string; email: string; role: string; department?: string;
}

// --------------- CONSTANTS ---------------
const STATUS_OPTIONS = [
  { value: 'pending', label: 'Pending', icon: Circle, color: 'text-slate-400', bg: 'bg-slate-50 border-slate-200', dot: 'bg-slate-400' },
  { value: 'in_progress', label: 'In Progress', icon: Timer, color: 'text-amber-600', bg: 'bg-amber-50 border-amber-200', dot: 'bg-amber-500' },
  { value: 'completed', label: 'Completed', icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50 border-emerald-200', dot: 'bg-emerald-500' },
  { value: 'cancelled', label: 'Cancelled', icon: X, color: 'text-red-500', bg: 'bg-red-50 border-red-200', dot: 'bg-red-400' },
] as const;

const PRIORITY_OPTIONS = [
  { value: 'low', label: 'Low', color: 'text-slate-600 bg-slate-100' },
  { value: 'medium', label: 'Medium', color: 'text-blue-600 bg-blue-50' },
  { value: 'high', label: 'High', color: 'text-orange-600 bg-orange-50' },
  { value: 'urgent', label: 'Urgent', color: 'text-red-600 bg-red-50' },
] as const;

const TYPE_OPTIONS = ['simple_completion', 'file_submission', 'form_submission', 'review', 'meeting', 'other'] as const;
const CATEGORY_OPTIONS = ['general', 'marketing', 'sales', 'operations', 'finance', 'hr', 'technology', 'brands', 'content'] as const;

// --------------- COMPONENT ---------------
export default function TasksPage() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [availableUsers, setAvailableUsers] = useState<AvailableUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [showMyTasks, setShowMyTasks] = useState(false);

  const [showModal, setShowModal] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    title: '', description: '', assignedTo: [] as string[],
    dueDate: '', priority: 'medium' as string, type: 'simple_completion' as string,
    category: 'general' as string, tags: '',
  });

  const { user, canCreate, canEdit, canDelete } = useAuth();
  const isAdmin = user?.role === 'super_admin' || user?.role === 'admin';
  const isExecutive = user?.role === 'executive';
  const canAssign = isAdmin || isExecutive;
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

  // --------------- HELPERS ---------------
  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
  };

  const fetchTasks = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchTerm) params.append('search', searchTerm);
      if (statusFilter !== 'all') params.append('status', statusFilter);
      if (priorityFilter !== 'all') params.append('priority', priorityFilter);
      if (showMyTasks) params.append('assignedTo', user?.id || '');
      const res = await fetch(`${API_URL}/api/tasks?${params}`, { headers: getAuthHeaders() });
      if (res.ok) setTasks(await res.json());
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

const fetchAvailableUsers = async () => {
  if (!canAssign) return;
  try {
    const token = localStorage.getItem('token');
    
    if (!token) {
      console.error('No token found in localStorage');
      return;
    }
    
    console.log('Fetching available users with token:', token.substring(0, 20) + '...');
    
    const res = await fetch(`${API_URL}/api/tasks/users/available`, { 
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      }
    });
    
    if (res.ok) {
      const data = await res.json();
      console.log('✅ Available users loaded:', data.length);
      setAvailableUsers(data);
    } else {
      const errorData = await res.json();
      console.error('❌ Failed to fetch users:', res.status, errorData);
      
      // If unauthorized, redirect to login
      if (res.status === 401) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
      }
    }
  } catch (e) { 
    console.error('❌ Network error fetching users:', e); 
  }
};

  useEffect(() => { fetchTasks(); fetchAvailableUsers(); }, [searchTerm, statusFilter, priorityFilter, showMyTasks]);

  const handleSubmit = async () => {
    if (!formData.title || !formData.description) { setError('Title and description are required.'); return; }
    setSubmitting(true); setError('');
    try {
      const url = editingTask ? `${API_URL}/api/tasks/${editingTask._id}` : `${API_URL}/api/tasks`;
      const method = editingTask ? 'PUT' : 'POST';
      const body = { ...formData, tags: formData.tags ? formData.tags.split(',').map(t => t.trim()).filter(Boolean) : [] };
      const res = await fetch(url, { method, headers: getAuthHeaders(), body: JSON.stringify(body) });
      if (res.ok) { fetchTasks(); closeModal(); setSuccess(editingTask ? 'Task updated.' : 'Task created.'); setTimeout(() => setSuccess(''), 2500); }
      else { const d = await res.json(); setError(d.message || 'Something went wrong.'); }
    } catch { setError('Network error.'); } finally { setSubmitting(false); }
  };

  const handleQuickStatus = async (taskId: string, newStatus: string) => {
    try {
      await fetch(`${API_URL}/api/tasks/${taskId}/status`, { method: 'PUT', headers: getAuthHeaders(), body: JSON.stringify({ status: newStatus }) });
      fetchTasks();
    } catch { setError('Failed to update status.'); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Permanently delete this task?')) return;
    try { await fetch(`${API_URL}/api/tasks/${id}`, { method: 'DELETE', headers: getAuthHeaders() }); fetchTasks(); setSuccess('Task deleted.'); setTimeout(() => setSuccess(''), 2500); }
    catch { setError('Failed to delete task.'); }
  };

  const openEditModal = (task: Task) => {
    setEditingTask(task);
    setFormData({
      title: task.title, description: task.description,
      assignedTo: task.assignedTo.map(a => a._id),
      dueDate: task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : '',
      priority: task.priority, type: task.type, category: task.category || 'general',
      tags: task.tags?.join(', ') || '',
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false); setEditingTask(null); setError('');
    setFormData({ title: '', description: '', assignedTo: [], dueDate: '', priority: 'medium', type: 'simple_completion', category: 'general', tags: '' });
  };

  const toggleUserAssignment = (userId: string) => {
    setFormData(prev => ({ ...prev, assignedTo: prev.assignedTo.includes(userId) ? prev.assignedTo.filter(id => id !== userId) : [...prev.assignedTo, userId] }));
  };

  // --------------- COMPUTED ---------------
  const counts = {
    all: tasks.length,
    pending: tasks.filter(t => t.status === 'pending').length,
    in_progress: tasks.filter(t => t.status === 'in_progress').length,
    completed: tasks.filter(t => t.status === 'completed').length,
    cancelled: tasks.filter(t => t.status === 'cancelled').length,
    overdue: tasks.filter(t => t.dueDate && new Date(t.dueDate) < new Date() && t.status !== 'completed').length,
  };

  const getPriorityStyle = (p: string) => PRIORITY_OPTIONS.find(o => o.value === p)?.color || '';
  const getStatusStyle = (s: string) => STATUS_OPTIONS.find(o => o.value === s);

  // --------------- RENDER ---------------
  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-96">
          <div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-600 border-t-transparent" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        {/* Toast Messages */}
        {success && (
          <div className="fixed top-6 right-6 z-50 bg-white border border-emerald-200 shadow-lg rounded-xl px-5 py-3 flex items-center gap-3 animate-slide-in">
            <CheckCircle2 className="h-5 w-5 text-emerald-500" />
            <span className="text-sm font-medium text-emerald-800">{success}</span>
          </div>
        )}
        {error && (
          <div className="fixed top-6 right-6 z-50 bg-white border border-red-200 shadow-lg rounded-xl px-5 py-3 flex items-center gap-3 animate-slide-in">
            <AlertCircle className="h-5 w-5 text-red-500" />
            <span className="text-sm font-medium text-red-800">{error}</span>
          </div>
        )}

        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-5">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-gray-900">Tasks</h1>
            <div className="flex items-center gap-3 mt-1.5">
              <p className="text-sm text-gray-500">
                {counts.all} task{counts.all !== 1 ? 's' : ''} total
              </p>
              {counts.overdue > 0 && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-50 text-red-700 text-xs font-medium">
                  <AlertCircle className="h-3 w-3" /> {counts.overdue} overdue
                </span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowMyTasks(!showMyTasks)}
              className={`px-4 py-2 text-sm font-medium rounded-xl border transition-all duration-200 ${
                showMyTasks
                  ? 'bg-indigo-50 border-indigo-200 text-indigo-700 shadow-sm'
                  : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
              }`}
            >
              {showMyTasks ? 'My Tasks' : 'All Tasks'}
            </button>
            {canCreate('tasks') && (
// When opening create modal
<button 
  onClick={() => { 
    closeModal(); 
    fetchAvailableUsers(); // ✅ Fetch users when opening modal
    setShowModal(true); 
  }}
  className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white text-sm font-semibold rounded-xl shadow-sm hover:bg-indigo-700 transition-colors"
>
  <Plus className="h-4 w-4" /> New Task
</button>
            )}
          </div>
        </div>

        {/* Status Pipeline */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {STATUS_OPTIONS.map(s => {
            const count = counts[s.value as keyof typeof counts] || 0;
            const isActive = statusFilter === s.value;
            return (
              <button
                key={s.value}
                onClick={() => setStatusFilter(isActive ? 'all' : s.value)}
                className={`relative flex flex-col p-4 rounded-xl border-2 transition-all duration-200 text-left ${
                  isActive ? `${s.bg} border-indigo-400 shadow-md scale-[1.02]` : 'bg-white border-gray-100 hover:border-gray-200 hover:shadow-sm'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <s.icon className={`h-5 w-5 ${s.color}`} />
                  {isActive && <CheckCircle2 className="h-4 w-4 text-indigo-500" />}
                </div>
                <span className="text-2xl font-bold text-gray-900">{count}</span>
                <span className="text-sm text-gray-500 mt-0.5">{s.label}</span>
              </button>
            );
          })}
        </div>

        {/* Search & Filters Bar */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search tasks by title or description..."
                className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>
            <select
              value={priorityFilter}
              onChange={e => setPriorityFilter(e.target.value)}
              className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Priorities</option>
              {PRIORITY_OPTIONS.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
            </select>
          </div>
        </div>

        {/* Tasks Table */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
          {/* Table Header */}
          <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-3.5 bg-gray-50 border-b border-gray-100 text-xs font-semibold text-gray-500 uppercase tracking-wider">
            <div className="col-span-1">Status</div>
            <div className="col-span-4">Task</div>
            <div className="col-span-2">Assigned To</div>
            <div className="col-span-2">Due Date</div>
            <div className="col-span-2">Priority</div>
            <div className="col-span-1"></div>
          </div>

          {/* Table Body */}
          <div className="divide-y divide-gray-100">
            {tasks.map(task => {
              const statusStyle = getStatusStyle(task.status);
              const StatusIcon = statusStyle?.icon || Circle;
              return (
                <div
                  key={task._id}
                  className="grid grid-cols-1 md:grid-cols-12 gap-3 md:gap-4 px-6 py-4 items-center hover:bg-gray-50/50 transition-colors group"
                >
                  {/* Status */}
                  <div className="md:col-span-1 flex items-center gap-2">
                    <select
                      value={task.status}
                      onChange={e => handleQuickStatus(task._id, e.target.value)}
                      className={`text-xs font-semibold rounded-lg px-2 py-1.5 border cursor-pointer focus:outline-none focus:ring-2 focus:ring-indigo-400 transition-all ${statusStyle?.bg || 'bg-gray-50'} ${statusStyle?.color || 'text-gray-600'}`}
                    >
                      {STATUS_OPTIONS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                    </select>
                  </div>

                  {/* Task Info */}
                  <div className="md:col-span-4 min-w-0">
                    <h4 className="text-sm font-semibold text-gray-900 truncate group-hover:text-indigo-600 transition-colors">
                      {task.title}
                    </h4>
                    <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{task.description}</p>
                    {task.tags && task.tags.length > 0 && (
                      <div className="flex gap-1.5 mt-1.5 flex-wrap">
                        {task.tags.map(tag => (
                          <span key={tag} className="px-2 py-0.5 text-[10px] font-medium bg-gray-100 text-gray-500 rounded-md">{tag}</span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Assigned To */}
                  <div className="md:col-span-2">
                    {task.assignedTo.length > 0 ? (
                      <div className="flex items-center gap-1.5">
                        <div className="flex -space-x-1.5">
                          {task.assignedTo.slice(0, 3).map(u => (
                            <div key={u._id} className="h-7 w-7 rounded-full bg-indigo-100 border-2 border-white flex items-center justify-center" title={u.name}>
                              <span className="text-[10px] font-bold text-indigo-600">
                                {u.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                              </span>
                            </div>
                          ))}
                          {task.assignedTo.length > 3 && (
                            <div className="h-7 w-7 rounded-full bg-gray-100 border-2 border-white flex items-center justify-center">
                              <span className="text-[10px] font-bold text-gray-500">+{task.assignedTo.length - 3}</span>
                            </div>
                          )}
                        </div>
                        <span className="text-xs text-gray-500 hidden lg:inline truncate max-w-[80px]">
                          {task.assignedTo.map(u => u.name.split(' ')[0]).join(', ')}
                        </span>
                      </div>
                    ) : (
                      <span className="text-xs text-gray-400 italic">Unassigned</span>
                    )}
                  </div>

                  {/* Due Date */}
                  <div className="md:col-span-2">
                    {task.dueDate ? (
                      <div className="flex items-center gap-1.5">
                        <Calendar className="h-3.5 w-3.5 text-gray-400" />
                        <span className={`text-xs font-medium ${
                          new Date(task.dueDate) < new Date() && task.status !== 'completed'
                            ? 'text-red-600'
                            : 'text-gray-600'
                        }`}>
                          {new Date(task.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          {new Date(task.dueDate) < new Date() && task.status !== 'completed' && ' ⚠'}
                        </span>
                      </div>
                    ) : (
                      <span className="text-xs text-gray-400">—</span>
                    )}
                  </div>

                  {/* Priority */}
                  <div className="md:col-span-2">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold ${getPriorityStyle(task.priority)}`}>
                      <Flag className="h-3 w-3" />
                      {task.priority}
                    </span>
                    <span className="ml-2 text-xs text-gray-400 capitalize">{task.type?.replace('_', ' ')}</span>
                  </div>

                  {/* Actions */}
                  <div className="md:col-span-1 flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {canEdit('tasks') && (
                      <button onClick={() => openEditModal(task)} className="p-1.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors" title="Edit">
                        <Edit className="h-4 w-4" />
                      </button>
                    )}
                    {canDelete('tasks') && (
                      <button onClick={() => handleDelete(task._id)} className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Delete">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Empty State */}
          {tasks.length === 0 && (
            <div className="text-center py-20">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-2xl bg-gray-100 mb-5">
                <CheckSquare className="h-8 w-8 text-gray-300" />
              </div>
              <h3 className="text-base font-semibold text-gray-900 mb-1">No tasks found</h3>
              <p className="text-sm text-gray-500 max-w-sm mx-auto">
                {showMyTasks
                  ? 'You have no pending tasks assigned to you.'
                  : 'Try adjusting your filters or create a new task.'}
              </p>
              {canCreate('tasks') && (
                <button
                  onClick={() => { closeModal(); setShowModal(true); }}
                  className="mt-5 inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white text-sm font-semibold rounded-xl shadow-sm hover:bg-indigo-700 transition-colors"
                >
                  <Plus className="h-4 w-4" /> Create First Task
                </button>
              )}
            </div>
          )}
        </div>

        {/* Create/Edit Task Modal */}
        {showModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              {/* Backdrop */}
              <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={closeModal} />
              
              {/* Modal */}
              <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border border-gray-100">
                {/* Modal Header */}
                <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 rounded-t-2xl flex items-center justify-between z-10">
                  <h2 className="text-lg font-bold text-gray-900">
                    {editingTask ? 'Edit Task' : 'Create New Task'}
                  </h2>
                  <button onClick={closeModal} className="p-2 hover:bg-gray-100 rounded-xl transition-colors text-gray-400 hover:text-gray-600">
                    <X className="h-5 w-5" />
                  </button>
                </div>

                {/* Modal Body */}
                <div className="p-6 space-y-5">
                  {error && (
                    <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm font-medium flex items-center gap-2">
                      <AlertCircle className="h-4 w-4" /> {error}
                    </div>
                  )}

                  {/* Title */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Task Title <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all bg-gray-50"
                      placeholder="e.g., Review Q4 partnership proposal"
                      value={formData.title}
                      onChange={e => setFormData({ ...formData, title: e.target.value })}
                    />
                  </div>

                  {/* Description */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Description <span className="text-red-500">*</span></label>
                    <textarea
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all bg-gray-50 resize-none"
                      rows={4}
                      placeholder="Describe what needs to be done..."
                      value={formData.description}
                      onChange={e => setFormData({ ...formData, description: e.target.value })}
                    />
                  </div>

                  {/* Assign Users */}
                  {canAssign && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Assign Team Members</label>
                      <div className="max-h-44 overflow-y-auto border border-gray-200 rounded-xl divide-y divide-gray-100 bg-gray-50">
                        {availableUsers.length === 0 && (
                          <p className="text-sm text-gray-400 text-center py-6">No team members available.</p>
                        )}
                        {availableUsers.map(u => {
                          const isChecked = formData.assignedTo.includes(u._id);
                          return (
                            <label
                              key={u._id}
                              className={`flex items-center gap-3 px-4 py-3 cursor-pointer transition-colors ${
                                isChecked ? 'bg-indigo-50' : 'hover:bg-white'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={() => toggleUserAssignment(u._id)}
                                className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                              />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-gray-900">{u.name}</p>
                                <p className="text-xs text-gray-500 capitalize">
                                  {u.role?.replace('_', ' ')} {u.department ? `· ${u.department}` : ''}
                                </p>
                              </div>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Grid: Priority, Type, Category, Due Date */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5">Priority</label>
                      <select
                        className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        value={formData.priority}
                        onChange={e => setFormData({ ...formData, priority: e.target.value })}
                      >
                        {PRIORITY_OPTIONS.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5">Type</label>
                      <select
                        className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        value={formData.type}
                        onChange={e => setFormData({ ...formData, type: e.target.value })}
                      >
                        {TYPE_OPTIONS.map(t => <option key={t} value={t}>{t.replace(/_/g, ' ')}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5">Category</label>
                      <select
                        className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        value={formData.category}
                        onChange={e => setFormData({ ...formData, category: e.target.value })}
                      >
                        {CATEGORY_OPTIONS.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5">Due Date</label>
                      <input
                        type="date"
                        className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        value={formData.dueDate}
                        onChange={e => setFormData({ ...formData, dueDate: e.target.value })}
                      />
                    </div>
                  </div>

                  {/* Tags */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Tags</label>
                    <input
                      type="text"
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-gray-50"
                      placeholder="marketing, urgent, q4 (comma separated)"
                      value={formData.tags}
                      onChange={e => setFormData({ ...formData, tags: e.target.value })}
                    />
                  </div>
                </div>

                {/* Modal Footer */}
                <div className="sticky bottom-0 bg-white border-t border-gray-100 px-6 py-4 rounded-b-2xl flex items-center justify-end gap-3">
                  <button
                    onClick={closeModal}
                    className="px-5 py-2.5 text-sm font-semibold text-gray-700 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSubmit}
                    disabled={submitting}
                    className="px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm flex items-center gap-2"
                  >
                    {submitting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                        Saving...
                      </>
                    ) : editingTask ? (
                      'Update Task'
                    ) : (
                      'Create Task'
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}