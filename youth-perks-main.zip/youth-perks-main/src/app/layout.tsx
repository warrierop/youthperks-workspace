// app/layout.tsx - Should be simple
import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'YouthPerks Workspace',
  description: 'Premium Internal Management System',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-gray-50">
        {children}
      </body>
    </html>
  );
}