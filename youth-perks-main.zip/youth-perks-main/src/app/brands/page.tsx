'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { useAuth } from '@/hooks/useAuth';
import {
  Plus, Search, Handshake, Edit, Trash2, Phone, Mail, Globe, 
  DollarSign, Calendar, X, Star, MapPin, Filter, ChevronDown, 
  ChevronUp, ExternalLink, TrendingUp, Briefcase, Target, 
  BarChart3, Grid, List, AlertCircle, CheckCircle, Building2,
  MessageSquare, Clock, XCircle, ArrowRight, UserPlus, BadgePercent
} from 'lucide-react';

// Types
interface FollowUp {
  _id: string;
  date: string;
  notes: string;
  outcome: string;
  createdBy: { _id: string; name: string };
  createdAt: string;
}

interface Brand {
  _id: string;
  name: string;
  description: string;
  category: string;
  city: string;
  country: string;
  industry: string;
  companySize: string;
  contactEmail?: string;
  contactPhone?: string;
  website?: string;
  status: string;
  stage: string;
  assignedTo?: { _id: string; name: string };
  notes: string;
  nextFollowUp?: string;
  value?: number;
  dealType: string;
  priority: string;
  isFavorite: boolean;
  followUps: FollowUp[];
  tags: string[];
  daysSinceLastContact: number | null;
  convertedToClientId?: string;
  createdAt: string;
}

interface FilterOptions {
  categories: string[];
  cities: string[];
  industries: string[];
  dealTypes: string[];
  tags: string[];
}

const STATUS_OPTIONS = [
  { value: 'to_pitch', label: 'To Pitch', color: 'bg-slate-100 text-slate-700 border-slate-200', dot: 'bg-slate-400' },
  { value: 'pitched', label: 'Pitched', color: 'bg-blue-50 text-blue-700 border-blue-200', dot: 'bg-blue-500' },
  { value: 'in_progress', label: 'In Progress', color: 'bg-amber-50 text-amber-700 border-amber-200', dot: 'bg-amber-500' },
  { value: 'negotiation', label: 'Negotiation', color: 'bg-purple-50 text-purple-700 border-purple-200', dot: 'bg-purple-500' },
  { value: 'closed', label: 'Closed Won', color: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' },
  { value: 'failed', label: 'Closed Lost', color: 'bg-red-50 text-red-700 border-red-200', dot: 'bg-red-500' },
];

const PRIORITY_OPTIONS = [
  { value: 'low', label: 'Low', badge: 'bg-gray-100 text-gray-600' },
  { value: 'medium', label: 'Medium', badge: 'bg-blue-100 text-blue-600' },
  { value: 'high', label: 'High', badge: 'bg-orange-100 text-orange-600' },
  { value: 'urgent', label: 'Urgent', badge: 'bg-red-100 text-red-600' },
];

export default function BrandsPage() {
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({ categories: [], cities: [], industries: [], dealTypes: [], tags: [] });

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [cityFilter, setCityFilter] = useState('all');
  const [showFavorites, setShowFavorites] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  const [showModal, setShowModal] = useState(false);
  const [showFollowUpModal, setShowFollowUpModal] = useState(false);
  const [editingBrand, setEditingBrand] = useState<Brand | null>(null);
  const [followUpBrand, setFollowUpBrand] = useState<Brand | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    name: '', description: '', category: 'Uncategorized', city: '', country: '',
    industry: '', companySize: '', contactEmail: '', contactPhone: '', website: '',
    value: '', dealType: 'partnership', priority: 'medium',
    status: 'to_pitch', stage: 'research', notes: '', tags: '',
  });

  const [followUpForm, setFollowUpForm] = useState({
    date: new Date().toISOString().split('T')[0], notes: '', outcome: 'pending',
  });

  const { canCreate, canDelete, canEdit } = useAuth();
  const router = useRouter();
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' };
  };

  const formatCurrency = (val?: number) => val ? `$${val.toLocaleString()}` : '$0';

  const fetchBrands = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchTerm) params.append('search', searchTerm);
      if (statusFilter !== 'all') params.append('status', statusFilter);
      if (categoryFilter !== 'all') params.append('category', categoryFilter);
      if (cityFilter !== 'all') params.append('city', cityFilter);
      if (showFavorites) params.append('isFavorite', 'true');
      params.append('limit', '100');

      const res = await fetch(`${API_URL}/api/brands?${params}`, { headers: getAuthHeaders() });
      if (res.ok) {
        const data = await res.json();
        setBrands(data.brands || data);
      }
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [searchTerm, statusFilter, categoryFilter, cityFilter, showFavorites]);

  const fetchFilterOptions = async () => {
    try {
      const res = await fetch(`${API_URL}/api/brands/filters/options`, { headers: getAuthHeaders() });
      if (res.ok) setFilterOptions(await res.json());
    } catch (e) { console.error(e); }
  };

  useEffect(() => { fetchBrands(); fetchFilterOptions(); }, [fetchBrands]);

  // ✅ CONVERT TO CLIENT
  const handleConvertToClient = async (brand: Brand) => {
    if (!confirm(`Convert "${brand.name}" to a Client? This will create a new client record and mark this deal as won.`)) return;
    try {
      const res = await fetch(`${API_URL}/api/brands/${brand._id}`, {
        method: 'PUT', headers: getAuthHeaders(),
        body: JSON.stringify({ status: 'closed' }),
      });
      if (res.ok) {
        const updated = await res.json();
        setBrands(brands.map(b => b._id === updated._id ? updated : b));
        setSuccess('Brand converted to Client! Redirecting...');
        setTimeout(() => {
          setSuccess('');
          if (updated.convertedToClientId) {
            router.push(`/clients/${updated.convertedToClientId}`);
          }
        }, 1500);
      }
    } catch { setError('Failed to convert'); }
  };

  const handleSubmit = async () => {
    if (!formData.name) { setError('Brand name is required'); return; }
    setSubmitting(true); setError('');
    try {
      const url = editingBrand ? `${API_URL}/api/brands/${editingBrand._id}` : `${API_URL}/api/brands`;
      const method = editingBrand ? 'PUT' : 'POST';
      const body = { ...formData, value: parseFloat(formData.value) || 0, tags: formData.tags ? formData.tags.split(',').map(t => t.trim()).filter(Boolean) : [] };
      const res = await fetch(url, { method, headers: getAuthHeaders(), body: JSON.stringify(body) });
      if (res.ok) {
        fetchBrands(); fetchFilterOptions();
        closeModal();
        setSuccess(editingBrand ? 'Brand updated!' : 'Brand added!');
        setTimeout(() => setSuccess(''), 3000);
      } else { const d = await res.json(); setError(d.message || 'Failed'); }
    } catch { setError('Failed to save'); }
    finally { setSubmitting(false); }
  };

  const handleToggleFavorite = async (brand: Brand) => {
    await fetch(`${API_URL}/api/brands/${brand._id}/toggle-favorite`, { method: 'PUT', headers: getAuthHeaders() });
    fetchBrands();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this brand?')) return;
    await fetch(`${API_URL}/api/brands/${id}`, { method: 'DELETE', headers: getAuthHeaders() });
    fetchBrands();
    setSuccess('Brand deleted!');
    setTimeout(() => setSuccess(''), 3000);
  };

  const openEditModal = (brand: Brand) => {
    setEditingBrand(brand);
    setFormData({
      name: brand.name, description: brand.description || '',
      category: brand.category || 'Uncategorized', city: brand.city || '',
      country: brand.country || '', industry: brand.industry || '',
      companySize: brand.companySize || '', contactEmail: brand.contactEmail || '',
      contactPhone: brand.contactPhone || '', website: brand.website || '',
      value: brand.value?.toString() || '', dealType: brand.dealType,
      priority: brand.priority, status: brand.status, stage: brand.stage,
      notes: brand.notes || '', tags: brand.tags?.join(', ') || '',
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false); setEditingBrand(null); setError('');
    setFormData({ name: '', description: '', category: 'Uncategorized', city: '', country: '', industry: '', companySize: '', contactEmail: '', contactPhone: '', website: '', value: '', dealType: 'partnership', priority: 'medium', status: 'to_pitch', stage: 'research', notes: '', tags: '' });
  };

  const getStatusStyle = (status: string) => STATUS_OPTIONS.find(s => s.value === status);
  const getPriorityStyle = (priority: string) => PRIORITY_OPTIONS.find(p => p.value === priority)?.badge || '';

  const totalValue = brands.reduce((s, b) => s + (b.value || 0), 0);
  const filteredBrands = brands;

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-96">
          <div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-600 border-t-transparent" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {/* Toast */}
        {success && (
          <div className="fixed top-6 right-6 z-50 bg-white border border-emerald-200 shadow-lg rounded-xl px-5 py-3 text-sm font-medium text-emerald-800 flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-emerald-500" />{success}
          </div>
        )}
        {error && (
          <div className="fixed top-6 right-6 z-50 bg-white border border-red-200 shadow-lg rounded-xl px-5 py-3 text-sm font-medium text-red-800">{error}</div>
        )}

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-gray-900">Pipeline</h1>
            <p className="text-sm text-gray-500 mt-1">{brands.length} brands • {formatCurrency(totalValue)} pipeline value</p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setShowFavorites(!showFavorites)}
              className={`p-2.5 rounded-xl border transition-all ${showFavorites ? 'bg-amber-50 border-amber-300 text-amber-600' : 'bg-white border-gray-200 text-gray-400'}`}>
              <Star className="h-5 w-5" fill={showFavorites ? 'currentColor' : 'none'} />
            </button>
            {canCreate('brands') && (
              <button onClick={() => { closeModal(); setShowModal(true); }}
                className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white text-sm font-semibold rounded-xl shadow-sm hover:bg-indigo-700 transition-colors">
                <Plus className="h-4 w-4" /> Add Brand
              </button>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Pipeline Value', value: formatCurrency(totalValue), icon: DollarSign, color: 'bg-emerald-500', sub: `${brands.length} brands` },
            { label: 'Active Deals', value: brands.filter(b => !['closed', 'failed'].includes(b.status)).length, icon: Target, color: 'bg-blue-500', sub: 'In progress' },
            { label: 'Closed Won', value: brands.filter(b => b.status === 'closed').length, icon: CheckCircle, color: 'bg-emerald-600', sub: 'Converted' },
            { label: 'Win Rate', value: `${brands.length > 0 ? Math.round((brands.filter(b => b.status === 'closed').length / brands.length) * 100) : 0}%`, icon: BarChart3, color: 'bg-purple-500', sub: 'Success rate' },
          ].map(s => (
            <div key={s.label} className="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center gap-3">
                <div className={`h-10 w-10 ${s.color} rounded-xl flex items-center justify-center`}>
                  <s.icon className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="text-xl font-bold text-gray-900">{s.value}</p>
                  <p className="text-xs text-gray-500">{s.label}</p>
                  <p className="text-[10px] text-gray-400">{s.sub}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Pipeline Stages */}
        <div className="bg-white rounded-2xl border border-gray-200 p-2">
          <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
            {STATUS_OPTIONS.map(s => {
              const count = brands.filter(b => b.status === s.value).length;
              return (
                <button key={s.value} onClick={() => setStatusFilter(statusFilter === s.value ? 'all' : s.value)}
                  className={`p-3 rounded-xl text-left transition-all ${statusFilter === s.value ? `${s.color} ring-2 ring-indigo-400 scale-[1.02]` : 'hover:bg-gray-50'}`}>
                  <p className="text-lg font-bold text-gray-900">{count}</p>
                  <p className="text-xs font-medium text-gray-500">{s.label}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Search & Filters */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input type="text" placeholder="Search brands..." className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
            </div>
            <button onClick={() => setShowFilters(!showFilters)}
              className={`px-4 py-2.5 rounded-xl text-sm font-medium border transition-all ${showFilters ? 'bg-indigo-50 border-indigo-300 text-indigo-700' : 'bg-gray-50 border-gray-200 text-gray-600'}`}>
              <Filter className="h-4 w-4 inline mr-1" /> Filters
            </button>
          </div>
          {showFilters && (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-3 pt-3 border-t border-gray-200">
              <select value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)} className="px-3 py-2 border rounded-xl text-sm bg-gray-50">
                <option value="all">All Categories</option>
                {filterOptions.categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select value={cityFilter} onChange={e => setCityFilter(e.target.value)} className="px-3 py-2 border rounded-xl text-sm bg-gray-50">
                <option value="all">All Cities</option>
                {filterOptions.cities.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          )}
        </div>

        {/* Brands Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredBrands.map(brand => {
            const statusStyle = getStatusStyle(brand.status);
            return (
              <div key={brand._id} className={`bg-white rounded-2xl border p-5 hover:shadow-lg transition-all group ${brand.isFavorite ? 'border-amber-300' : 'border-gray-200'}`}>
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2 flex-1 min-w-0">
                    <button onClick={() => handleToggleFavorite(brand)}>
                      <Star className={`h-4 w-4 ${brand.isFavorite ? 'text-amber-500 fill-amber-500' : 'text-gray-300'}`} />
                    </button>
                    <div className="min-w-0">
                      <h3 className="font-semibold text-gray-900 truncate">{brand.name}</h3>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        {brand.category && brand.category !== 'Uncategorized' && (
                          <span className="text-xs bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full">{brand.category}</span>
                        )}
                        {brand.city && <span className="text-xs text-gray-500 flex items-center gap-0.5"><MapPin className="h-3 w-3" />{brand.city}</span>}
                      </div>
                    </div>
                  </div>
                  <span className={`px-2 py-0.5 text-xs font-semibold rounded-full border ${statusStyle?.color}`}>{statusStyle?.label}</span>
                </div>

                {/* Stage & Deal Type */}
                <div className="flex items-center gap-1.5 mb-3 flex-wrap">
                  <span className="px-2 py-0.5 text-xs rounded-full bg-gray-100 text-gray-600 capitalize">{brand.stage?.replace('_', ' ')}</span>
                  <span className="px-2 py-0.5 text-xs rounded-full bg-blue-50 text-blue-600 capitalize">{brand.dealType?.replace('_', ' ')}</span>
                  <span className={`px-2 py-0.5 text-xs rounded-full ${getPriorityStyle(brand.priority)}`}>{brand.priority}</span>
                </div>

                {/* Contact */}
                <div className="space-y-1 mb-3 text-xs text-gray-500">
                  {brand.contactEmail && <p className="flex items-center gap-1"><Mail className="h-3 w-3" />{brand.contactEmail}</p>}
                  {brand.website && <p className="flex items-center gap-1"><Globe className="h-3 w-3" />{brand.website}</p>}
                </div>

                {/* Value */}
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-bold text-gray-900">{formatCurrency(brand.value)}</span>
                  {brand.nextFollowUp && <span className="text-xs text-gray-400"><Calendar className="h-3 w-3 inline mr-1" />{new Date(brand.nextFollowUp).toLocaleDateString()}</span>}
                </div>

                {/* Converted indicator */}
                {brand.convertedToClientId && (
                  <button onClick={() => router.push(`/clients/${brand.convertedToClientId}`)}
                    className="w-full mb-3 px-3 py-2 bg-emerald-50 text-emerald-700 text-xs font-medium rounded-lg flex items-center justify-center gap-2 hover:bg-emerald-100">
                    <Building2 className="h-3.5 w-3.5" /> View Client →
                  </button>
                )}

                {/* Actions */}
                <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                  <div className="flex gap-1">
                    {brand.status !== 'closed' && brand.status !== 'failed' && (
                      <button onClick={(e) => { e.stopPropagation(); handleConvertToClient(brand); }}
                        className="px-2.5 py-1 text-xs font-semibold bg-emerald-50 text-emerald-600 rounded-lg hover:bg-emerald-100 flex items-center gap-1">
                        <UserPlus className="h-3.5 w-3.5" /> Convert
                      </button>
                    )}
                    <button onClick={(e) => { e.stopPropagation(); setFollowUpBrand(brand); setShowFollowUpModal(true); }}
                      className="px-2.5 py-1 text-xs font-semibold bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100">
                      + Follow-up
                    </button>
                  </div>
                  <div className="flex gap-1">
                    {canEdit('brands') && <button onClick={() => openEditModal(brand)} className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg"><Edit className="h-4 w-4" /></button>}
                    {canDelete('brands') && <button onClick={() => handleDelete(brand._id)} className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg"><Trash2 className="h-4 w-4" /></button>}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {filteredBrands.length === 0 && (
          <div className="text-center py-20 bg-white rounded-2xl border border-gray-200">
            <Building2 className="mx-auto h-12 w-12 text-gray-300 mb-4" />
            <h3 className="text-lg font-semibold text-gray-900">No brands in pipeline</h3>
            <p className="text-sm text-gray-500">Add your first brand partnership opportunity.</p>
          </div>
        )}

{/* Create/Edit Modal */}
{showModal && (
  <div className="fixed inset-0 z-50 overflow-y-auto">
    <div className="flex min-h-full items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={closeModal} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl border border-gray-100 max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-5 rounded-t-2xl flex items-center justify-between z-10">
          <div>
            <h2 className="text-xl font-bold text-gray-900">
              {editingBrand ? 'Edit Brand' : 'Add New Brand'}
            </h2>
            <p className="text-sm text-gray-500 mt-1">
              {editingBrand ? 'Update the brand information below' : 'Fill in the details to add a new brand partnership'}
            </p>
          </div>
          <button onClick={closeModal} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
            <X className="h-5 w-5 text-gray-400 hover:text-gray-600" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          {error && (
            <div className="flex items-center gap-3 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6">
              <AlertCircle className="h-5 w-5 flex-shrink-0" />
              <p className="text-sm font-medium">{error}</p>
            </div>
          )}

          <div className="space-y-5">
            {/* Brand Name */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Brand Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all"
                placeholder="e.g., Nike, Zomato"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Category */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Category</label>
                <input
                  type="text"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all"
                  placeholder="e.g., Food, Tech, Fashion"
                  value={formData.category}
                  onChange={e => setFormData({...formData, category: e.target.value})}
                  list="category-list"
                />
                <datalist id="category-list">
                  {filterOptions.categories.map(c => <option key={c} value={c} />)}
                </datalist>
              </div>

              {/* Industry */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Industry</label>
                <input
                  type="text"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all"
                  placeholder="e.g., E-commerce, SaaS"
                  value={formData.industry}
                  onChange={e => setFormData({...formData, industry: e.target.value})}
                />
              </div>

              {/* City */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">City</label>
                <input
                  type="text"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all"
                  placeholder="e.g., Mumbai, Delhi"
                  value={formData.city}
                  onChange={e => setFormData({...formData, city: e.target.value})}
                  list="city-list"
                />
                <datalist id="city-list">
                  {filterOptions.cities.map(c => <option key={c} value={c} />)}
                </datalist>
              </div>

              {/* Country */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Country</label>
                <input
                  type="text"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all"
                  placeholder="e.g., India, USA"
                  value={formData.country}
                  onChange={e => setFormData({...formData, country: e.target.value})}
                />
              </div>

              {/* Contact Email */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Contact Email</label>
                <input
                  type="email"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all"
                  placeholder="contact@brand.com"
                  value={formData.contactEmail}
                  onChange={e => setFormData({...formData, contactEmail: e.target.value})}
                />
              </div>

              {/* Contact Phone */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Contact Phone</label>
                <input
                  type="text"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all"
                  placeholder="+91 12345 67890"
                  value={formData.contactPhone}
                  onChange={e => setFormData({...formData, contactPhone: e.target.value})}
                />
              </div>

              {/* Website */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Website</label>
                <input
                  type="text"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all"
                  placeholder="www.brand.com"
                  value={formData.website}
                  onChange={e => setFormData({...formData, website: e.target.value})}
                />
              </div>

              {/* Deal Value */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Deal Value ($)</label>
                <div className="relative">
                  <DollarSign className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="number"
                    className="w-full border border-gray-200 rounded-xl pl-10 pr-4 py-3 text-sm bg-gray-50 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all"
                    placeholder="0"
                    value={formData.value}
                    onChange={e => setFormData({...formData, value: e.target.value})}
                  />
                </div>
              </div>

              {/* Deal Type */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Deal Type</label>
                <select
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all cursor-pointer capitalize"
                  value={formData.dealType}
                  onChange={e => setFormData({...formData, dealType: e.target.value})}
                >
                  <option value="sponsorship">Sponsorship</option>
                  <option value="partnership">Partnership</option>
                  <option value="collaboration">Collaboration</option>
                  <option value="endorsement">Endorsement</option>
                  <option value="barter">Barter</option>
                  <option value="affiliate">Affiliate</option>
                  <option value="ambassador">Ambassador</option>
                  <option value="other">Other</option>
                </select>
              </div>

              {/* Priority */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Priority</label>
                <select
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all cursor-pointer"
                  value={formData.priority}
                  onChange={e => setFormData({...formData, priority: e.target.value})}
                >
                  {PRIORITY_OPTIONS.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
                </select>
              </div>
            </div>

            {/* Tags */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Tags</label>
              <input
                type="text"
                className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all"
                placeholder="e.g., food, trending, q4 (comma separated)"
                value={formData.tags}
                onChange={e => setFormData({...formData, tags: e.target.value})}
              />
            </div>

            {/* Notes */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Notes</label>
              <textarea
                className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all resize-none"
                rows={3}
                placeholder="Any additional notes about this brand..."
                value={formData.notes}
                onChange={e => setFormData({...formData, notes: e.target.value})}
              />
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="sticky bottom-0 bg-white border-t border-gray-100 px-6 py-5 rounded-b-2xl">
          <div className="flex justify-end gap-3">
            <button
              onClick={closeModal}
              className="px-5 py-2.5 text-sm font-semibold text-gray-700 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              disabled={submitting}
              className="px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm flex items-center gap-2"
            >
              {submitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                  Saving...
                </>
              ) : editingBrand ? (
                'Update Brand'
              ) : (
                'Create Brand'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
)}

        {/* Follow-up Modal */}
        {showFollowUpModal && followUpBrand && (
          <div className="fixed inset-0 z-50 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setShowFollowUpModal(false)} />
              <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md border border-gray-100">
                <div className="px-6 py-4 border-b flex items-center justify-between">
                  <div><h2 className="text-lg font-bold">Add Follow-up</h2><p className="text-sm text-gray-500">{followUpBrand.name}</p></div>
                  <button onClick={() => setShowFollowUpModal(false)} className="p-2 hover:bg-gray-100 rounded-xl"><X className="h-5 w-5 text-gray-400" /></button>
                </div>
                <div className="p-6 space-y-4">
                  <div><label className="block text-sm font-semibold mb-1.5">Date</label><input type="date" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={followUpForm.date} onChange={e => setFollowUpForm({...followUpForm, date: e.target.value})} /></div>
                  <div><label className="block text-sm font-semibold mb-1.5">Outcome</label>
                    <div className="grid grid-cols-2 gap-2">
                      {['positive','neutral','negative','pending'].map(o => (
                        <button key={o} onClick={() => setFollowUpForm({...followUpForm, outcome: o})} className={`px-3 py-2 rounded-xl text-sm font-medium border ${followUpForm.outcome === o ? 'bg-indigo-50 border-indigo-300 text-indigo-700' : 'bg-gray-50 border-gray-200 text-gray-600'}`}>{o}</button>
                      ))}
                    </div>
                  </div>
                  <div><label className="block text-sm font-semibold mb-1.5">Notes</label><textarea className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50 resize-none" rows={3} value={followUpForm.notes} onChange={e => setFollowUpForm({...followUpForm, notes: e.target.value})} /></div>
                </div>
                <div className="px-6 py-4 border-t flex justify-end gap-3">
                  <button onClick={() => setShowFollowUpModal(false)} className="px-5 py-2.5 text-sm font-semibold text-gray-700 border rounded-xl">Cancel</button>
                  <button onClick={async () => {
                    setSubmitting(true);
                    try {
                      await fetch(`${API_URL}/api/brands/${followUpBrand._id}/followup`, { method: 'POST', headers: getAuthHeaders(), body: JSON.stringify(followUpForm) });
                      fetchBrands();
                      setShowFollowUpModal(false);
                      setSuccess('Follow-up added!');
                      setTimeout(() => setSuccess(''), 2000);
                    } catch { setError('Failed'); }
                    finally { setSubmitting(false); }
                  }} disabled={submitting} className="px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-xl">{submitting ? 'Saving...' : 'Save'}</button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}