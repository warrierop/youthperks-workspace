'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { useAuth } from '@/hooks/useAuth';
import {
  ArrowLeft, Edit, Star, MapPin, Globe, Building2, Users, Phone, Mail,
  Calendar, DollarSign, TrendingUp, Clock, FileText, Upload, Download,
  Plus, X, MessageSquare, Tag, ChevronRight, ExternalLink, CheckCircle2,
  AlertTriangle, BadgePercent, Handshake, Link, Sparkles, PartyPopper,
  FlaskConical, Tv, Trash2, Activity, BarChart3, Layers
} from 'lucide-react';

interface Contact {
  _id: string; name: string; position: string; email: string; phone: string; avatar: string; isPrimary: boolean;
}
interface Document {
  _id: string; name: string; url: string; type: string; fileSize: number; uploadedAt: string; uploadedBy?: { name: string };
}
interface Revenue {
  _id: string; amount: number; description: string; date: string; status: string;
}
interface Offer {
  _id: string; title: string; description: string; discountPercent?: number; code?: string; validFrom?: string; validUntil?: string; status: string; redemptionCount: number;
}
interface Activity {
  _id: string; action: string; description: string; performedBy?: { name: string; email: string }; createdAt: string;
}
interface Note {
  _id: string; content: string; createdBy: { name: string }; createdAt: string;
}
interface ClientDetail {
  _id: string; brandId: string; brandName: string; logo: string; description: string;
  partnerType: string; industry: string; city: string; country: string; website: string;
  accountManager?: { _id: string; name: string; email: string; role: string; avatar: string };
  accountManagerEmail: string; accountManagerSince: string;
  contacts: Contact[]; documents: Document[]; revenue: Revenue[]; offers: Offer[];
  activities: Activity[]; notes: Note[];
  dealValue: number; currency: string; paymentTerms: string;
  startDate: string; renewalDate: string; contractDuration: string;
  status: string; healthScore: string;
  performance: { revenueGenerated: number; activeCampaigns: number; totalRedemptions: number; roi: number; reach: number };
  isFavorite: boolean; convertedFromPipeline: boolean;
  createdAt: string;
}

const PARTNER_TYPES: Record<string, { label: string; icon: any; color: string; bg: string }> = {
  official_partner: { label: 'Official Partner', icon: Handshake, color: 'text-blue-600', bg: 'bg-blue-50' },
  discount_partner: { label: 'Discount Partner', icon: BadgePercent, color: 'text-green-600', bg: 'bg-green-50' },
  sponsored_brand: { label: 'Sponsored Brand', icon: DollarSign, color: 'text-purple-600', bg: 'bg-purple-50' },
  affiliate_partner: { label: 'Affiliate Partner', icon: Link, color: 'text-orange-600', bg: 'bg-orange-50' },
  ambassador_partner: { label: 'Ambassador Partner', icon: Sparkles, color: 'text-amber-600', bg: 'bg-amber-50' },
  event_partner: { label: 'Event Partner', icon: PartyPopper, color: 'text-pink-600', bg: 'bg-pink-50' },
  trial_partner: { label: 'Trial Partner', icon: FlaskConical, color: 'text-teal-600', bg: 'bg-teal-50' },
  media_partner: { label: 'Media Partner', icon: Tv, color: 'text-red-600', bg: 'bg-red-50' },
};
const STATUS: Record<string, { label: string; color: string; bg: string }> = {
  active: { label: 'Active', color: 'text-emerald-700', bg: 'bg-emerald-50' },
  trial: { label: 'Trial', color: 'text-blue-700', bg: 'bg-blue-50' },
  at_risk: { label: 'At Risk', color: 'text-amber-700', bg: 'bg-amber-50' },
  expiring: { label: 'Expiring', color: 'text-orange-700', bg: 'bg-orange-50' },
  paused: { label: 'Paused', color: 'text-gray-700', bg: 'bg-gray-50' },
  completed: { label: 'Completed', color: 'text-blue-700', bg: 'bg-blue-50' },
};

const TABS = ['Overview', 'Offers', 'Campaigns', 'Contacts', 'Activity', 'Finance', 'Docs'];

export default function ClientDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const { user, canEdit } = useAuth();
  const [client, setClient] = useState<ClientDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('Overview');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [noteText, setNoteText] = useState('');
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDocUpload, setShowDocUpload] = useState(false);
  const [showOfferModal, setShowOfferModal] = useState(false);
  const [showRevenueModal, setShowRevenueModal] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [editForm, setEditForm] = useState<any>({});
  const [offerForm, setOfferForm] = useState({ title: '', description: '', discountPercent: '', code: '', validFrom: '', validUntil: '', status: 'draft' });
  const [revenueForm, setRevenueForm] = useState({ amount: '', description: '', status: 'pending', date: new Date().toISOString().split('T')[0] });

  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';
  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';

  useEffect(() => { fetchClient(); }, [id]);

  const getAuthHeaders = (isFormData = false) => {
    const token = localStorage.getItem('token');
    const h: Record<string, string> = { Authorization: `Bearer ${token}` };
    if (!isFormData) h['Content-Type'] = 'application/json';
    return h;
  };

const fetchClient = async () => {
  try {
    const res = await fetch(`${API_URL}/api/clients/${id}`, { headers: getAuthHeaders() });
    
    if (res.status === 404) {
      console.log('Client not found, redirecting...');
      router.push('/clients');
      return;
    }
    
    if (res.status === 403) {
      console.log('Not authorized');
      setError('You do not have access to this client');
      setLoading(false);
      return;
    }
    
    if (!res.ok) {
      throw new Error(`Failed with status ${res.status}`);
    }
    
    const data = await res.json();
    setClient(data);
  } catch (e) { 
    console.error('Error fetching client:', e); 
    setError('Failed to load client data');
  } finally { 
    setLoading(false); 
  }
};
  const handleNoteAdd = async () => {
    if (!noteText.trim()) return;
    try {
      const res = await fetch(`${API_URL}/api/clients/${id}/notes`, { method: 'POST', headers: getAuthHeaders(), body: JSON.stringify({ content: noteText }) });
      if (res.ok) { setClient(await res.json()); setNoteText(''); }
    } catch { /* skip */ }
  };

  const handleFileUpload = async () => {
    if (!selectedFile) return;
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('file', selectedFile);
      fd.append('name', selectedFile.name);
      fd.append('type', 'contract');
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/api/clients/${id}/documents`, { method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: fd });
      if (res.ok) { setClient(await res.json()); setShowDocUpload(false); setSelectedFile(null); setSuccess('Document uploaded!'); setTimeout(() => setSuccess(''), 3000); }
    } catch { setError('Upload failed'); }
    finally { setUploading(false); }
  };

  const handleOfferAdd = async () => {
    if (!offerForm.title) return;
    try {
      const res = await fetch(`${API_URL}/api/clients/${id}/offers`, { method: 'POST', headers: getAuthHeaders(), body: JSON.stringify(offerForm) });
      if (res.ok) { setClient(await res.json()); setShowOfferModal(false); setOfferForm({ title: '', description: '', discountPercent: '', code: '', validFrom: '', validUntil: '', status: 'draft' }); }
    } catch { /* skip */ }
  };

  const handleRevenueAdd = async () => {
    if (!revenueForm.amount) return;
    try {
      const res = await fetch(`${API_URL}/api/clients/${id}/revenue`, { method: 'POST', headers: getAuthHeaders(), body: JSON.stringify({ ...revenueForm, amount: parseFloat(revenueForm.amount) }) });
      if (res.ok) { setClient(await res.json()); setShowRevenueModal(false); setRevenueForm({ amount: '', description: '', status: 'pending', date: new Date().toISOString().split('T')[0] }); }
    } catch { /* skip */ }
  };

  const handleUpdate = async () => {
    try {
      const res = await fetch(`${API_URL}/api/clients/${id}`, { method: 'PUT', headers: getAuthHeaders(), body: JSON.stringify(editForm) });
      if (res.ok) { setClient(await res.json()); setShowEditModal(false); setSuccess('Updated!'); setTimeout(() => setSuccess(''), 3000); }
    } catch { setError('Failed'); }
  };

  const daysUntilRenewal = client?.renewalDate ? Math.ceil((new Date(client.renewalDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : 0;
  const totalRevenue = client?.revenue?.filter(r => r.status === 'received').reduce((s, r) => s + r.amount, 0) || 0;
  const typeInfo = client ? PARTNER_TYPES[client.partnerType] || PARTNER_TYPES.discount_partner : null;
  const TypeIcon = typeInfo?.icon;
  const statusInfo = client ? STATUS[client.status] || STATUS.active : null;

  if (loading) {
    return <DashboardLayout><div className="flex justify-center items-center h-96"><div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-600 border-t-transparent" /></div></DashboardLayout>;
  }
  if (!client) return <DashboardLayout><div className="text-center py-20">Client not found</div></DashboardLayout>;

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {success && <div className="fixed top-6 right-6 z-50 bg-white border border-emerald-200 shadow-lg rounded-xl px-5 py-3 text-sm font-medium text-emerald-800">{success}</div>}
        {error && <div className="fixed top-6 right-6 z-50 bg-white border border-red-200 shadow-lg rounded-xl px-5 py-3 text-sm font-medium text-red-800">{error}</div>}

        {/* Header */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <button onClick={() => router.push('/clients')} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                <ArrowLeft className="h-5 w-5 text-gray-500" />
              </button>
              <div className="flex items-center gap-4">
                <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-xl shrink-0 shadow-lg">
                  {client.brandName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
                </div>
                <div>
                  <div className="flex items-center gap-3">
                    <h1 className="text-2xl font-bold text-gray-900">{client.brandName}</h1>
                    {typeInfo && <TypeIcon className={`h-5 w-5 ${typeInfo.color}`} />}
                    <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${typeInfo?.bg} ${typeInfo?.color}`}>{typeInfo?.label}</span>
                    {statusInfo && <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${statusInfo.bg} ${statusInfo.color}`}>{statusInfo.label}</span>}
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-sm text-gray-500">
                    <span className="font-mono text-xs bg-gray-100 px-2 py-0.5 rounded-md">{client.brandId}</span>
                    {client.accountManager && <span>👤 {client.accountManager.name} (Manager)</span>}
                  </div>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              {canEdit('clients') && (
                <button onClick={() => { setEditForm({ brandName: client.brandName, description: client.description, partnerType: client.partnerType, industry: client.industry, city: client.city, country: client.country, website: client.website, dealValue: client.dealValue, status: client.status, healthScore: client.healthScore, accountManagerEmail: client.accountManagerEmail, renewalDate: client.renewalDate ? new Date(client.renewalDate).toISOString().split('T')[0] : '', contractDuration: client.contractDuration }); setShowEditModal(true); }}
                  className="px-4 py-2 text-sm font-semibold text-gray-700 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors flex items-center gap-2">
                  <Edit className="h-4 w-4" /> Edit
                </button>
              )}
              <button onClick={() => router.push(`/clients/${client._id}/renew`)}
                className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors">
                Renew
              </button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="flex border-b border-gray-200 overflow-x-auto">
            {TABS.map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab)}
                className={`px-5 py-3.5 text-sm font-semibold whitespace-nowrap transition-all border-b-2 ${
                  activeTab === tab ? 'text-indigo-600 border-indigo-600' : 'text-gray-500 border-transparent hover:text-gray-700'
                }`}>
                {tab}
              </button>
            ))}
          </div>

          <div className="p-6">
            {/* ========== OVERVIEW TAB ========== */}
            {activeTab === 'Overview' && (
              <div className="space-y-6">
                {/* KPIs */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { label: 'Revenue Generated', value: `$${totalRevenue.toLocaleString()}`, sub: `+${Math.round((totalRevenue / (client.dealValue || 1)) * 100)}% of deal`, icon: DollarSign, color: 'bg-indigo-500' },
                    { label: 'Active Campaigns', value: client.performance?.activeCampaigns || 0, sub: 'Running campaigns', icon: BarChart3, color: 'bg-blue-500' },
                    { label: 'Offer Redemptions', value: (client.performance?.totalRedemptions || 0).toLocaleString(), sub: 'This month', icon: BadgePercent, color: 'bg-emerald-500' },
                    { label: 'Renewal Date', value: client.renewalDate ? new Date(client.renewalDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'N/A', sub: daysUntilRenewal > 0 ? `${daysUntilRenewal} days left` : 'Expired', icon: Calendar, color: daysUntilRenewal > 30 ? 'bg-teal-500' : 'bg-amber-500' },
                  ].map(kpi => (
                    <div key={kpi.label} className="bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow">
                      <div className={`h-10 w-10 ${kpi.color} rounded-xl flex items-center justify-center mb-3`}>
                        <kpi.icon className="h-5 w-5 text-white" />
                      </div>
                      <p className="text-xl font-bold text-gray-900">{kpi.value}</p>
                      <p className="text-xs font-medium text-gray-500 mt-0.5">{kpi.label}</p>
                      <p className="text-[10px] text-gray-400 mt-1">{kpi.sub}</p>
                    </div>
                  ))}
                </div>

                {/* Info Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {/* Company Info */}
                  <div className="border border-gray-200 rounded-xl p-5">
                    <h4 className="text-sm font-bold text-gray-900 mb-3">Company Info</h4>
                    <div className="space-y-2 text-sm">
                      {client.website && <p className="flex items-center gap-2 text-gray-600"><Globe className="h-4 w-4 text-gray-400" /> <a href={client.website} target="_blank" className="text-indigo-600 hover:underline">{client.website}</a></p>}
                      {client.industry && <p className="flex items-center gap-2 text-gray-600"><Building2 className="h-4 w-4 text-gray-400" /> {client.industry}</p>}
                      <p className="flex items-center gap-2 text-gray-600"><Tag className="h-4 w-4 text-gray-400" /> {typeInfo?.label}</p>
                      {client.startDate && <p className="flex items-center gap-2 text-gray-600"><Calendar className="h-4 w-4 text-gray-400" /> Started: {new Date(client.startDate).toLocaleDateString()}</p>}
                      {client.contractDuration && <p className="flex items-center gap-2 text-gray-600"><Clock className="h-4 w-4 text-gray-400" /> {client.contractDuration}</p>}
                      <p className="flex items-center gap-2 text-gray-600"><CheckCircle2 className="h-4 w-4 text-gray-400" /> {statusInfo?.label}</p>
                    </div>
                  </div>

                  {/* Account Manager */}
                  <div className="border border-gray-200 rounded-xl p-5">
                    <h4 className="text-sm font-bold text-gray-900 mb-3">Account Manager</h4>
                    {client.accountManager ? (
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center text-sm font-bold text-indigo-600">
                            {client.accountManager.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-gray-900">{client.accountManager.name}</p>
                            <p className="text-xs text-gray-500 capitalize">{client.accountManager.role?.replace('_', ' ')}</p>
                          </div>
                        </div>
                        <p className="flex items-center gap-2 text-sm text-gray-600"><Mail className="h-4 w-4 text-gray-400" /> {client.accountManager.email}</p>
                        {client.accountManagerSince && <p className="text-xs text-gray-400">Since {new Date(client.accountManagerSince).toLocaleDateString()}</p>}
                      </div>
                    ) : (
                      <p className="text-sm text-gray-400 italic">No manager assigned</p>
                    )}
                  </div>

                  {/* Main Contact */}
                  {client.contacts?.find(c => c.isPrimary) && (
                    <div className="border border-gray-200 rounded-xl p-5">
                      <h4 className="text-sm font-bold text-gray-900 mb-3">Main Contact</h4>
                      {(() => { const c = client.contacts.find(c => c.isPrimary)!; return (
                        <div className="space-y-2">
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-sm font-bold text-gray-600">
                              {c.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                            </div>
                            <div>
                              <p className="text-sm font-semibold text-gray-900">{c.name}</p>
                              {c.position && <p className="text-xs text-gray-500">{c.position}</p>}
                            </div>
                          </div>
                          {c.email && <p className="flex items-center gap-2 text-sm text-gray-600"><Mail className="h-4 w-4 text-gray-400" /> {c.email}</p>}
                          {c.phone && <p className="flex items-center gap-2 text-sm text-gray-600"><Phone className="h-4 w-4 text-gray-400" /> {c.phone}</p>}
                        </div>
                      )})()}
                    </div>
                  )}
                </div>

                {/* Notes */}
                <div className="border border-gray-200 rounded-xl p-5">
                  <h4 className="text-sm font-bold text-gray-900 mb-3">Notes</h4>
                  <div className="space-y-2 max-h-48 overflow-y-auto mb-3">
                    {client.notes?.map(note => (
                      <div key={note._id} className="p-3 bg-gray-50 rounded-xl text-sm">
                        <p className="text-gray-700">{note.content}</p>
                        <p className="text-xs text-gray-400 mt-1">{note.createdBy?.name}</p>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <input type="text" placeholder="Add a note..." className="flex-1 border border-gray-200 rounded-xl px-4 py-2.5 text-sm bg-gray-50" value={noteText} onChange={e => setNoteText(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleNoteAdd()} />
                    <button onClick={handleNoteAdd} className="px-4 py-2.5 bg-indigo-600 text-white text-sm font-semibold rounded-xl">Add</button>
                  </div>
                </div>
              </div>
            )}

            {/* ========== OFFERS TAB ========== */}
            {activeTab === 'Offers' && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-bold text-gray-900">Offers ({client.offers?.length || 0})</h3>
                  <button onClick={() => setShowOfferModal(true)} className="px-4 py-2 bg-indigo-600 text-white text-sm font-semibold rounded-xl flex items-center gap-2"><Plus className="h-4 w-4" /> Add Offer</button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {client.offers?.map(offer => (
                    <div key={offer._id} className="border border-gray-200 rounded-xl p-4">
                      <div className="flex justify-between mb-2">
                        <h4 className="font-semibold text-gray-900">{offer.title}</h4>
                        <span className={`px-2 py-0.5 text-xs rounded-full ${offer.status === 'active' ? 'bg-emerald-100 text-emerald-700' : offer.status === 'expired' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600'}`}>{offer.status}</span>
                      </div>
                      {offer.description && <p className="text-sm text-gray-600 mb-2">{offer.description}</p>}
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        {offer.discountPercent && <span>🏷️ {offer.discountPercent}% off</span>}
                        {offer.code && <span className="font-mono bg-gray-100 px-2 py-0.5 rounded">Code: {offer.code}</span>}
                        <span>📊 {offer.redemptionCount || 0} redemptions</span>
                      </div>
                    </div>
                  ))}
                  {(!client.offers || client.offers.length === 0) && <p className="text-gray-400 text-sm col-span-2 text-center py-8">No offers yet</p>}
                </div>
              </div>
            )}

            {/* ========== CAMPAIGNS TAB ========== */}
            {activeTab === 'Campaigns' && (
              <div className="text-center py-12">
                <BarChart3 className="mx-auto h-10 w-10 text-gray-300 mb-3" />
                <p className="text-gray-500">Campaigns linked to this brand will appear here.</p>
                <button onClick={() => router.push('/campaigns')} className="mt-3 text-sm text-indigo-600 font-semibold hover:underline">View Campaigns →</button>
              </div>
            )}

            {/* ========== CONTACTS TAB ========== */}
            {activeTab === 'Contacts' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-gray-900">Contacts ({client.contacts?.length || 0})</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {client.contacts?.map(contact => (
                    <div key={contact._id} className="border border-gray-200 rounded-xl p-4 flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-gray-200 flex items-center justify-center text-lg font-bold text-gray-600 shrink-0">
                        {contact.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold text-gray-900">{contact.name}</h4>
                          {contact.isPrimary && <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">Primary</span>}
                        </div>
                        {contact.position && <p className="text-sm text-gray-500">{contact.position}</p>}
                        <div className="flex items-center gap-3 mt-1 text-xs text-gray-500">
                          {contact.email && <span className="flex items-center gap-1"><Mail className="h-3 w-3" />{contact.email}</span>}
                          {contact.phone && <span className="flex items-center gap-1"><Phone className="h-3 w-3" />{contact.phone}</span>}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ========== ACTIVITY TAB ========== */}
            {activeTab === 'Activity' && (
              <div className="space-y-3">
                <h3 className="text-lg font-bold text-gray-900">Recent Activity</h3>
                {client.activities?.map(activity => (
                  <div key={activity._id} className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded-xl transition-colors">
                    <div className="h-8 w-8 rounded-full bg-indigo-100 flex items-center justify-center shrink-0">
                      <Activity className="h-4 w-4 text-indigo-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-700">{activity.description}</p>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {activity.performedBy?.name || 'System'} • {new Date(activity.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ========== FINANCE TAB ========== */}
            {activeTab === 'Finance' && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-bold text-gray-900">Revenue ({formatCurrency(totalRevenue)})</h3>
                  <button onClick={() => setShowRevenueModal(true)} className="px-4 py-2 bg-indigo-600 text-white text-sm font-semibold rounded-xl flex items-center gap-2"><Plus className="h-4 w-4" /> Add Revenue</button>
                </div>
                <div className="space-y-2">
                  {client.revenue?.map(rev => (
                    <div key={rev._id} className="flex items-center justify-between p-4 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
                      <div>
                        <p className="font-semibold text-gray-900">${rev.amount.toLocaleString()}</p>
                        <p className="text-sm text-gray-500">{rev.description || 'No description'}</p>
                        <p className="text-xs text-gray-400">{new Date(rev.date).toLocaleDateString()}</p>
                      </div>
                      <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
                        rev.status === 'received' ? 'bg-emerald-100 text-emerald-700' : rev.status === 'overdue' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                      }`}>{rev.status}</span>
                    </div>
                  ))}
                  {(!client.revenue || client.revenue.length === 0) && <p className="text-gray-400 text-sm text-center py-8">No revenue records yet</p>}
                </div>
              </div>
            )}

            {/* ========== DOCS TAB ========== */}
            {activeTab === 'Docs' && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-bold text-gray-900">Documents ({client.documents?.length || 0})</h3>
                  <button onClick={() => setShowDocUpload(true)} className="px-4 py-2 bg-indigo-600 text-white text-sm font-semibold rounded-xl flex items-center gap-2"><Upload className="h-4 w-4" /> Upload</button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {client.documents?.map(doc => (
                    <div key={doc._id} className="flex items-center justify-between p-4 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
                      <div className="flex items-center gap-3">
                        <FileText className="h-8 w-8 text-gray-400" />
                        <div>
                          <p className="text-sm font-semibold text-gray-900">{doc.name}</p>
                          <p className="text-xs text-gray-500">{doc.type} • {doc.fileSize ? `${(doc.fileSize / 1024).toFixed(0)} KB` : ''}</p>
                        </div>
                      </div>
                      <a href={doc.url} target="_blank" rel="noopener noreferrer" className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg"><Download className="h-4 w-4" /></a>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Doc Upload Modal */}
        {showDocUpload && (
          <Modal onClose={() => setShowDocUpload(false)} title="Upload Document">
            <input type="file" onChange={e => setSelectedFile(e.target.files?.[0] || null)} className="w-full text-sm" />
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setShowDocUpload(false)} className="px-4 py-2 text-sm font-semibold text-gray-700 border rounded-xl">Cancel</button>
              <button onClick={handleFileUpload} disabled={uploading || !selectedFile} className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-xl disabled:opacity-50">{uploading ? 'Uploading...' : 'Upload'}</button>
            </div>
          </Modal>
        )}

        {/* Offer Modal */}
        {showOfferModal && (
          <Modal onClose={() => setShowOfferModal(false)} title="Add Offer">
            <div className="space-y-3">
              <input type="text" placeholder="Title *" className="w-full border rounded-xl px-4 py-2.5 text-sm bg-gray-50" value={offerForm.title} onChange={e => setOfferForm({...offerForm, title: e.target.value})} />
              <input type="text" placeholder="Description" className="w-full border rounded-xl px-4 py-2.5 text-sm bg-gray-50" value={offerForm.description} onChange={e => setOfferForm({...offerForm, description: e.target.value})} />
              <div className="grid grid-cols-2 gap-3">
                <input type="number" placeholder="Discount %" className="border rounded-xl px-4 py-2.5 text-sm bg-gray-50" value={offerForm.discountPercent} onChange={e => setOfferForm({...offerForm, discountPercent: e.target.value})} />
                <input type="text" placeholder="Code" className="border rounded-xl px-4 py-2.5 text-sm bg-gray-50" value={offerForm.code} onChange={e => setOfferForm({...offerForm, code: e.target.value})} />
              </div>
              <div className="flex justify-end gap-3 mt-4">
                <button onClick={() => setShowOfferModal(false)} className="px-4 py-2 text-sm font-semibold text-gray-700 border rounded-xl">Cancel</button>
                <button onClick={handleOfferAdd} className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-xl">Add Offer</button>
              </div>
            </div>
          </Modal>
        )}

        {/* Revenue Modal */}
        {showRevenueModal && (
          <Modal onClose={() => setShowRevenueModal(false)} title="Add Revenue">
            <div className="space-y-3">
              <input type="number" placeholder="Amount *" className="w-full border rounded-xl px-4 py-2.5 text-sm bg-gray-50" value={revenueForm.amount} onChange={e => setRevenueForm({...revenueForm, amount: e.target.value})} />
              <input type="text" placeholder="Description" className="w-full border rounded-xl px-4 py-2.5 text-sm bg-gray-50" value={revenueForm.description} onChange={e => setRevenueForm({...revenueForm, description: e.target.value})} />
              <select className="w-full border rounded-xl px-4 py-2.5 text-sm bg-gray-50" value={revenueForm.status} onChange={e => setRevenueForm({...revenueForm, status: e.target.value})}>
                <option value="pending">Pending</option><option value="received">Received</option><option value="overdue">Overdue</option>
              </select>
              <div className="flex justify-end gap-3 mt-4">
                <button onClick={() => setShowRevenueModal(false)} className="px-4 py-2 text-sm font-semibold text-gray-700 border rounded-xl">Cancel</button>
                <button onClick={handleRevenueAdd} className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-xl">Add</button>
              </div>
            </div>
          </Modal>
        )}

        {/* Edit Modal */}
        {showEditModal && (
          <Modal onClose={() => setShowEditModal(false)} title="Edit Client" wide>
            <div className="grid grid-cols-2 gap-4 max-h-[60vh] overflow-y-auto">
              <div><label className="block text-xs font-semibold mb-1">Brand Name</label><input type="text" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.brandName || ''} onChange={e => setEditForm({...editForm, brandName: e.target.value})} /></div>
              <div><label className="block text-xs font-semibold mb-1">Partner Type</label><select className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.partnerType || ''} onChange={e => setEditForm({...editForm, partnerType: e.target.value})}>{Object.entries(PARTNER_TYPES).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}</select></div>
              <div><label className="block text-xs font-semibold mb-1">Industry</label><input type="text" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.industry || ''} onChange={e => setEditForm({...editForm, industry: e.target.value})} /></div>
              <div><label className="block text-xs font-semibold mb-1">City</label><input type="text" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.city || ''} onChange={e => setEditForm({...editForm, city: e.target.value})} /></div>
              <div><label className="block text-xs font-semibold mb-1">Country</label><input type="text" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.country || ''} onChange={e => setEditForm({...editForm, country: e.target.value})} /></div>
              <div><label className="block text-xs font-semibold mb-1">Website</label><input type="text" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.website || ''} onChange={e => setEditForm({...editForm, website: e.target.value})} /></div>
              <div><label className="block text-xs font-semibold mb-1">Deal Value ($)</label><input type="number" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.dealValue || ''} onChange={e => setEditForm({...editForm, dealValue: e.target.value})} /></div>
              <div><label className="block text-xs font-semibold mb-1">Status</label><select className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.status || ''} onChange={e => setEditForm({...editForm, status: e.target.value})}>{Object.entries(STATUS).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}</select></div>
              <div><label className="block text-xs font-semibold mb-1">Account Manager Email</label><input type="email" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.accountManagerEmail || ''} onChange={e => setEditForm({...editForm, accountManagerEmail: e.target.value})} /></div>
              <div><label className="block text-xs font-semibold mb-1">Renewal Date</label><input type="date" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.renewalDate || ''} onChange={e => setEditForm({...editForm, renewalDate: e.target.value})} /></div>
              <div><label className="block text-xs font-semibold mb-1">Contract Duration</label><input type="text" className="w-full border rounded-xl px-3 py-2 text-sm bg-gray-50" value={editForm.contractDuration || ''} onChange={e => setEditForm({...editForm, contractDuration: e.target.value})} placeholder="e.g., 12 months" /></div>
            </div>
            <div className="flex justify-end gap-3 mt-6 pt-4 border-t">
              <button onClick={() => setShowEditModal(false)} className="px-4 py-2 text-sm font-semibold text-gray-700 border rounded-xl">Cancel</button>
              <button onClick={handleUpdate} className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-xl">Save Changes</button>
            </div>
          </Modal>
        )}
      </div>
    </DashboardLayout>
  );
}

// Helper Modal Component
function Modal({ children, onClose, title, wide }: { children: React.ReactNode; onClose: () => void; title: string; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={onClose} />
        <div className={`relative bg-white rounded-2xl shadow-2xl w-full ${wide ? 'max-w-2xl' : 'max-w-md'} border border-gray-100`}>
          <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 rounded-t-2xl flex items-center justify-between z-10">
            <h2 className="text-lg font-bold text-gray-900">{title}</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-xl"><X className="h-5 w-5 text-gray-400" /></button>
          </div>
          <div className="p-6">{children}</div>
        </div>
      </div>
    </div>
  );
}

function formatCurrency(val: number) { return val ? `$${val.toLocaleString()}` : '$0'; }