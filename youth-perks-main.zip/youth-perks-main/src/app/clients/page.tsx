'use client';

import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/hooks/useAuth';
import {
  Plus, Search, Star, MapPin, Building2, ChevronRight,
  Briefcase, Handshake, BadgePercent, DollarSign, Link,
  Sparkles, PartyPopper, FlaskConical, Tv, Users, TrendingUp,
  Filter, Upload, X, Image, Mail
} from 'lucide-react';

interface Client {
  _id: string; brandId: string; brandName: string; logo: string;
  partnerType: string; industry: string; city: string; country: string;
  dealValue: number; status: string; healthScore: string; isFavorite: boolean;
  accountManager?: { _id: string; name: string; email: string; role: string };
  performance: { revenueGenerated: number; activeCampaigns: number; totalRedemptions: number };
  startDate: string; renewalDate: string;
}

const PARTNER_TYPES: Record<string, { label: string; icon: any; color: string; bg: string; border: string }> = {
  official_partner:   { label: 'Official Partner',    icon: Handshake,      color: 'text-blue-600',   bg: 'bg-blue-50',   border: 'border-blue-200' },
  discount_partner:   { label: 'Discount Partner',    icon: BadgePercent,   color: 'text-green-600',  bg: 'bg-green-50',  border: 'border-green-200' },
  sponsored_brand:    { label: 'Sponsored Brand',     icon: DollarSign,     color: 'text-purple-600', bg: 'bg-purple-50', border: 'border-purple-200' },
  affiliate_partner:  { label: 'Affiliate Partner',   icon: Link,           color: 'text-orange-600', bg: 'bg-orange-50', border: 'border-orange-200' },
  ambassador_partner: { label: 'Ambassador Partner',  icon: Sparkles,       color: 'text-amber-600',  bg: 'bg-amber-50',  border: 'border-amber-200' },
  event_partner:      { label: 'Event Partner',       icon: PartyPopper,    color: 'text-pink-600',   bg: 'bg-pink-50',   border: 'border-pink-200' },
  trial_partner:      { label: 'Trial Partner',       icon: FlaskConical,   color: 'text-teal-600',   bg: 'bg-teal-50',   border: 'border-teal-200' },
  media_partner:      { label: 'Media Partner',       icon: Tv,             color: 'text-red-600',    bg: 'bg-red-50',    border: 'border-red-200' },
};

const STATUS: Record<string, { label: string; dot: string }> = {
  active: { label: 'Active', dot: 'bg-emerald-500' },
  trial: { label: 'Trial', dot: 'bg-blue-500' },
  at_risk: { label: 'At Risk', dot: 'bg-amber-500' },
  expiring: { label: 'Expiring', dot: 'bg-orange-500' },
  paused: { label: 'Paused', dot: 'bg-gray-400' },
  completed: { label: 'Completed', dot: 'bg-blue-400' },
};

export default function ClientsPage() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [showFavorites, setShowFavorites] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState('');
  const [formData, setFormData] = useState({
    brandName: '', partnerType: 'discount_partner', industry: '',
    city: '', country: '', website: '', dealValue: '',
    accountManagerEmail: '', description: '',
  });

  const router = useRouter();
  const { canCreate } = useAuth();
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

  useEffect(() => { fetchClients(); }, [searchTerm, statusFilter, typeFilter, showFavorites]);

  const getAuthHeaders = (isFormData = false) => {
    const token = localStorage.getItem('token');
    const h: Record<string, string> = { Authorization: `Bearer ${token}` };
    if (!isFormData) h['Content-Type'] = 'application/json';
    return h;
  };

  const fetchClients = async () => {
    try {
      const params = new URLSearchParams();
      if (statusFilter !== 'all') params.append('status', statusFilter);
      if (typeFilter !== 'all') params.append('partnerType', typeFilter);
      if (searchTerm) params.append('search', searchTerm);
      if (showFavorites) params.append('isFavorite', 'true');
      const res = await fetch(`${API_URL}/api/clients?${params}`, { headers: getAuthHeaders() });
      if (res.ok) setClients(await res.json());
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const handleCreate = async () => {
    if (!formData.brandName) { setError('Brand name is required'); return; }
    setSubmitting(true);
    try {
      const fd = new FormData();
      fd.append('brandName', formData.brandName);
      fd.append('partnerType', formData.partnerType);
      fd.append('industry', formData.industry);
      fd.append('city', formData.city);
      fd.append('country', formData.country);
      fd.append('website', formData.website);
      fd.append('dealValue', formData.dealValue);
      fd.append('accountManagerEmail', formData.accountManagerEmail);
      fd.append('description', formData.description);
      if (logoFile) fd.append('logo', logoFile);

      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/api/clients`, { method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: fd });
      if (res.ok) {
        fetchClients();
        setShowCreateModal(false);
        setSuccess('Client created!');
        setTimeout(() => setSuccess(''), 3000);
        resetForm();
      } else {
        const d = await res.json();
        setError(d.message || 'Failed');
      }
    } catch { setError('Failed to create'); }
    finally { setSubmitting(false); }
  };

  const resetForm = () => {
    setFormData({ brandName: '', partnerType: 'discount_partner', industry: '', city: '', country: '', website: '', dealValue: '', accountManagerEmail: '', description: '' });
    setLogoFile(null); setLogoPreview('');
  };

  const toggleFavorite = async (id: string) => {
    await fetch(`${API_URL}/api/clients/${id}/toggle-favorite`, { method: 'PUT', headers: getAuthHeaders() });
    fetchClients();
  };

  const formatCurrency = (val: number) => val ? `$${(val / 1000).toFixed(0)}k` : '$0';
  const totalValue = clients.reduce((s, c) => s + (c.dealValue || 0), 0);
  const activeCount = clients.filter(c => c.status === 'active').length;

  // Group by status
  const grouped = {
    active: clients.filter(c => c.status === 'active'),
    trial: clients.filter(c => c.status === 'trial'),
    other: clients.filter(c => !['active', 'trial'].includes(c.status)),
  };

  if (loading) {
    return <DashboardLayout><div className="flex justify-center items-center h-96"><div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-600 border-t-transparent" /></div></DashboardLayout>;
  }

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {success && <Toast message={success} type="success" />}
        {error && <Toast message={error} type="error" />}

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-gray-900">Partners & Clients</h1>
            <p className="text-sm text-gray-500 mt-1">
              <span className="font-semibold text-emerald-600">{activeCount}</span> active •{' '}
              <span className="font-semibold text-gray-700">{formatCurrency(totalValue)}</span> total value
            </p>
          </div>
          {canCreate('clients') && (
            <button onClick={() => setShowCreateModal(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white text-sm font-semibold rounded-xl shadow-sm hover:bg-indigo-700 transition-all active:scale-95">
              <Plus className="h-4 w-4" /> Add Client
            </button>
          )}
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'Active', value: grouped.active.length, color: 'bg-emerald-500' },
            { label: 'Trial', value: grouped.trial.length, color: 'bg-blue-500' },
            { label: 'At Risk', value: clients.filter(c => c.status === 'at_risk').length, color: 'bg-amber-500' },
            { label: 'Expiring Soon', value: clients.filter(c => c.status === 'expiring').length, color: 'bg-orange-500' },
          ].map(s => (
            <button key={s.label} onClick={() => setStatusFilter(statusFilter === s.label.toLowerCase().replace(' ', '_') ? 'all' : s.label.toLowerCase().replace(' ', '_'))}
              className="bg-white border border-gray-200 rounded-xl p-4 text-left hover:shadow-md transition-all">
              <div className="flex items-center gap-2 mb-1">
                <div className={`h-2.5 w-2.5 rounded-full ${s.color}`} />
                <span className="text-xs font-medium text-gray-500">{s.label}</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">{s.value}</p>
            </button>
          ))}
        </div>

        {/* Search & Filters */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input type="text" placeholder="Search brands by name, ID, or industry..." className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
            </div>
            <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)}
              className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium text-gray-700">
              <option value="all">All Types</option>
              {Object.entries(PARTNER_TYPES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
            <button onClick={() => setShowFavorites(!showFavorites)}
              className={`px-4 py-2.5 rounded-xl text-sm font-medium border transition-all ${showFavorites ? 'bg-amber-50 border-amber-300 text-amber-700 shadow-sm' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'}`}>
              ⭐ {showFavorites ? 'Favorites' : 'All'}
            </button>
          </div>
        </div>

        {/* Active Clients */}
        <ClientSection title="Active" clients={grouped.active} statusFilter={statusFilter} onStatusFilter={setStatusFilter} onFavorite={toggleFavorite} onClick={(c) => router.push(`/clients/${c._id}`)} />

        {/* Trial Clients */}
        <ClientSection title="Trial" clients={grouped.trial} statusFilter={statusFilter} onStatusFilter={setStatusFilter} onFavorite={toggleFavorite} onClick={(c) => router.push(`/clients/${c._id}`)} />

        {/* Other Clients */}
        {grouped.other.length > 0 && (
          <ClientSection title="Other" clients={grouped.other} statusFilter={statusFilter} onStatusFilter={setStatusFilter} onFavorite={toggleFavorite} onClick={(c) => router.push(`/clients/${c._id}`)} />
        )}

        {clients.length === 0 && (
          <div className="text-center py-20 bg-white rounded-2xl border border-gray-200">
            <div className="h-16 w-16 rounded-2xl bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <Briefcase className="h-8 w-8 text-gray-300" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">No clients yet</h3>
            <p className="text-sm text-gray-500 mt-1">Add your first brand partner to get started.</p>
            {canCreate('clients') && (
              <button onClick={() => setShowCreateModal(true)}
                className="mt-4 px-5 py-2.5 bg-indigo-600 text-white text-sm font-semibold rounded-xl hover:bg-indigo-700 transition-colors">
                <Plus className="h-4 w-4 inline mr-1" /> Add First Client
              </button>
            )}
          </div>
        )}

        {/* Create Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <div className="fixed inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setShowCreateModal(false)} />
              <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-xl border border-gray-100 max-h-[90vh] overflow-y-auto">
                <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 rounded-t-2xl flex items-center justify-between z-10">
                  <h2 className="text-lg font-bold text-gray-900">Add New Client</h2>
                  <button onClick={() => setShowCreateModal(false)} className="p-2 hover:bg-gray-100 rounded-xl"><X className="h-5 w-5 text-gray-400" /></button>
                </div>
                <div className="p-6 space-y-4">
                  {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm">{error}</div>}

                  {/* Logo Upload */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Brand Logo</label>
                    <div className="flex items-center gap-4">
                      <div className="h-20 w-20 rounded-2xl border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden bg-gray-50 hover:border-indigo-400 transition-colors cursor-pointer relative"
                        onClick={() => document.getElementById('logo-input')?.click()}>
                        {logoPreview ? (
                          <img src={logoPreview} alt="Preview" className="h-full w-full object-cover" />
                        ) : (
                          <div className="text-center">
                            <Image className="h-6 w-6 text-gray-400 mx-auto" />
                            <span className="text-[10px] text-gray-400 mt-1 block">Logo</span>
                          </div>
                        )}
                      </div>
                      <input id="logo-input" type="file" className="hidden" accept="image/*"
                        onChange={e => {
                          const file = e.target.files?.[0];
                          if (file) { setLogoFile(file); setLogoPreview(URL.createObjectURL(file)); }
                        }} />
                      <div>
                        <p className="text-sm font-medium text-gray-700">Upload brand logo</p>
                        <p className="text-xs text-gray-400 mt-0.5">PNG, JPG or SVG. Max 5MB.</p>
                        {logoFile && <button onClick={() => { setLogoFile(null); setLogoPreview(''); }} className="text-xs text-red-500 mt-1">Remove</button>}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Brand Name *</label><input type="text" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500" value={formData.brandName} onChange={e => setFormData({...formData, brandName: e.target.value})} placeholder="e.g., Nike" /></div>
                    <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Partner Type</label><select className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.partnerType} onChange={e => setFormData({...formData, partnerType: e.target.value})}>{Object.entries(PARTNER_TYPES).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}</select></div>
                    <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Industry</label><input type="text" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.industry} onChange={e => setFormData({...formData, industry: e.target.value})} /></div>
                    <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">City</label><input type="text" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.city} onChange={e => setFormData({...formData, city: e.target.value})} /></div>
                    <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Country</label><input type="text" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.country} onChange={e => setFormData({...formData, country: e.target.value})} /></div>
                    <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Website</label><input type="text" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.website} onChange={e => setFormData({...formData, website: e.target.value})} /></div>
                    <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Deal Value ($)</label><input type="number" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.dealValue} onChange={e => setFormData({...formData, dealValue: e.target.value})} /></div>
                    <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Account Manager Email</label><input type="email" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.accountManagerEmail} onChange={e => setFormData({...formData, accountManagerEmail: e.target.value})} placeholder="manager@example.com" /></div>
                  </div>
                  <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Description</label><textarea className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50 resize-none" rows={2} value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} /></div>
                </div>
                <div className="sticky bottom-0 bg-white border-t border-gray-100 px-6 py-4 rounded-b-2xl flex justify-end gap-3">
                  <button onClick={() => setShowCreateModal(false)} className="px-5 py-2.5 text-sm font-semibold text-gray-700 border border-gray-200 rounded-xl hover:bg-gray-50">Cancel</button>
                  <button onClick={handleCreate} disabled={submitting}
                    className="px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2">
                    {submitting ? <><div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" /> Creating...</> : 'Create Client'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}

// Client Card Component
function ClientCard({ client, onFavorite, onClick }: { client: Client; onFavorite: (id: string) => void; onClick: () => void }) {
  const typeInfo = PARTNER_TYPES[client.partnerType] || PARTNER_TYPES.discount_partner;
  const statusInfo = STATUS[client.status] || STATUS.active;
  const TypeIcon = typeInfo.icon;

  return (
    <div onClick={onClick}
      className="group bg-white rounded-xl border border-gray-200 p-4 hover:shadow-lg hover:border-gray-300 transition-all cursor-pointer active:scale-[0.98]">
      <div className="flex items-center gap-3 mb-3">
        {/* Logo or Initials */}
        {client.logo ? (
          <img src={client.logo} alt={client.brandName} className="h-11 w-11 rounded-xl object-cover border border-gray-200 shrink-0" />
        ) : (
          <div className="h-11 w-11 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm shrink-0 shadow-md">
            {client.brandName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <h4 className="font-semibold text-gray-900 text-sm truncate">{client.brandName}</h4>
            <div className="flex items-center gap-1.5">
              <div className={`h-2 w-2 rounded-full ${statusInfo.dot}`} title={statusInfo.label} />
              <button onClick={(e) => { e.stopPropagation(); onFavorite(client._id); }}
                className="p-0.5 hover:bg-amber-50 rounded transition-colors">
                <Star className={`h-3.5 w-3.5 ${client.isFavorite ? 'text-amber-500 fill-amber-500' : 'text-gray-300 group-hover:text-gray-400'}`} />
              </button>
            </div>
          </div>
          <div className="flex items-center gap-2 mt-1">
            <TypeIcon className={`h-3.5 w-3.5 ${typeInfo.color}`} />
            <span className={`text-xs font-medium ${typeInfo.color}`}>{typeInfo.label}</span>
          </div>
        </div>
      </div>

      {/* Location & Industry */}
      <div className="flex items-center gap-3 text-xs text-gray-500 mb-3">
        {(client.city || client.country) && (
          <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{client.city}{client.city && client.country ? ', ' : ''}{client.country}</span>
        )}
        {client.industry && <span className="flex items-center gap-1"><Building2 className="h-3 w-3" />{client.industry}</span>}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-3 border-t border-gray-100">
        <span className="text-xs font-mono text-gray-400">{client.brandId}</span>
        <div className="flex items-center gap-2">
          {client.dealValue > 0 && <span className="text-sm font-bold text-gray-900">${(client.dealValue / 1000).toFixed(0)}k</span>}
          <ChevronRight className="h-4 w-4 text-gray-300 group-hover:text-indigo-500 group-hover:translate-x-0.5 transition-all" />
        </div>
      </div>
    </div>
  );
}

// Client Section Component
function ClientSection({ title, clients, onFavorite, onClick }: { title: string; clients: Client[]; statusFilter: string; onStatusFilter: (v: string) => void; onFavorite: (id: string) => void; onClick: (c: Client) => void }) {
  if (clients.length === 0) return null;
  return (
    <div>
      <div className="flex items-center justify-between mb-3 px-1">
        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">{title} ({clients.length})</h3>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        {clients.map(client => (
          <ClientCard key={client._id} client={client} onFavorite={onFavorite} onClick={() => onClick(client)} />
        ))}
      </div>
    </div>
  );
}

// Toast Component
function Toast({ message, type }: { message: string; type: 'success' | 'error' }) {
  return (
    <div className={`fixed top-6 right-6 z-50 bg-white border shadow-lg rounded-xl px-5 py-3 text-sm font-medium animate-slide-in flex items-center gap-2 ${
      type === 'success' ? 'border-emerald-200 text-emerald-800' : 'border-red-200 text-red-800'
    }`}>
      <div className={`h-5 w-5 rounded-full flex items-center justify-center ${type === 'success' ? 'bg-emerald-100' : 'bg-red-100'}`}>
        {type === 'success' ? <CheckCircle2 className="h-3 w-3 text-emerald-600" /> : <X className="h-3 w-3 text-red-600" />}
      </div>
      {message}
    </div>
  );
}

// Need this import
import { CheckCircle2 } from 'lucide-react';