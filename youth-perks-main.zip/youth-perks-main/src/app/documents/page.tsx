'use client';

import { useState, useEffect, useRef } from 'react';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { useAuth } from '@/hooks/useAuth';
import { 
  Plus, Search, Download, FileText, File, Upload, X, Trash2, Edit, 
  FileImage, FileSpreadsheet, FileArchive, Eye, EyeOff, Globe, Users, Lock, Shield
} from 'lucide-react';

interface Document {
  _id: string;
  title: string;
  description: string;
  fileUrl: string;
  cloudinaryId: string;
  fileType: string;
  fileSize: number;
  originalName: string;
  category: string;
  uploadedBy: { _id: string; name: string; email: string; role?: string; department?: string };
  visibility: {
    roles: string[];
    departments: string[];
    users: string[];
  };
  isPublic: boolean;
  tags: string[];
  createdAt: string;
}

const roleLabels: Record<string, string> = {
  super_admin: 'CEO',
  admin: 'Admin',
  executive: 'Executive',
  staff_level3: 'Staff L3',
  staff_level2: 'Staff L2',
  staff_level1: 'Staff L1',
  support: 'Support',
};

const allRoles = ['super_admin', 'admin', 'executive', 'staff_level3', 'staff_level2', 'staff_level1', 'support'];

export default function DocumentsPage() {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showVisibilityModal, setShowVisibilityModal] = useState(false);
  const [editingDoc, setEditingDoc] = useState<Document | null>(null);
  const [visibilityDoc, setVisibilityDoc] = useState<Document | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('internal');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isPublic, setIsPublic] = useState(false);
  const [visibilityRoles, setVisibilityRoles] = useState<string[]>(['super_admin', 'admin']);
  const [visibilityDepartments, setVisibilityDepartments] = useState<string[]>([]);
  
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editCategory, setEditCategory] = useState('internal');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { user, canCreate, canDelete, canEdit } = useAuth();
  const isAdmin = user?.role === 'super_admin' || user?.role === 'admin';
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

  useEffect(() => { fetchDocuments(); }, []);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' };
  };

  const fetchDocuments = async () => {
    try {
      const response = await fetch(`${API_URL}/api/documents`, { headers: getAuthHeaders() });
      if (response.ok) {
        const data = await response.json();
        setDocuments(data);
      } else if (response.status === 401) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
      }
    } catch (error) {
      console.error('Failed to fetch documents:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async () => {
    if (!title || !selectedFile) {
      setError('Title and file are required');
      return;
    }

    setUploading(true);
    setError('');

    try {
      const formData = new FormData();
      formData.append('title', title);
      formData.append('description', description);
      formData.append('category', category);
      formData.append('file', selectedFile);
      formData.append('isPublic', String(isPublic));
      formData.append('visibilityRoles', JSON.stringify(visibilityRoles));
      formData.append('visibilityDepartments', JSON.stringify(visibilityDepartments));

      const token = localStorage.getItem('token');
      const response = await fetch(`${API_URL}/api/documents`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData,
      });

      if (response.ok) {
        const newDoc = await response.json();
        setDocuments([newDoc, ...documents]);
        setShowUploadModal(false);
        resetForm();
        setSuccess('Document uploaded!');
        setTimeout(() => setSuccess(''), 3000);
      } else if (response.status === 401) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
      } else {
        const data = await response.json();
        setError(data.message || 'Failed to upload');
      }
    } catch (error) {
      setError('Failed to upload document');
    } finally {
      setUploading(false);
    }
  };

  const handleUpdate = async () => {
    if (!editingDoc) return;
    setUploading(true);
    setError('');

    try {
      const response = await fetch(`${API_URL}/api/documents/${editingDoc._id}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          title: editTitle,
          description: editDescription,
          category: editCategory,
        }),
      });

      if (response.ok) {
        const updatedDoc = await response.json();
        setDocuments(documents.map(d => d._id === updatedDoc._id ? updatedDoc : d));
        setShowEditModal(false);
        setSuccess('Document updated!');
        setTimeout(() => setSuccess(''), 3000);
      } else {
        const data = await response.json();
        setError(data.message || 'Failed to update');
      }
    } catch (error) {
      setError('Failed to update document');
    } finally {
      setUploading(false);
    }
  };

  const handleUpdateVisibility = async () => {
    if (!visibilityDoc) return;
    setUploading(true);
    setError('');

    try {
      const response = await fetch(`${API_URL}/api/documents/${visibilityDoc._id}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          visibility: {
            roles: visibilityRoles,
            departments: visibilityDepartments,
            users: visibilityDoc.visibility?.users || [],
          },
          isPublic: isPublic,
        }),
      });

      if (response.ok) {
        const updatedDoc = await response.json();
        setDocuments(documents.map(d => d._id === updatedDoc._id ? updatedDoc : d));
        setShowVisibilityModal(false);
        setSuccess('Visibility updated!');
        setTimeout(() => setSuccess(''), 3000);
      } else {
        const data = await response.json();
        setError(data.message || 'Failed to update visibility');
      }
    } catch (error) {
      setError('Failed to update visibility');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (docId: string) => {
    if (!confirm('Delete this document? This cannot be undone.')) return;

    try {
      const response = await fetch(`${API_URL}/api/documents/${docId}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        setDocuments(documents.filter(doc => doc._id !== docId));
        setSuccess('Document deleted!');
        setTimeout(() => setSuccess(''), 3000);
      }
    } catch (error) {
      setError('Failed to delete document');
    }
  };

  const handleDownload = async (doc: Document) => {
    try {
      setError('');
      const token = localStorage.getItem('token');
      const response = await fetch(`${API_URL}/api/documents/download/${doc._id}?token=${token}`);
      if (!response.ok) throw new Error('Download failed');
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = doc.originalName || `${doc.title}.${getExtensionFromMime(doc.fileType)}`;
      document.body.appendChild(a); a.click();
      window.URL.revokeObjectURL(url); document.body.removeChild(a);
    } catch (err) {
      setError('Failed to download file');
      setTimeout(() => setError(''), 3000);
    }
  };

  function getExtensionFromMime(mimeType: string): string {
    const mimeMap: Record<string, string> = {
      'application/pdf': 'pdf', 'application/msword': 'doc',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
      'application/vnd.ms-excel': 'xls',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
      'text/plain': 'txt', 'text/csv': 'csv',
      'image/jpeg': 'jpg', 'image/png': 'png', 'image/gif': 'gif',
      'application/zip': 'zip',
    };
    return mimeMap[mimeType] || 'bin';
  }

  const openEditModal = (doc: Document) => {
    setEditingDoc(doc);
    setEditTitle(doc.title);
    setEditDescription(doc.description || '');
    setEditCategory(doc.category);
    setShowEditModal(true);
  };

  const openVisibilityModal = (doc: Document) => {
    setVisibilityDoc(doc);
    setIsPublic(doc.isPublic || false);
    setVisibilityRoles(doc.visibility?.roles || ['super_admin', 'admin']);
    setVisibilityDepartments(doc.visibility?.departments || []);
    setShowVisibilityModal(true);
  };

  const resetForm = () => {
    setTitle(''); setDescription(''); setCategory('internal');
    setSelectedFile(null); setIsPublic(false);
    setVisibilityRoles(['super_admin', 'admin']); setVisibilityDepartments([]);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const toggleRole = (role: string) => {
    setVisibilityRoles(prev => prev.includes(role) ? prev.filter(r => r !== role) : [...prev, role]);
  };

  const getVisibilityBadge = (doc: Document) => {
    if (doc.isPublic) return { label: 'Public', color: 'bg-green-100 text-green-700', icon: Globe };
    if (doc.visibility?.roles?.length === 0 && doc.visibility?.departments?.length === 0) 
      return { label: 'Admins Only', color: 'bg-red-100 text-red-700', icon: Lock };
    return { label: 'Restricted', color: 'bg-amber-100 text-amber-700', icon: Shield };
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.includes('pdf')) return <FileText className="h-8 w-8 text-red-500" />;
    if (fileType.includes('word') || fileType.includes('document')) return <FileText className="h-8 w-8 text-blue-600" />;
    if (fileType.includes('sheet') || fileType.includes('excel') || fileType.includes('csv')) return <FileSpreadsheet className="h-8 w-8 text-green-600" />;
    if (fileType.includes('image')) return <FileImage className="h-8 w-8 text-purple-500" />;
    if (fileType.includes('zip')) return <FileArchive className="h-8 w-8 text-orange-500" />;
    return <File className="h-8 w-8 text-gray-500" />;
  };

  const getFileTypeLabel = (fileType: string) => {
    if (fileType.includes('pdf')) return 'PDF';
    if (fileType.includes('word') || fileType.includes('document')) return 'DOC';
    if (fileType.includes('sheet') || fileType.includes('excel') || fileType.includes('csv')) return 'XLS';
    if (fileType.includes('image')) return 'IMG';
    if (fileType.includes('zip')) return 'ZIP';
    return 'FILE';
  };

  const formatFileSize = (bytes: number) => {
    if (!bytes) return 'Unknown';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      mou: 'bg-purple-100 text-purple-700 border-purple-200',
      agreement: 'bg-blue-100 text-blue-700 border-blue-200',
      budget: 'bg-green-100 text-green-700 border-green-200',
      report: 'bg-yellow-100 text-yellow-700 border-yellow-200',
      internal: 'bg-gray-100 text-gray-700 border-gray-200',
    };
    return colors[category] || colors.internal;
  };

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || doc.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-96">
          <div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-600 border-t-transparent" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {/* Toast Messages */}
        {success && (
          <div className="fixed top-6 right-6 z-50 bg-white border border-emerald-200 shadow-lg rounded-xl px-5 py-3 text-sm font-medium text-emerald-800 flex items-center gap-2">
            <div className="h-5 w-5 rounded-full bg-emerald-100 flex items-center justify-center">
              <svg className="h-3 w-3 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
            </div>
            {success}
          </div>
        )}
        {error && (
          <div className="fixed top-6 right-6 z-50 bg-white border border-red-200 shadow-lg rounded-xl px-5 py-3 text-sm font-medium text-red-800 flex items-center gap-2">
            <X className="h-4 w-4 text-red-500" />{error}
          </div>
        )}

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-gray-900">Documents</h1>
            <p className="text-sm text-gray-500 mt-1">{documents.length} document{documents.length !== 1 ? 's' : ''} total</p>
          </div>
          {canCreate('documents') && (
            <button onClick={() => { resetForm(); setShowUploadModal(true); }}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white text-sm font-semibold rounded-xl shadow-sm hover:bg-indigo-700 transition-colors">
              <Upload className="h-4 w-4" /> Upload Document
            </button>
          )}
        </div>

        {/* Filters */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input type="text" placeholder="Search documents..." className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
            </div>
            <select className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium text-gray-700" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
              <option value="all">All Categories</option>
              <option value="mou">MoUs</option><option value="agreement">Agreements</option><option value="budget">Budgets</option><option value="report">Reports</option><option value="internal">Internal</option>
            </select>
          </div>
        </div>

        {/* Documents Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDocuments.map((doc) => {
            const visBadge = getVisibilityBadge(doc);
            const VisIcon = visBadge.icon;
            return (
              <div key={doc._id} className="group bg-white rounded-2xl border border-gray-200 p-5 hover:shadow-lg hover:border-gray-300 transition-all duration-200">
                <div className="flex items-start gap-4 mb-4">
                  <div className="shrink-0">{getFileIcon(doc.fileType)}</div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 truncate group-hover:text-indigo-600 transition-colors">{doc.title}</h3>
                    <p className="text-xs text-gray-500 mt-0.5">{new Date(doc.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium rounded-full border ${visBadge.color}`}>
                        <VisIcon className="h-3 w-3" /> {visBadge.label}
                      </span>
                      <span className={`inline-flex px-2 py-0.5 text-xs font-medium rounded-full border ${getCategoryColor(doc.category)}`}>
                        {doc.category}
                      </span>
                    </div>
                  </div>
                </div>

                {doc.description && <p className="text-sm text-gray-600 mb-4 line-clamp-2">{doc.description}</p>}
                {doc.originalName && <p className="text-xs text-gray-400 mb-3 truncate">📄 {doc.originalName}</p>}

                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <span>{formatFileSize(doc.fileSize)}</span>
                    <span>•</span>
                    <span>{doc.uploadedBy?.name || 'Unknown'}</span>
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => handleDownload(doc)} className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg" title="Download"><Download className="h-4 w-4" /></button>
                    {isAdmin && (
                      <button onClick={() => openVisibilityModal(doc)} className="p-2 text-amber-600 hover:bg-amber-50 rounded-lg" title="Visibility"><Eye className="h-4 w-4" /></button>
                    )}
                    {canEdit('documents') && <button onClick={() => openEditModal(doc)} className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg" title="Edit"><Edit className="h-4 w-4" /></button>}
                    {canDelete('documents') && <button onClick={() => handleDelete(doc._id)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg" title="Delete"><Trash2 className="h-4 w-4" /></button>}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Empty State */}
        {filteredDocuments.length === 0 && (
          <div className="text-center py-20 bg-white rounded-2xl border border-gray-200">
            <File className="mx-auto h-12 w-12 text-gray-300 mb-4" />
            <h3 className="text-base font-semibold text-gray-900 mb-1">No documents found</h3>
            <p className="text-sm text-gray-500">{searchTerm ? 'Try adjusting your search.' : 'Upload your first document.'}</p>
          </div>
        )}

        {/* Upload Modal */}
        {showUploadModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={() => { setShowUploadModal(false); resetForm(); }} />
              <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg border border-gray-100">
                <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 rounded-t-2xl flex items-center justify-between z-10">
                  <h2 className="text-lg font-bold text-gray-900">Upload Document</h2>
                  <button onClick={() => { setShowUploadModal(false); resetForm(); }} className="p-2 hover:bg-gray-100 rounded-xl"><X className="h-5 w-5 text-gray-400" /></button>
                </div>
                <div className="p-6 space-y-4">
                  {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm">{error}</div>}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Title *</label>
                    <input type="text" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500" value={title} onChange={(e) => setTitle(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Description</label>
                    <textarea className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none" rows={2} value={description} onChange={(e) => setDescription(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Category</label>
                    <select className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50" value={category} onChange={(e) => setCategory(e.target.value)}>
                      <option value="mou">MoU</option><option value="agreement">Agreement</option><option value="budget">Budget</option><option value="report">Report</option><option value="internal">Internal</option>
                    </select>
                  </div>

                  {/* Visibility Section */}
                  <div>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={isPublic} onChange={(e) => setIsPublic(e.target.checked)} className="rounded" />
                      <span className="text-sm font-semibold text-gray-700">Make this document public (visible to all roles)</span>
                    </label>
                  </div>
                  {!isPublic && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Visible to Roles</label>
                      <div className="flex flex-wrap gap-2">
                        {allRoles.map(role => (
                          <button key={role} onClick={() => toggleRole(role)}
                            className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-all ${
                              visibilityRoles.includes(role)
                                ? 'bg-indigo-50 border-indigo-300 text-indigo-700'
                                : 'bg-white border-gray-200 text-gray-500 hover:border-gray-300'
                            }`}>
                            {roleLabels[role] || role}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">File *</label>
                    <div className="border-2 border-dashed border-gray-300 rounded-xl p-5 text-center">
                      <input type="file" ref={fileInputRef} className="w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-indigo-600 file:text-white"
                        onChange={(e) => setSelectedFile(e.target.files?.[0] || null)} />
                    </div>
                    {selectedFile && <p className="text-sm text-gray-600 mt-2">Selected: {selectedFile.name}</p>}
                  </div>
                </div>
                <div className="sticky bottom-0 bg-white border-t border-gray-100 px-6 py-4 rounded-b-2xl flex justify-end gap-3">
                  <button onClick={() => { setShowUploadModal(false); resetForm(); }} className="px-5 py-2.5 text-sm font-semibold text-gray-700 border border-gray-200 rounded-xl">Cancel</button>
                  <button onClick={handleUpload} disabled={uploading} className="px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 disabled:opacity-50">
                    {uploading ? 'Uploading...' : 'Upload Document'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Visibility Modal (Admin only) */}
        {showVisibilityModal && visibilityDoc && (
          <div className="fixed inset-0 z-50 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setShowVisibilityModal(false)} />
              <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg border border-gray-100">
                <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 rounded-t-2xl flex items-center justify-between">
                  <h2 className="text-lg font-bold text-gray-900">Visibility: {visibilityDoc.title}</h2>
                  <button onClick={() => setShowVisibilityModal(false)} className="p-2 hover:bg-gray-100 rounded-xl"><X className="h-5 w-5 text-gray-400" /></button>
                </div>
                <div className="p-6 space-y-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={isPublic} onChange={(e) => setIsPublic(e.target.checked)} className="rounded" />
                    <span className="text-sm font-semibold text-gray-700">Public (visible to everyone)</span>
                  </label>
                  {!isPublic && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Visible to Roles</label>
                      <div className="flex flex-wrap gap-2">
                        {allRoles.map(role => (
                          <button key={role} onClick={() => toggleRole(role)}
                            className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-all ${
                              visibilityRoles.includes(role)
                                ? 'bg-indigo-50 border-indigo-300 text-indigo-700'
                                : 'bg-white border-gray-200 text-gray-500 hover:border-gray-300'
                            }`}>
                            {roleLabels[role] || role}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                <div className="sticky bottom-0 bg-white border-t border-gray-100 px-6 py-4 rounded-b-2xl flex justify-end gap-3">
                  <button onClick={() => setShowVisibilityModal(false)} className="px-5 py-2.5 text-sm font-semibold text-gray-700 border border-gray-200 rounded-xl">Cancel</button>
                  <button onClick={handleUpdateVisibility} disabled={uploading} className="px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700">
                    {uploading ? 'Saving...' : 'Save Visibility'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Edit Modal */}
        {showEditModal && editingDoc && (
          <div className="fixed inset-0 z-50 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setShowEditModal(false)} />
              <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg border border-gray-100">
                <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 rounded-t-2xl flex items-center justify-between">
                  <h2 className="text-lg font-bold">Edit Document</h2>
                  <button onClick={() => setShowEditModal(false)} className="p-2 hover:bg-gray-100 rounded-xl"><X className="h-5 w-5 text-gray-400" /></button>
                </div>
                <div className="p-6 space-y-4">
                  <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Title</label><input type="text" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50" value={editTitle} onChange={(e) => setEditTitle(e.target.value)} /></div>
                  <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Description</label><textarea className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 resize-none" rows={3} value={editDescription} onChange={(e) => setEditDescription(e.target.value)} /></div>
                  <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Category</label><select className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50" value={editCategory} onChange={(e) => setEditCategory(e.target.value)}>
                    <option value="mou">MoU</option><option value="agreement">Agreement</option><option value="budget">Budget</option><option value="report">Report</option><option value="internal">Internal</option>
                  </select></div>
                </div>
                <div className="sticky bottom-0 bg-white border-t border-gray-100 px-6 py-4 rounded-b-2xl flex justify-end gap-3">
                  <button onClick={() => setShowEditModal(false)} className="px-5 py-2.5 text-sm font-semibold text-gray-700 border border-gray-200 rounded-xl">Cancel</button>
                  <button onClick={handleUpdate} disabled={uploading} className="px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700">Save Changes</button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}