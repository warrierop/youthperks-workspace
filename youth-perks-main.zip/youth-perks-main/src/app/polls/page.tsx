'use client';

import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Button } from '@/components/ui/button';
import { Plus, Search, MessageSquare, Users, BarChart3, Clock, Vote, Eye, Edit, Trash2, X } from 'lucide-react';
import { ProtectedPage } from '@/components/auth/ProtectedPage';

interface Response {
  _id: string;
  userId: { _id: string; name: string; email: string } | null;
  selectedOption: number;
  submittedAt: string;
}

interface Poll {
  _id: string;
  question: string;
  description: string;
  options: string[];
  targetRoles: string[];
  targetUsers: string[];
  createdBy: { _id: string; name: string; email: string };
  isActive: boolean;
  isExpired: boolean;
  endDate?: string;
  allowMultiple: boolean;
  isAnonymous: boolean;
  responses: Response[];
  totalResponses: number;
  createdAt: string;
}

export default function PollsPage() {
  const [polls, setPolls] = useState<Poll[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showModal, setShowModal] = useState(false);
  const [editingPoll, setEditingPoll] = useState<Poll | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    question: '',
    description: '',
    options: ['', ''],
    targetRoles: [] as string[],
    endDate: '',
    allowMultiple: false,
    isAnonymous: false,
  });

  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

  useEffect(() => {
    fetchPolls();
  }, []);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    };
  };

  const fetchPolls = async () => {
    try {
      const response = await fetch(`${API_URL}/api/polls`, {
        headers: getAuthHeaders(),
      });
      if (response.ok) {
        const data = await response.json();
        setPolls(data);
      }
    } catch (error) {
      console.error('Failed to fetch polls:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!formData.question || formData.options.filter(o => o.trim()).length < 2) {
      setError('Question and at least 2 options are required');
      return;
    }

    setSubmitting(true);
    setError('');

    try {
      const url = editingPoll
        ? `${API_URL}/api/polls/${editingPoll._id}`
        : `${API_URL}/api/polls`;
      const method = editingPoll ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: getAuthHeaders(),
        body: JSON.stringify({
          ...formData,
          options: formData.options.filter(o => o.trim()),
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (editingPoll) {
          setPolls(polls.map(p => p._id === data._id ? data : p));
        } else {
          setPolls([data, ...polls]);
        }
        closeModal();
        setSuccess(editingPoll ? 'Poll updated!' : 'Poll created!');
        setTimeout(() => setSuccess(''), 3000);
      } else {
        const data = await response.json();
        setError(data.message || 'Operation failed');
      }
    } catch (error) {
      setError('Failed to save poll');
    } finally {
      setSubmitting(false);
    }
  };

  const handleVote = async (pollId: string, selectedOption: number) => {
    try {
      const response = await fetch(`${API_URL}/api/polls/${pollId}/vote`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ selectedOption }),
      });

      if (response.ok) {
        const data = await response.json();
        setPolls(polls.map(p => p._id === data.poll._id ? data.poll : p));
        setSuccess('Vote submitted!');
        setTimeout(() => setSuccess(''), 2000);
      } else {
        const data = await response.json();
        setError(data.message);
      }
    } catch (error) {
      setError('Failed to submit vote');
    }
  };

  const handleDelete = async (pollId: string) => {
    if (!confirm('Delete this poll?')) return;
    try {
      const response = await fetch(`${API_URL}/api/polls/${pollId}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });
      if (response.ok) {
        setPolls(polls.filter(p => p._id !== pollId));
        setSuccess('Poll deleted!');
        setTimeout(() => setSuccess(''), 3000);
      }
    } catch (error) {
      setError('Failed to delete poll');
    }
  };

  const handleToggleActive = async (poll: Poll) => {
    try {
      const response = await fetch(`${API_URL}/api/polls/${poll._id}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({ isActive: !poll.isActive }),
      });
      if (response.ok) {
        const data = await response.json();
        setPolls(polls.map(p => p._id === data._id ? data : p));
      }
    } catch (error) {
      console.error('Failed to toggle poll status:', error);
    }
  };

  const addOption = () => {
    if (formData.options.length >= 10) return;
    setFormData({ ...formData, options: [...formData.options, ''] });
  };

  const removeOption = (index: number) => {
    if (formData.options.length <= 2) return;
    setFormData({
      ...formData,
      options: formData.options.filter((_, i) => i !== index),
    });
  };

  const updateOption = (index: number, value: string) => {
    const newOptions = [...formData.options];
    newOptions[index] = value;
    setFormData({ ...formData, options: newOptions });
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingPoll(null);
    setError('');
    setFormData({
      question: '',
      description: '',
      options: ['', ''],
      targetRoles: [],
      endDate: '',
      allowMultiple: false,
      isAnonymous: false,
    });
  };

  const openEditModal = (poll: Poll) => {
    setEditingPoll(poll);
    setFormData({
      question: poll.question,
      description: poll.description || '',
      options: poll.options,
      targetRoles: poll.targetRoles || [],
      endDate: poll.endDate ? new Date(poll.endDate).toISOString().split('T')[0] : '',
      allowMultiple: poll.allowMultiple,
      isAnonymous: poll.isAnonymous,
    });
    setShowModal(true);
  };

  const getOptionStats = (poll: Poll, optionIndex: number) => {
    const count = poll.responses.filter(r => r.selectedOption === optionIndex).length;
    const percentage = poll.totalResponses > 0 ? Math.round((count / poll.totalResponses) * 100) : 0;
    return { count, percentage };
  };

  const hasUserVoted = (poll: Poll) => {
    // Simple check - in a real app you'd compare with current user ID from token
    return poll.responses.length > 0;
  };

  const filteredPolls = polls.filter(poll => {
    const matchesSearch = poll.question.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      statusFilter === 'all' ||
      (statusFilter === 'active' && poll.isActive && !poll.isExpired) ||
      (statusFilter === 'expired' && poll.isExpired) ||
      (statusFilter === 'inactive' && !poll.isActive);
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <ProtectedPage page="polls">
        <DashboardLayout>
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
          </div>
        </DashboardLayout>
      </ProtectedPage>
    );
  }

  return (
    <ProtectedPage page="polls">
      <DashboardLayout>
        <div className="p-4 lg:p-6 space-y-6">
        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">{success}</div>
        )}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">{error}</div>
        )}

        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Polls</h1>
            <p className="text-gray-500 mt-1">Create and manage team polls</p>
          </div>
          <Button onClick={() => setShowModal(true)} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Create Poll
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { label: 'Total Polls', value: polls.length, icon: MessageSquare, color: 'bg-blue-500' },
            { label: 'Active', value: polls.filter(p => p.isActive && !p.isExpired).length, icon: BarChart3, color: 'bg-green-500' },
            { label: 'Total Votes', value: polls.reduce((s, p) => s + p.totalResponses, 0), icon: Users, color: 'bg-purple-500' },
          ].map((stat) => (
            <div key={stat.label} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center gap-4">
                <div className={`p-3 rounded-lg ${stat.color}`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-500">{stat.label}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search polls..."
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <select
              className="px-4 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">All</option>
              <option value="active">Active</option>
              <option value="expired">Expired</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>

        {/* Polls List */}
        <div className="space-y-4">
          {filteredPolls.map((poll) => (
            <div key={poll._id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900">{poll.question}</h3>
                  <div className="flex items-center gap-3 mt-2 text-sm text-gray-500">
                    <span className={`px-2 py-0.5 text-xs rounded-full ${!poll.isActive ? 'bg-gray-100 text-gray-700' :
                      poll.isExpired ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
                      }`}>
                      {!poll.isActive ? 'Inactive' : poll.isExpired ? 'Expired' : 'Active'}
                    </span>
                    <span>{poll.totalResponses} responses</span>
                    {poll.endDate && <span>Ends: {new Date(poll.endDate).toLocaleDateString()}</span>}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" onClick={() => handleToggleActive(poll)}>
                    {poll.isActive ? 'Pause' : 'Activate'}
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => openEditModal(poll)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(poll._id)}>
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </Button>
                </div>
              </div>

              {/* Options with bars */}
              <div className="space-y-2">
                {poll.options.map((option, idx) => {
                  const stats = getOptionStats(poll, idx);
                  return (
                    <div key={idx} className="flex items-center gap-3">
                      <button
                        onClick={() => handleVote(poll._id, idx)}
                        disabled={!poll.isActive || poll.isExpired}
                        className="flex-1 flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 border border-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <span className="text-sm font-medium text-gray-900 flex-1">{option}</span>
                        <span className="text-sm text-gray-500">{stats.count} ({stats.percentage}%)</span>
                        <div className="w-24 bg-gray-100 rounded-full h-2">
                          <div
                            className="bg-indigo-500 h-2 rounded-full transition-all"
                            style={{ width: `${stats.percentage}%` }}
                          />
                        </div>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {filteredPolls.length === 0 && (
          <div className="text-center py-16 bg-white rounded-xl border border-gray-100">
            <MessageSquare className="mx-auto h-12 w-12 text-gray-300" />
            <h3 className="mt-4 text-lg font-medium text-gray-900">No polls found</h3>
            <Button className="mt-4" onClick={() => setShowModal(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Poll
            </Button>
          </div>
        )}

        {/* Create/Edit Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold">{editingPoll ? 'Edit Poll' : 'Create Poll'}</h2>
                  <button onClick={closeModal} className="p-2 hover:bg-gray-100 rounded-lg">
                    <X className="h-5 w-5" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Question *</label>
                    <input
                      type="text"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      value={formData.question}
                      onChange={(e) => setFormData({ ...formData, question: e.target.value })}
                      placeholder="What would you like to ask?"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                    <textarea
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      rows={2}
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Options * (min 2)</label>
                    {formData.options.map((option, idx) => (
                      <div key={idx} className="flex gap-2 mb-2">
                        <input
                          type="text"
                          className="flex-1 border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          value={option}
                          onChange={(e) => updateOption(idx, e.target.value)}
                          placeholder={`Option ${idx + 1}`}
                        />
                        {formData.options.length > 2 && (
                          <button onClick={() => removeOption(idx)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg">
                            <X className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    ))}
                    {formData.options.length < 10 && (
                      <Button variant="outline" size="sm" onClick={addOption}>
                        <Plus className="h-4 w-4 mr-1" /> Add Option
                      </Button>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
                    <input
                      type="date"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      value={formData.endDate}
                      onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                    />
                  </div>

                  <div className="flex gap-4">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={formData.allowMultiple}
                        onChange={(e) => setFormData({ ...formData, allowMultiple: e.target.checked })}
                        className="rounded"
                      />
                      <span className="text-sm">Allow vote changes</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={formData.isAnonymous}
                        onChange={(e) => setFormData({ ...formData, isAnonymous: e.target.checked })}
                        className="rounded"
                      />
                      <span className="text-sm">Anonymous</span>
                    </label>
                  </div>
                </div>

                <div className="flex justify-end gap-3 mt-6 pt-6 border-t">
                  <Button variant="outline" onClick={closeModal}>Cancel</Button>
                  <Button onClick={handleSubmit} disabled={submitting}>
                    {submitting ? 'Saving...' : editingPoll ? 'Update' : 'Create'}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      </DashboardLayout>
    </ProtectedPage>
  );
}