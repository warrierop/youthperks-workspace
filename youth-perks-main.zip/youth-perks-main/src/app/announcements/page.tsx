'use client';

import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Button } from '@/components/ui/button';
import { Plus, Search, Megaphone, Calendar, User, Edit, Trash2, Pin, PinOff, Eye, EyeOff, X } from 'lucide-react';
import { ProtectedPage } from '@/components/auth/ProtectedPage';

interface Announcement {
  _id: string;
  title: string;
  content: string;
  postedBy: { _id: string; name: string; email: string };
  visibility: { roles: string[]; users: string[] };
  priority: 'low' | 'medium' | 'high';
  category: 'general' | 'important' | 'urgent' | 'policy' | 'event';
  isActive: boolean;
  isExpired: boolean;
  pinned: boolean;
  expiresAt?: string;
  createdAt: string;
}

export default function AnnouncementsPage() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [showModal, setShowModal] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    title: '',
    content: '',
    priority: 'medium' as 'low' | 'medium' | 'high',
    category: 'general' as 'general' | 'important' | 'urgent' | 'policy' | 'event',
    visibilityRoles: [] as string[],
    pinned: false,
    expiresAt: '',
  });

  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

  useEffect(() => {
    fetchAnnouncements();
  }, []);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
  };

  const fetchAnnouncements = async () => {
    try {
      const response = await fetch(`${API_URL}/api/announcements`, { headers: getAuthHeaders() });
      if (response.ok) {
        setAnnouncements(await response.json());
      }
    } catch (error) {
      console.error('Failed to fetch announcements:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!formData.title || !formData.content) {
      setError('Title and content are required');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      const url = editingAnnouncement
        ? `${API_URL}/api/announcements/${editingAnnouncement._id}`
        : `${API_URL}/api/announcements`;
      const method = editingAnnouncement ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: getAuthHeaders(),
        body: JSON.stringify({
          ...formData,
          visibility: {
            roles: formData.visibilityRoles,
            users: [],
          },
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (editingAnnouncement) {
          setAnnouncements(announcements.map(a => a._id === data._id ? data : a));
        } else {
          setAnnouncements([data, ...announcements]);
        }
        closeModal();
        setSuccess(editingAnnouncement ? 'Announcement updated!' : 'Announcement created!');
        setTimeout(() => setSuccess(''), 3000);
      } else {
        const data = await response.json();
        setError(data.message || 'Operation failed');
      }
    } catch {
      setError('Failed to save announcement');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleActive = async (announcement: Announcement) => {
    try {
      const response = await fetch(`${API_URL}/api/announcements/${announcement._id}/toggle`, {
        method: 'PUT',
        headers: getAuthHeaders(),
      });
      if (response.ok) {
        const data = await response.json();
        setAnnouncements(announcements.map(a => a._id === announcement._id ? data.announcement : a));
      }
    } catch {
      setError('Failed to toggle status');
    }
  };

  const handleTogglePin = async (announcement: Announcement) => {
    try {
      const response = await fetch(`${API_URL}/api/announcements/${announcement._id}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({ pinned: !announcement.pinned }),
      });
      if (response.ok) {
        const data = await response.json();
        setAnnouncements(announcements.map(a => a._id === data._id ? data : a));
      }
    } catch {
      setError('Failed to toggle pin');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this announcement?')) return;
    try {
      await fetch(`${API_URL}/api/announcements/${id}`, { method: 'DELETE', headers: getAuthHeaders() });
      setAnnouncements(announcements.filter(a => a._id !== id));
      setSuccess('Announcement deleted!');
      setTimeout(() => setSuccess(''), 3000);
    } catch {
      setError('Failed to delete announcement');
    }
  };

  const openEditModal = (announcement: Announcement) => {
    setEditingAnnouncement(announcement);
    setFormData({
      title: announcement.title,
      content: announcement.content,
      priority: announcement.priority,
      category: announcement.category,
      visibilityRoles: announcement.visibility?.roles || [],
      pinned: announcement.pinned,
      expiresAt: announcement.expiresAt ? new Date(announcement.expiresAt).toISOString().split('T')[0] : '',
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingAnnouncement(null);
    setError('');
    setFormData({
      title: '', content: '', priority: 'medium', category: 'general',
      visibilityRoles: [], pinned: false, expiresAt: '',
    });
  };

  const getPriorityStyles = (priority: string) => {
    switch (priority) {
      case 'high': return { bg: 'bg-red-50 border-red-400', badge: 'bg-red-100 text-red-700', icon: '🔴' };
      case 'medium': return { bg: 'bg-yellow-50 border-yellow-400', badge: 'bg-yellow-100 text-yellow-700', icon: '🟡' };
      default: return { bg: 'bg-blue-50 border-blue-400', badge: 'bg-blue-100 text-blue-700', icon: '🔵' };
    }
  };

  const getCategoryBadge = (category: string) => {
    const styles: Record<string, string> = {
      general: 'bg-gray-100 text-gray-700',
      important: 'bg-orange-100 text-orange-700',
      urgent: 'bg-red-100 text-red-700',
      policy: 'bg-purple-100 text-purple-700',
      event: 'bg-green-100 text-green-700',
    };
    return styles[category] || styles.general;
  };

  const filteredAnnouncements = announcements.filter(a => {
    const matchesSearch = a.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPriority = priorityFilter === 'all' || a.priority === priorityFilter;
    const matchesCategory = categoryFilter === 'all' || a.category === categoryFilter;
    return matchesSearch && matchesPriority && matchesCategory;
  });

  const sortedAnnouncements = [...filteredAnnouncements].sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  if (loading) {
    return (
      <ProtectedPage page="announcements">
        <DashboardLayout>
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
          </div>
        </DashboardLayout>
      </ProtectedPage>
    );
  }

  return (
    <ProtectedPage page="announcements">
      <DashboardLayout>
        <div className="p-4 lg:p-6 space-y-6">
        {success && <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">{success}</div>}
        {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">{error}</div>}

        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Announcements</h1>
            <p className="text-gray-500 mt-1">Manage internal announcements and communications</p>
          </div>
          <Button onClick={() => setShowModal(true)} className="flex items-center gap-2">
            <Plus className="h-4 w-4" /> Create Announcement
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total', value: announcements.length, color: 'bg-blue-500' },
            { label: 'Active', value: announcements.filter(a => a.isActive).length, color: 'bg-green-500' },
            { label: 'High Priority', value: announcements.filter(a => a.priority === 'high').length, color: 'bg-red-500' },
            { label: 'Pinned', value: announcements.filter(a => a.pinned).length, color: 'bg-purple-500' },
          ].map(s => (
            <div key={s.label} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <p className="text-2xl font-bold text-gray-900">{s.value}</p>
              <p className="text-sm text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text" placeholder="Search announcements..."
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <select className="px-4 py-2.5 border border-gray-200 rounded-lg" value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)}>
              <option value="all">All Priority</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
            <select className="px-4 py-2.5 border border-gray-200 rounded-lg" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
              <option value="all">All Categories</option>
              <option value="general">General</option>
              <option value="important">Important</option>
              <option value="urgent">Urgent</option>
              <option value="policy">Policy</option>
              <option value="event">Event</option>
            </select>
          </div>
        </div>

        {/* Announcements List */}
        <div className="space-y-4">
          {sortedAnnouncements.map((announcement) => {
            const priorityStyle = getPriorityStyles(announcement.priority);
            return (
              <div
                key={announcement._id}
                className={`bg-white rounded-xl shadow-sm border-l-4 p-6 ${priorityStyle.bg} ${announcement.pinned ? 'ring-2 ring-indigo-300' : ''}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      {announcement.pinned && <Pin className="h-4 w-4 text-indigo-500" />}
                      <span className="text-lg">{priorityStyle.icon}</span>
                      <h3 className="text-lg font-semibold text-gray-900">{announcement.title}</h3>
                      <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${priorityStyle.badge}`}>
                        {announcement.priority}
                      </span>
                      <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${getCategoryBadge(announcement.category)}`}>
                        {announcement.category}
                      </span>
                      {announcement.isActive ? (
                        <span className="px-2 py-0.5 text-xs font-medium bg-green-100 text-green-700 rounded-full">Active</span>
                      ) : (
                        <span className="px-2 py-0.5 text-xs font-medium bg-gray-100 text-gray-700 rounded-full">Inactive</span>
                      )}
                    </div>
                    <p className="text-gray-600 whitespace-pre-wrap">{announcement.content}</p>
                    <div className="flex items-center gap-4 mt-4 text-sm text-gray-500">
                      <span className="flex items-center gap-1"><User className="h-4 w-4" /> {announcement.postedBy?.name || 'Admin'}</span>
                      <span className="flex items-center gap-1"><Calendar className="h-4 w-4" /> {new Date(announcement.createdAt).toLocaleDateString()}</span>
                      {announcement.expiresAt && (
                        <span className="flex items-center gap-1">
                          Expires: {new Date(announcement.expiresAt).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-1 ml-4">
                    <Button variant="ghost" size="sm" onClick={() => handleTogglePin(announcement)} title={announcement.pinned ? 'Unpin' : 'Pin'}>
                      {announcement.pinned ? <PinOff className="h-4 w-4" /> : <Pin className="h-4 w-4" />}
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => handleToggleActive(announcement)} title={announcement.isActive ? 'Deactivate' : 'Activate'}>
                      {announcement.isActive ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => openEditModal(announcement)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDelete(announcement._id)}>
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {sortedAnnouncements.length === 0 && (
          <div className="text-center py-16 bg-white rounded-xl border border-gray-100">
            <Megaphone className="mx-auto h-12 w-12 text-gray-300" />
            <h3 className="mt-4 text-lg font-medium text-gray-900">No announcements found</h3>
            <Button className="mt-4" onClick={() => setShowModal(true)}>
              <Plus className="h-4 w-4 mr-2" /> Create Announcement
            </Button>
          </div>
        )}

        {/* Create/Edit Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold">{editingAnnouncement ? 'Edit' : 'Create'} Announcement</h2>
                  <button onClick={closeModal} className="p-2 hover:bg-gray-100 rounded-lg"><X className="h-5 w-5" /></button>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
                    <input type="text" className="w-full border border-gray-200 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      value={formData.title} onChange={(e) => setFormData({ ...formData, title: e.target.value })} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Content *</label>
                    <textarea className="w-full border border-gray-200 rounded-lg px-3 py-2.5 min-h-[200px] focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      value={formData.content} onChange={(e) => setFormData({ ...formData, content: e.target.value })} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
                      <select className="w-full border border-gray-200 rounded-lg px-3 py-2.5"
                        value={formData.priority} onChange={(e) => setFormData({ ...formData, priority: e.target.value as any })}>
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                      <select className="w-full border border-gray-200 rounded-lg px-3 py-2.5"
                        value={formData.category} onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}>
                        <option value="general">General</option>
                        <option value="important">Important</option>
                        <option value="urgent">Urgent</option>
                        <option value="policy">Policy</option>
                        <option value="event">Event</option>
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Expiry Date</label>
                      <input type="date" className="w-full border border-gray-200 rounded-lg px-3 py-2.5"
                        value={formData.expiresAt} onChange={(e) => setFormData({ ...formData, expiresAt: e.target.value })} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Visibility Roles</label>
                      <div className="flex gap-2 mt-2">
                        {['super_admin', 'admin'].map(role => (
                          <label key={role} className="flex items-center gap-1">
                            <input type="checkbox" checked={formData.visibilityRoles.includes(role)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFormData({ ...formData, visibilityRoles: [...formData.visibilityRoles, role] });
                                } else {
                                  setFormData({ ...formData, visibilityRoles: formData.visibilityRoles.filter(r => r !== role) });
                                }
                              }} />
                            <span className="text-sm">{role.replace('_', ' ')}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" checked={formData.pinned}
                      onChange={(e) => setFormData({ ...formData, pinned: e.target.checked })} />
                    <span className="text-sm">Pin this announcement</span>
                  </label>
                </div>
                <div className="flex justify-end gap-3 mt-6 pt-6 border-t">
                  <Button variant="outline" onClick={closeModal}>Cancel</Button>
                  <Button onClick={handleSubmit} disabled={submitting}>
                    {submitting ? 'Saving...' : editingAnnouncement ? 'Update' : 'Create'}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      </DashboardLayout>
    </ProtectedPage>
  );
}