'use client';

import { useState, useEffect, useRef } from 'react';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { useAuth } from '@/hooks/useAuth';
import {
  Plus, Search, FileBarChart, Calendar, User, Download, Edit, Trash2,
  Send, Eye, CheckCircle, XCircle, AlertCircle, X, Paperclip, File,
  ChevronDown, Filter, Flag, FileText, FileSpreadsheet, FileImage, FileArchive
} from 'lucide-react';

interface Attachment {
  _id: string;
  filename: string;
  originalName: string;
  url: string;
  fileType: string;
  fileSize: number;
  uploadedAt: string;
}

interface Review {
  reviewedBy: { _id: string; name: string; email: string };
  comment: string;
  decision: string;
  reviewedAt: string;
}

interface Report {
  _id: string;
  title: string;
  content: string;
  summary: string;
  achievements: string;
  challenges: string;
  goals: string;
  submittedBy: { _id: string; name: string; email: string; department?: string };
  department: string;
  month: string;
  year: number;
  type: string;
  status: string;
  reviewedBy?: { _id: string; name: string };
  review?: Review;
  attachments: Attachment[];
  tags: string[];
  createdAt: string;
}

const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];

const statusOptions = [
  { value: 'draft', label: 'Draft', color: 'bg-slate-100 text-slate-700 border-slate-200' },
  { value: 'submitted', label: 'Submitted', color: 'bg-blue-50 text-blue-700 border-blue-200' },
  { value: 'reviewed', label: 'Reviewed', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  { value: 'changes_requested', label: 'Changes Requested', color: 'bg-amber-50 text-amber-700 border-amber-200' },
];

export default function ReportsPage() {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [editingReport, setEditingReport] = useState<Report | null>(null);
  const [reviewingReport, setReviewingReport] = useState<Report | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [reviewForm, setReviewForm] = useState({ decision: 'approved', comment: '' });
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [removeAttachmentIds, setRemoveAttachmentIds] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    title: '', content: '', summary: '', achievements: '', challenges: '', goals: '',
    month: '', year: new Date().getFullYear().toString(), type: 'monthly',
    department: '', tags: [] as string[],
  });

  const { user, canCreate, canEdit, canDelete } = useAuth();
  const isAdmin = user?.role === 'super_admin' || user?.role === 'admin';
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
  };

  useEffect(() => { fetchReports(); }, [searchTerm, statusFilter, typeFilter]);

  const fetchReports = async () => {
    try {
      const params = new URLSearchParams();
      if (statusFilter !== 'all') params.append('status', statusFilter);
      if (typeFilter !== 'all') params.append('type', typeFilter);
      if (searchTerm) params.append('search', searchTerm);
      const res = await fetch(`${API_URL}/api/reports?${params}`, { headers: getAuthHeaders() });
      if (res.ok) setReports(await res.json());
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const handleSubmit = async () => {
    if (!formData.title || !formData.content || !formData.month || !formData.year || !formData.type) {
      setError('Please fill in all required fields'); return;
    }
    setSubmitting(true); setError('');
    try {
      const fd = new FormData();
      fd.append('title', formData.title); fd.append('content', formData.content);
      fd.append('summary', formData.summary); fd.append('achievements', formData.achievements);
      fd.append('challenges', formData.challenges); fd.append('goals', formData.goals);
      fd.append('month', formData.month); fd.append('year', formData.year);
      fd.append('type', formData.type); fd.append('department', formData.department);
      if (formData.tags.length > 0) fd.append('tags', JSON.stringify(formData.tags));
      selectedFiles.forEach(f => fd.append('attachments', f));
      if (editingReport && removeAttachmentIds.length > 0) fd.append('removeAttachments', JSON.stringify(removeAttachmentIds));

      const token = localStorage.getItem('token');
      const url = editingReport ? `${API_URL}/api/reports/${editingReport._id}` : `${API_URL}/api/reports`;
      const method = editingReport ? 'PUT' : 'POST';
      const res = await fetch(url, { method, headers: { 'Authorization': `Bearer ${token}` }, body: fd });

      if (res.ok) {
        const data = await res.json();
        setReports(editingReport ? reports.map(r => r._id === data._id ? data : r) : [data, ...reports]);
        closeModal();
        setSuccess(editingReport ? 'Report updated!' : 'Report created!');
        setTimeout(() => setSuccess(''), 3000);
      } else { const d = await res.json(); setError(d.message || 'Failed'); }
    } catch { setError('Failed to save'); }
    finally { setSubmitting(false); }
  };

  const handleSubmitForReview = async (id: string) => {
    try {
      await fetch(`${API_URL}/api/reports/${id}/submit`, { method: 'POST', headers: getAuthHeaders() });
      fetchReports(); setSuccess('Submitted for review!'); setTimeout(() => setSuccess(''), 2000);
    } catch { setError('Failed to submit'); }
  };

  const handleReview = async () => {
    if (!reviewingReport) return;
    setSubmitting(true);
    try {
      const res = await fetch(`${API_URL}/api/reports/${reviewingReport._id}/review`, {
        method: 'POST', headers: getAuthHeaders(), body: JSON.stringify(reviewForm),
      });
      if (res.ok) { fetchReports(); setShowReviewModal(false); setSuccess('Review submitted!'); setTimeout(() => setSuccess(''), 2000); }
      else { const d = await res.json(); setError(d.message); }
    } catch { setError('Failed to submit review'); }
    finally { setSubmitting(false); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this report permanently?')) return;
    try {
      await fetch(`${API_URL}/api/reports/${id}`, { method: 'DELETE', headers: getAuthHeaders() });
      fetchReports(); setSuccess('Report deleted!'); setTimeout(() => setSuccess(''), 3000);
    } catch { setError('Failed to delete'); }
  };

  // ✅ DOWNLOAD ATTACHMENT - Direct Cloudinary URL
// ✅ DOWNLOAD ATTACHMENT - With proper filename and extension
const handleDownloadAttachment = async (attachment: Attachment) => {
  try {
    // Fetch the file from Cloudinary
    const response = await fetch(attachment.url);
    const blob = await response.blob();
    
    // Create a blob URL
    const url = window.URL.createObjectURL(blob);
    
    // Create download link with proper filename
    const a = document.createElement('a');
    a.href = url;
    
    // Use original name (which includes extension)
    // If originalName doesn't have extension, add it from MIME type
    let filename = attachment.originalName;
    if (!filename.includes('.')) {
      const ext = getExtensionFromMime(attachment.fileType);
      filename = `${filename}.${ext}`;
    }
    
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    
    // Cleanup
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  } catch (err) {
    console.error('Download error:', err);
    setError('Failed to download file');
  }
};

// Helper function to get extension from MIME type
function getExtensionFromMime(mimeType: string): string {
  const mimeMap: Record<string, string> = {
    'application/pdf': 'pdf',
    'application/msword': 'doc',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
    'application/vnd.ms-excel': 'xls',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
    'application/vnd.ms-powerpoint': 'ppt',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
    'text/plain': 'txt',
    'text/csv': 'csv',
    'image/jpeg': 'jpg',
    'image/png': 'png',
    'image/gif': 'gif',
    'image/webp': 'webp',
    'application/zip': 'zip',
    'application/x-zip-compressed': 'zip',
    'application/octet-stream': 'bin',
  };
  return mimeMap[mimeType] || 'bin';
}

  // ✅ DOWNLOAD ALL ATTACHMENTS
  const handleDownloadAllAttachments = (report: Report) => {
    if (report.attachments.length === 0) return;
    report.attachments.forEach((att, i) => {
      setTimeout(() => window.open(att.url, '_blank'), i * 300);
    });
  };

  // ✅ EXPORT REPORT AS JSON
  const handleExport = (report: Report) => {
    const token = localStorage.getItem('token');
    window.open(`${API_URL}/api/reports/export/${report._id}?token=${token}`, '_blank');
  };

  const openEditModal = (report: Report) => {
    setEditingReport(report);
    setFormData({
      title: report.title, content: report.content, summary: report.summary || '',
      achievements: report.achievements || '', challenges: report.challenges || '',
      goals: report.goals || '', month: report.month, year: report.year.toString(),
      type: report.type, department: report.department || '', tags: report.tags || [],
    });
    setSelectedFiles([]); setRemoveAttachmentIds([]);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false); setEditingReport(null); setError(''); setSelectedFiles([]); setRemoveAttachmentIds([]);
    setFormData({ title:'', content:'', summary:'', achievements:'', challenges:'', goals:'', month:'', year:new Date().getFullYear().toString(), type:'monthly', department:'', tags:[] });
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const formatSize = (bytes: number) => {
    if (!bytes) return '0 KB';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
  };

  const getFileIcon = (fileType: string) => {
    if (fileType?.includes('pdf')) return <FileText className="h-8 w-8 text-red-500" />;
    if (fileType?.includes('word') || fileType?.includes('document')) return <FileText className="h-8 w-8 text-blue-600" />;
    if (fileType?.includes('sheet') || fileType?.includes('excel') || fileType?.includes('csv')) return <FileSpreadsheet className="h-8 w-8 text-green-600" />;
    if (fileType?.includes('image')) return <FileImage className="h-8 w-8 text-purple-500" />;
    if (fileType?.includes('zip') || fileType?.includes('rar')) return <FileArchive className="h-8 w-8 text-orange-500" />;
    if (fileType?.includes('powerpoint') || fileType?.includes('presentation')) return <FileText className="h-8 w-8 text-orange-600" />;
    return <File className="h-8 w-8 text-gray-500" />;
  };

  const getFileTypeLabel = (fileType: string) => {
    if (fileType?.includes('pdf')) return 'PDF';
    if (fileType?.includes('word') || fileType?.includes('document')) return 'DOC';
    if (fileType?.includes('sheet') || fileType?.includes('excel')) return 'XLS';
    if (fileType?.includes('csv')) return 'CSV';
    if (fileType?.includes('image')) return 'IMG';
    if (fileType?.includes('zip')) return 'ZIP';
    if (fileType?.includes('powerpoint') || fileType?.includes('presentation')) return 'PPT';
    return 'FILE';
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-96">
          <div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-600 border-t-transparent" />
        </div>
      </DashboardLayout>
    );
  }

  const counts = {
    all: reports.length,
    draft: reports.filter(r => r.status === 'draft').length,
    submitted: reports.filter(r => r.status === 'submitted').length,
    reviewed: reports.filter(r => r.status === 'reviewed').length,
    changes: reports.filter(r => r.status === 'changes_requested').length,
  };

  return (
    <DashboardLayout>
      <div className="mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {/* Toast Messages */}
        {success && (
          <div className="fixed top-6 right-6 z-50 bg-white border border-emerald-200 shadow-lg rounded-xl px-5 py-3 text-sm font-medium text-emerald-800 flex items-center gap-2 animate-in">
            <CheckCircle className="h-4 w-4 text-emerald-500" />{success}
          </div>
        )}
        {error && (
          <div className="fixed top-6 right-6 z-50 bg-white border border-red-200 shadow-lg rounded-xl px-5 py-3 text-sm font-medium text-red-800 flex items-center gap-2 animate-in">
            <AlertCircle className="h-4 w-4 text-red-500" />{error}
          </div>
        )}

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-gray-900">Reports</h1>
            <p className="text-sm text-gray-500 mt-1">{counts.all} report{counts.all !== 1 ? 's' : ''} total</p>
          </div>
          {canCreate('reports') && (
            <button onClick={() => { closeModal(); setShowModal(true); }}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white text-sm font-semibold rounded-xl shadow-sm hover:bg-indigo-700 transition-colors">
              <Plus className="h-4 w-4" /> Create Report
            </button>
          )}
        </div>

        {/* Status Pipeline */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {statusOptions.map(s => {
            const count = counts[s.value as keyof typeof counts] || 0;
            const isActive = statusFilter === s.value;
            return (
              <button key={s.value} onClick={() => setStatusFilter(isActive ? 'all' : s.value)}
                className={`relative p-4 rounded-xl border-2 text-left transition-all duration-200 ${
                  isActive ? `${s.color} ring-2 ring-indigo-400 scale-[1.02]` : 'bg-white border-gray-100 hover:border-gray-200'
                }`}>
                <p className="text-2xl font-bold text-gray-900">{count}</p>
                <p className="text-xs font-medium text-gray-500 mt-0.5">{s.label}</p>
                {isActive && <CheckCircle className="absolute top-3 right-3 h-4 w-4 text-indigo-500" />}
              </button>
            );
          })}
        </div>

        {/* Search & Filters */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input type="text" placeholder="Search reports by title or content..." 
                className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
            </div>
            <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)} 
              className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500">
              <option value="all">All Types</option>
              <option value="monthly">Monthly</option>
              <option value="quarterly">Quarterly</option>
              <option value="annual">Annual</option>
            </select>
          </div>
        </div>

        {/* Reports List */}
        <div className="space-y-4">
          {reports.map(report => (
            <div key={report._id} className="bg-white rounded-2xl border border-gray-200 p-5 hover:shadow-md transition-all group">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  {/* Title + Status Badges */}
                  <div className="flex items-center gap-2 flex-wrap mb-1.5">
                    <h3 className="font-semibold text-gray-900">{report.title}</h3>
                    <span className={`px-2 py-0.5 text-xs font-medium rounded-full border ${statusOptions.find(s => s.value === report.status)?.color || ''}`}>
                      {report.status.replace('_', ' ')}
                    </span>
                    <span className="px-2 py-0.5 text-xs font-medium rounded-full bg-gray-100 text-gray-600 capitalize">{report.type}</span>
                  </div>

                  {/* Meta Info */}
                  <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                    <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />{report.month} {report.year}</span>
                    <span className="flex items-center gap-1"><User className="h-3 w-3" />{report.submittedBy?.name || 'Unknown'}</span>
                    {report.department && <span className="px-1.5 py-0.5 bg-gray-100 rounded-md">{report.department}</span>}
                    {report.attachments?.length > 0 && (
                      <span className="flex items-center gap-1"><Paperclip className="h-3 w-3" />{report.attachments.length} file{report.attachments.length > 1 ? 's' : ''}</span>
                    )}
                  </div>

                  {/* Summary */}
                  {report.summary && (
                    <p className="text-sm text-gray-600 mb-3 line-clamp-2">{report.summary}</p>
                  )}

                  {/* Attachments - Clickable to Download */}
                  {report.attachments?.length > 0 && (
                    <div className="mb-3">
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Attachments</p>
                        {report.attachments.length > 1 && (
                          <button onClick={() => handleDownloadAllAttachments(report)}
                            className="text-xs text-indigo-600 hover:text-indigo-800 font-medium">
                            Download all
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {report.attachments.map(att => (
                          <button
                            key={att._id}
                            onClick={() => handleDownloadAttachment(att)}
                            className="flex items-center gap-3 p-3 bg-gray-50 hover:bg-indigo-50 border border-gray-200 hover:border-indigo-200 rounded-xl transition-all group/att text-left"
                          >
                            {getFileIcon(att.fileType)}
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900 truncate group-hover/att:text-indigo-700 transition-colors">
                                {att.originalName}
                              </p>
                              <p className="text-xs text-gray-500">
                                {getFileTypeLabel(att.fileType)} • {formatSize(att.fileSize)}
                              </p>
                            </div>
                            <Download className="h-4 w-4 text-gray-400 group-hover/att:text-indigo-600 opacity-0 group-hover/att:opacity-100 transition-all shrink-0" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Review Info */}
                  {report.review && (
                    <div className="p-3 bg-gray-50 rounded-xl">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-semibold text-gray-700">Review by {report.review.reviewedBy?.name}:</span>
                        <span className={`text-xs font-medium px-1.5 py-0.5 rounded-full ${
                          report.review.decision === 'approved' ? 'bg-emerald-100 text-emerald-700' :
                          report.review.decision === 'changes_requested' ? 'bg-amber-100 text-amber-700' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {report.review.decision.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">{report.review.comment}</p>
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                  {report.status === 'draft' && (
                    <button onClick={() => handleSubmitForReview(report._id)} 
                      className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors" title="Submit for Review">
                      <Send className="h-4 w-4" />
                    </button>
                  )}
                  {report.status === 'submitted' && isAdmin && (
                    <button onClick={() => { setReviewingReport(report); setShowReviewModal(true); }} 
                      className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors" title="Review">
                      <Eye className="h-4 w-4" />
                    </button>
                  )}
                  {canEdit('reports') && (
                    <button onClick={() => openEditModal(report)} 
                      className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors" title="Edit">
                      <Edit className="h-4 w-4" />
                    </button>
                  )}
                  <button onClick={() => handleExport(report)} 
                    className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors" title="Export as JSON">
                    <Download className="h-4 w-4" />
                  </button>
                  {canDelete('reports') && (
                    <button onClick={() => handleDelete(report._id)} 
                      className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Delete">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {reports.length === 0 && (
          <div className="text-center py-20 bg-white rounded-2xl border border-gray-200">
            <div className="inline-flex items-center justify-center h-16 w-16 rounded-2xl bg-gray-100 mb-5">
              <FileBarChart className="h-8 w-8 text-gray-300" />
            </div>
            <h3 className="text-base font-semibold text-gray-900 mb-1">No reports found</h3>
            <p className="text-sm text-gray-500 max-w-sm mx-auto">
              {searchTerm ? 'Try adjusting your search or filters.' : 'Create your first report to get started.'}
            </p>
            {canCreate('reports') && (
              <button onClick={() => { closeModal(); setShowModal(true); }}
                className="mt-5 inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white text-sm font-semibold rounded-xl shadow-sm hover:bg-indigo-700 transition-colors">
                <Plus className="h-4 w-4" /> Create Report
              </button>
            )}
          </div>
        )}

        {/* Create/Edit Modal */}
        {showModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={closeModal} />
              <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border border-gray-100">
                <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 rounded-t-2xl flex items-center justify-between z-10">
                  <h2 className="text-lg font-bold text-gray-900">{editingReport ? 'Edit' : 'Create'} Report</h2>
                  <button onClick={closeModal} className="p-2 hover:bg-gray-100 rounded-xl transition-colors text-gray-400 hover:text-gray-600">
                    <X className="h-5 w-5" />
                  </button>
                </div>
                <div className="p-6 space-y-4">
                  {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm font-medium">{error}</div>}
                  
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Title <span className="text-red-500">*</span></label>
                    <input type="text" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                      value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="e.g., Monthly Performance Report" />
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5">Type <span className="text-red-500">*</span></label>
                      <select className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        value={formData.type} onChange={e => setFormData({...formData, type: e.target.value})}>
                        <option value="monthly">Monthly</option>
                        <option value="quarterly">Quarterly</option>
                        <option value="annual">Annual</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5">Month <span className="text-red-500">*</span></label>
                      <select className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        value={formData.month} onChange={e => setFormData({...formData, month: e.target.value})}>
                        <option value="">Select</option>
                        {months.map(m => <option key={m} value={m}>{m}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5">Year <span className="text-red-500">*</span></label>
                      <input type="number" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        value={formData.year} onChange={e => setFormData({...formData, year: e.target.value})} />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Attachments</label>
                    <div className="border-2 border-dashed border-gray-300 rounded-xl p-5 text-center hover:border-indigo-400 transition-colors">
                      <input type="file" ref={fileInputRef} multiple
                        className="w-full text-sm text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-700 file:cursor-pointer file:transition-colors"
                        onChange={e => setSelectedFiles(Array.from(e.target.files || []))}
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.jpg,.jpeg,.png,.gif,.zip" />
                    </div>
                    <p className="text-xs text-gray-500 mt-1.5">Max 50MB per file. Supports PDF, DOCX, XLSX, images, and more.</p>
                    {selectedFiles.length > 0 && (
                      <div className="mt-2 space-y-1">
                        {selectedFiles.map((f, i) => <p key={i} className="text-sm text-gray-600 font-medium">{f.name} ({(f.size / 1048576).toFixed(1)} MB)</p>)}
                      </div>
                    )}
                    {editingReport && editingReport.attachments?.length > 0 && (
                      <div className="mt-3 space-y-1">
                        <p className="text-xs font-medium text-gray-500">Current attachments:</p>
                        {editingReport.attachments.map(a => (
                          <div key={a._id} className="flex items-center justify-between text-sm py-1.5 px-2 bg-gray-50 rounded-lg">
                            <span className="text-gray-600 truncate">{a.originalName}</span>
                            <button onClick={() => {
                              setRemoveAttachmentIds([...removeAttachmentIds, a._id]);
                              setEditingReport({...editingReport, attachments: editingReport.attachments.filter(x => x._id !== a._id)});
                            }} className="text-red-500 hover:text-red-700 text-xs font-medium ml-2 shrink-0">Remove</button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Summary</label>
                    <textarea className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none" rows={2}
                      value={formData.summary} onChange={e => setFormData({...formData, summary: e.target.value})} placeholder="Brief overview..." />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5">Achievements</label>
                      <textarea className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none" rows={3}
                        value={formData.achievements} onChange={e => setFormData({...formData, achievements: e.target.value})} placeholder="What went well..." />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5">Challenges</label>
                      <textarea className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none" rows={3}
                        value={formData.challenges} onChange={e => setFormData({...formData, challenges: e.target.value})} placeholder="Obstacles faced..." />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Goals for Next Period</label>
                    <textarea className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none" rows={2}
                      value={formData.goals} onChange={e => setFormData({...formData, goals: e.target.value})} placeholder="Upcoming objectives..." />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Detailed Content <span className="text-red-500">*</span></label>
                    <textarea className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none min-h-[200px]"
                      value={formData.content} onChange={e => setFormData({...formData, content: e.target.value})} placeholder="Full detailed report..." />
                  </div>
                </div>
                <div className="sticky bottom-0 bg-white border-t border-gray-100 px-6 py-4 rounded-b-2xl flex items-center justify-end gap-3">
                  <button onClick={closeModal} className="px-5 py-2.5 text-sm font-semibold text-gray-700 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">Cancel</button>
                  <button onClick={handleSubmit} disabled={submitting}
                    className="px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm flex items-center gap-2">
                    {submitting ? (
                      <><div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" /> Saving...</>
                    ) : editingReport ? 'Update Report' : 'Save as Draft'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Review Modal */}
        {showReviewModal && reviewingReport && (
          <div className="fixed inset-0 z-50 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setShowReviewModal(false)} />
              <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg border border-gray-100">
                <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 rounded-t-2xl flex items-center justify-between">
                  <h2 className="text-lg font-bold text-gray-900">Review Report</h2>
                  <button onClick={() => setShowReviewModal(false)} className="p-2 hover:bg-gray-100 rounded-xl transition-colors text-gray-400 hover:text-gray-600">
                    <X className="h-5 w-5" />
                  </button>
                </div>
                <div className="p-6 space-y-4">
                  <div className="p-4 bg-gray-50 rounded-xl">
                    <h3 className="font-semibold text-gray-900">{reviewingReport.title}</h3>
                    <p className="text-sm text-gray-600 mt-1">{reviewingReport.summary || 'No summary provided'}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Decision</label>
                    <div className="flex gap-3">
                      {[
                        { v: 'approved', l: 'Approve', icon: CheckCircle, color: 'text-emerald-500', bg: 'bg-emerald-50' },
                        { v: 'changes_requested', l: 'Request Changes', icon: AlertCircle, color: 'text-amber-500', bg: 'bg-amber-50' },
                        { v: 'rejected', l: 'Reject', icon: XCircle, color: 'text-red-500', bg: 'bg-red-50' },
                      ].map(d => (
                        <button key={d.v} onClick={() => setReviewForm({ ...reviewForm, decision: d.v })}
                          className={`flex-1 p-3 rounded-xl border-2 text-center font-medium text-sm transition-all ${
                            reviewForm.decision === d.v ? `${d.bg} border-indigo-400 ${d.color}` : 'border-gray-200 text-gray-500 hover:border-gray-300'
                          }`}>
                          <d.icon className={`h-5 w-5 mx-auto mb-1 ${reviewForm.decision === d.v ? d.color : 'text-gray-300'}`} />
                          {d.l}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Comment</label>
                    <textarea className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none" rows={4}
                      value={reviewForm.comment} onChange={e => setReviewForm({ ...reviewForm, comment: e.target.value })}
                      placeholder="Provide feedback or comments..." />
                  </div>
                </div>
                <div className="sticky bottom-0 bg-white border-t border-gray-100 px-6 py-4 rounded-b-2xl flex items-center justify-end gap-3">
                  <button onClick={() => setShowReviewModal(false)}
                    className="px-5 py-2.5 text-sm font-semibold text-gray-700 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">Cancel</button>
                  <button onClick={handleReview} disabled={submitting}
                    className="px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm">
                    {submitting ? 'Submitting...' : 'Submit Review'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}