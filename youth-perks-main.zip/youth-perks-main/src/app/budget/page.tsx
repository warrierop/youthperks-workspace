'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { ProtectedPage } from '@/components/auth/ProtectedPage';
import { useAuth } from '@/hooks/useAuth';
import {
  Plus, Search, DollarSign, TrendingUp, TrendingDown, 
  FileText, Edit, Trash2, X, Wallet, ArrowUpRight,
  ArrowDownRight, Calendar, Filter, Receipt, PiggyBank
} from 'lucide-react';

interface Expense {
  _id: string;
  amount: number;
  description: string;
  category: string;
  date: string;
  createdBy?: { _id: string; name: string };
}

interface BudgetDocument {
  _id: string;
  title: string;
  content: string;
  createdBy: { _id: string; name: string; email: string };
  createdAt: string;
}

interface Budget {
  _id: string;
  name: string;
  description: string;
  allocatedAmount: number;
  spentAmount: number;
  remainingAmount: number;
  usagePercentage: number;
  department?: string;
  project?: string;
  category?: string;
  status: 'active' | 'completed' | 'paused';
  documents: BudgetDocument[];
  expenses: Expense[];
  startDate: string;
  endDate: string;
  createdAt: string;
}

const statusColors: Record<string, string> = {
  active: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  completed: 'bg-blue-50 text-blue-700 border-blue-200',
  paused: 'bg-amber-50 text-amber-700 border-amber-200',
};

export default function BudgetPage() {
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showModal, setShowModal] = useState(false);
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null);
  const [expenseBudget, setExpenseBudget] = useState<Budget | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    name: '', description: '', allocatedAmount: '',
    department: '', project: '', startDate: '', endDate: '',
    status: 'active', category: 'general',
  });

  const [expenseForm, setExpenseForm] = useState({
    amount: '', description: '', category: 'other',
    date: new Date().toISOString().split('T')[0],
  });

  const { canCreate, canEdit, canDelete } = useAuth();
  const router = useRouter();
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

  useEffect(() => { fetchBudgets(); }, []);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' };
  };

  const fetchBudgets = async () => {
    try {
      const res = await fetch(`${API_URL}/api/budget`, { headers: getAuthHeaders() });
      if (res.ok) setBudgets(await res.json());
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const handleSubmit = async () => {
    if (!formData.name || !formData.allocatedAmount || !formData.startDate || !formData.endDate) {
      setError('Please fill in all required fields'); return;
    }
    setSubmitting(true); setError('');
    try {
      const url = editingBudget ? `${API_URL}/api/budget/${editingBudget._id}` : `${API_URL}/api/budget`;
      const method = editingBudget ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method, headers: getAuthHeaders(),
        body: JSON.stringify({ ...formData, allocatedAmount: parseFloat(formData.allocatedAmount) }),
      });
      if (res.ok) {
        const data = await res.json();
        setBudgets(editingBudget ? budgets.map(b => b._id === data._id ? data : b) : [data, ...budgets]);
        closeModal();
        setSuccess(editingBudget ? 'Budget updated!' : 'Budget created!');
        setTimeout(() => setSuccess(''), 3000);
      } else {
        const d = await res.json();
        setError(d.message || 'Failed');
      }
    } catch { setError('Failed to save'); }
    finally { setSubmitting(false); }
  };

  const handleAddExpense = async () => {
    if (!expenseBudget || !expenseForm.amount) return;
    setSubmitting(true);
    try {
      const res = await fetch(`${API_URL}/api/budget/${expenseBudget._id}/expenses`, {
        method: 'POST', headers: getAuthHeaders(),
        body: JSON.stringify({ ...expenseForm, amount: parseFloat(expenseForm.amount) }),
      });
      if (res.ok) {
        const updated = await res.json();
        setBudgets(budgets.map(b => b._id === updated._id ? updated : b));
        setShowExpenseModal(false);
        setExpenseForm({ amount: '', description: '', category: 'other', date: new Date().toISOString().split('T')[0] });
        setSuccess('Expense recorded!');
        setTimeout(() => setSuccess(''), 3000);
      }
    } catch { setError('Failed to add expense'); }
    finally { setSubmitting(false); }
  };

  const handleDeleteExpense = async (budgetId: string, expenseId: string) => {
    try {
      const res = await fetch(`${API_URL}/api/budget/${budgetId}/expenses/${expenseId}`, {
        method: 'DELETE', headers: getAuthHeaders(),
      });
      if (res.ok) {
        const updated = await res.json();
        setBudgets(budgets.map(b => b._id === updated._id ? updated : b));
      }
    } catch { /* skip */ }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this budget?')) return;
    try {
      await fetch(`${API_URL}/api/budget/${id}`, { method: 'DELETE', headers: getAuthHeaders() });
      setBudgets(budgets.filter(b => b._id !== id));
      setSuccess('Budget deleted!');
      setTimeout(() => setSuccess(''), 3000);
    } catch { setError('Failed'); }
  };

  const openEditModal = (budget: Budget) => {
    setEditingBudget(budget);
    setFormData({
      name: budget.name, description: budget.description || '',
      allocatedAmount: budget.allocatedAmount.toString(),
      department: budget.department || '', project: budget.project || '',
      startDate: new Date(budget.startDate).toISOString().split('T')[0],
      endDate: new Date(budget.endDate).toISOString().split('T')[0],
      status: budget.status, category: budget.category || 'general',
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false); setEditingBudget(null); setError('');
    setFormData({ name: '', description: '', allocatedAmount: '', department: '', project: '', startDate: '', endDate: '', status: 'active', category: 'general' });
  };

  const formatCurrency = (val: number) => `$${val.toLocaleString()}`;
  const totalAllocated = budgets.reduce((s, b) => s + b.allocatedAmount, 0);
  const totalSpent = budgets.reduce((s, b) => s + b.spentAmount, 0);
  const totalRemaining = totalAllocated - totalSpent;

  const filteredBudgets = budgets.filter(b => {
    const ms = b.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.department?.toLowerCase().includes(searchTerm.toLowerCase());
    return ms && (statusFilter === 'all' || b.status === statusFilter);
  });

  if (loading) {
    return (
      <ProtectedPage page="budget">
        <DashboardLayout>
          <div className="flex justify-center items-center h-96">
            <div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-600 border-t-transparent" />
          </div>
        </DashboardLayout>
      </ProtectedPage>
    );
  }

  return (
    <ProtectedPage page="budget">
      <DashboardLayout>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
          {/* Toast */}
          {success && (
            <div className="fixed top-6 right-6 z-50 bg-white border border-emerald-200 shadow-lg rounded-xl px-5 py-3 text-sm font-medium text-emerald-800 flex items-center gap-2">
              <div className="h-5 w-5 rounded-full bg-emerald-100 flex items-center justify-center">✓</div>
              {success}
            </div>
          )}

          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-gray-900">Budget Management</h1>
              <p className="text-sm text-gray-500 mt-1">
                {budgets.length} budget{budgets.length !== 1 ? 's' : ''} • {formatCurrency(totalAllocated)} allocated
              </p>
            </div>
            {canCreate('budget') && (
              <button onClick={() => setShowModal(true)}
                className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white text-sm font-semibold rounded-xl shadow-sm hover:bg-indigo-700 transition-colors">
                <Plus className="h-4 w-4" /> Create Budget
              </button>
            )}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { label: 'Total Allocated', value: formatCurrency(totalAllocated), icon: Wallet, color: 'bg-blue-500', sub: `${budgets.length} budgets` },
              { label: 'Total Spent', value: formatCurrency(totalSpent), icon: TrendingDown, color: 'bg-emerald-500', sub: `${totalAllocated > 0 ? Math.round((totalSpent / totalAllocated) * 100) : 0}% used` },
              { label: 'Remaining', value: formatCurrency(totalRemaining), icon: PiggyBank, color: totalRemaining >= 0 ? 'bg-amber-500' : 'bg-red-500', sub: totalRemaining >= 0 ? 'Available' : 'Over budget!' },
            ].map(s => (
              <div key={s.label} className="bg-white rounded-2xl border border-gray-200 p-5 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4">
                  <div className={`h-11 w-11 ${s.color} rounded-xl flex items-center justify-center`}>
                    <s.icon className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xl font-bold text-gray-900">{s.value}</p>
                    <p className="text-xs text-gray-500">{s.label}</p>
                    <p className="text-[10px] text-gray-400 mt-0.5">{s.sub}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Filters */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input type="text" placeholder="Search budgets..." className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
              </div>
              <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
                className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium text-gray-700">
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="completed">Completed</option>
                <option value="paused">Paused</option>
              </select>
            </div>
          </div>

          {/* Budget Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredBudgets.map(budget => {
              const usagePercent = Math.min(budget.usagePercentage || 0, 100);
              const isOverBudget = budget.remainingAmount < 0;
              return (
                <div key={budget._id} className="bg-white rounded-2xl border border-gray-200 p-5 hover:shadow-md transition-all group">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-900 truncate">{budget.name}</h3>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {budget.department || budget.project || budget.category || 'General'}
                      </p>
                    </div>
                    <span className={`px-2.5 py-1 text-xs font-semibold rounded-full border ${statusColors[budget.status]}`}>
                      {budget.status}
                    </span>
                  </div>

                  {/* Amounts */}
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div className="text-center p-2 bg-gray-50 rounded-xl">
                      <p className="text-xs text-gray-500">Allocated</p>
                      <p className="text-sm font-bold text-gray-900">{formatCurrency(budget.allocatedAmount)}</p>
                    </div>
                    <div className="text-center p-2 bg-gray-50 rounded-xl">
                      <p className="text-xs text-gray-500">Spent</p>
                      <p className="text-sm font-bold text-gray-900">{formatCurrency(budget.spentAmount)}</p>
                    </div>
                    <div className={`text-center p-2 rounded-xl ${isOverBudget ? 'bg-red-50' : 'bg-gray-50'}`}>
                      <p className="text-xs text-gray-500">Remaining</p>
                      <p className={`text-sm font-bold ${isOverBudget ? 'text-red-600' : 'text-gray-900'}`}>
                        {formatCurrency(budget.remainingAmount)}
                      </p>
                    </div>
                  </div>

                  {/* Usage Bar */}
                  <div className="mb-4">
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-gray-500">Usage</span>
                      <span className={`font-semibold ${usagePercent >= 90 ? 'text-red-600' : usagePercent >= 75 ? 'text-amber-600' : 'text-emerald-600'}`}>
                        {usagePercent}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2.5 overflow-hidden">
                      <div className={`h-full rounded-full transition-all duration-500 ${usagePercent >= 90 ? 'bg-red-500' : usagePercent >= 75 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                        style={{ width: `${usagePercent}%` }} />
                    </div>
                  </div>

                  {/* Recent Expenses */}
                  {budget.expenses?.length > 0 && (
                    <div className="mb-4">
                      <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Recent Expenses</p>
                      <div className="space-y-1.5">
                        {budget.expenses.slice(-3).reverse().map(exp => (
                          <div key={exp._id} className="flex items-center justify-between text-sm">
                            <span className="text-gray-600 truncate flex-1">{exp.description || 'Expense'}</span>
                            <span className="font-medium text-gray-900 ml-2">-{formatCurrency(exp.amount)}</span>
                            <button onClick={(e) => { e.stopPropagation(); handleDeleteExpense(budget._id, exp._id); }}
                              className="ml-2 p-0.5 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                    <button onClick={(e) => { e.stopPropagation(); setExpenseBudget(budget); setShowExpenseModal(true); }}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100 transition-colors">
                      <Plus className="h-3.5 w-3.5" /> Add Expense
                    </button>
                    <div className="flex gap-1">
                      <button onClick={() => router.push(`/budget/${budget._id}`)}
                        className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                        <FileText className="h-4 w-4" />
                      </button>
                      {canEdit('budget') && (
                        <button onClick={(e) => { e.stopPropagation(); openEditModal(budget); }}
                          className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                          <Edit className="h-4 w-4" />
                        </button>
                      )}
                      {canDelete('budget') && (
                        <button onClick={(e) => { e.stopPropagation(); handleDelete(budget._id); }}
                          className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredBudgets.length === 0 && (
            <div className="text-center py-20 bg-white rounded-2xl border border-gray-200">
              <div className="h-16 w-16 rounded-2xl bg-gray-100 flex items-center justify-center mx-auto mb-4">
                <DollarSign className="h-8 w-8 text-gray-300" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">No budgets found</h3>
              <p className="text-sm text-gray-500 mt-1">Create your first budget to get started.</p>
            </div>
          )}

          {/* Create/Edit Modal */}
          {showModal && (
            <div className="fixed inset-0 z-50 overflow-y-auto">
              <div className="flex min-h-full items-center justify-center p-4">
                <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={closeModal} />
                <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg border border-gray-100">
                  <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 rounded-t-2xl flex items-center justify-between z-10">
                    <h2 className="text-lg font-bold text-gray-900">{editingBudget ? 'Edit' : 'Create'} Budget</h2>
                    <button onClick={closeModal} className="p-2 hover:bg-gray-100 rounded-xl"><X className="h-5 w-5 text-gray-400" /></button>
                  </div>
                  <div className="p-6 space-y-4">
                    {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm">{error}</div>}
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5">Budget Name <span className="text-red-500">*</span></label>
                      <input type="text" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5">Description</label>
                      <textarea className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50 resize-none" rows={2} value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Amount <span className="text-red-500">*</span></label><input type="number" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.allocatedAmount} onChange={e => setFormData({...formData, allocatedAmount: e.target.value})} /></div>
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Category</label><select className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}><option value="general">General</option><option value="marketing">Marketing</option><option value="operations">Operations</option><option value="technology">Technology</option><option value="hr">HR</option><option value="sales">Sales</option></select></div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Start Date <span className="text-red-500">*</span></label><input type="date" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.startDate} onChange={e => setFormData({...formData, startDate: e.target.value})} /></div>
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">End Date <span className="text-red-500">*</span></label><input type="date" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.endDate} onChange={e => setFormData({...formData, endDate: e.target.value})} /></div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Department</label><input type="text" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.department} onChange={e => setFormData({...formData, department: e.target.value})} /></div>
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Status</label><select className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={formData.status} onChange={e => setFormData({...formData, status: e.target.value})}><option value="active">Active</option><option value="completed">Completed</option><option value="paused">Paused</option></select></div>
                    </div>
                  </div>
                  <div className="sticky bottom-0 bg-white border-t border-gray-100 px-6 py-4 rounded-b-2xl flex justify-end gap-3">
                    <button onClick={closeModal} className="px-5 py-2.5 text-sm font-semibold text-gray-700 border border-gray-200 rounded-xl">Cancel</button>
                    <button onClick={handleSubmit} disabled={submitting} className="px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 disabled:opacity-50">{submitting ? 'Saving...' : editingBudget ? 'Update' : 'Create Budget'}</button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Expense Modal */}
          {showExpenseModal && expenseBudget && (
            <div className="fixed inset-0 z-50 overflow-y-auto">
              <div className="flex min-h-full items-center justify-center p-4">
                <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setShowExpenseModal(false)} />
                <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md border border-gray-100">
                  <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 rounded-t-2xl flex items-center justify-between">
                    <div>
                      <h2 className="text-lg font-bold text-gray-900">Add Expense</h2>
                      <p className="text-sm text-gray-500">{expenseBudget.name}</p>
                    </div>
                    <button onClick={() => setShowExpenseModal(false)} className="p-2 hover:bg-gray-100 rounded-xl"><X className="h-5 w-5 text-gray-400" /></button>
                  </div>
                  <div className="p-6 space-y-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5">Amount ($) <span className="text-red-500">*</span></label>
                      <input type="number" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50" value={expenseForm.amount} onChange={e => setExpenseForm({...expenseForm, amount: e.target.value})} />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5">Description</label>
                      <input type="text" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm bg-gray-50" value={expenseForm.description} onChange={e => setExpenseForm({...expenseForm, description: e.target.value})} placeholder="What was this for?" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Category</label><select className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={expenseForm.category} onChange={e => setExpenseForm({...expenseForm, category: e.target.value})}><option value="other">Other</option><option value="marketing">Marketing</option><option value="operations">Operations</option><option value="travel">Travel</option><option value="software">Software</option><option value="events">Events</option></select></div>
                      <div><label className="block text-sm font-semibold text-gray-700 mb-1.5">Date</label><input type="date" className="w-full border rounded-xl px-4 py-3 text-sm bg-gray-50" value={expenseForm.date} onChange={e => setExpenseForm({...expenseForm, date: e.target.value})} /></div>
                    </div>
                  </div>
                  <div className="sticky bottom-0 bg-white border-t border-gray-100 px-6 py-4 rounded-b-2xl flex justify-end gap-3">
                    <button onClick={() => setShowExpenseModal(false)} className="px-5 py-2.5 text-sm font-semibold text-gray-700 border rounded-xl">Cancel</button>
                    <button onClick={handleAddExpense} disabled={submitting} className="px-5 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700">{submitting ? 'Adding...' : 'Add Expense'}</button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedPage>
  );
}