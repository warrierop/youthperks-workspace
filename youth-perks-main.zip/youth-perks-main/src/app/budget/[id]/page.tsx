'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Plus, FileText, Edit, Trash2, Save, X, Download, Share2 } from 'lucide-react';

interface BudgetDocument {
    _id: string;
    title: string;
    content: string;
    createdBy: { _id: string; name: string; email: string };
    lastEditedBy?: { _id: string; name: string; email: string };
    lastEditedAt?: string;
    createdAt: string;
}

interface Budget {
    _id: string;
    name: string;
    description: string;
    allocatedAmount: number;
    spentAmount: number;
    remainingAmount: number;
    usagePercentage: number;
    documents: BudgetDocument[];
    status: string;
    startDate: string;
    endDate: string;
}

export default function BudgetDetailPage() {
    const { id } = useParams();
    const router = useRouter();
    const [budget, setBudget] = useState<Budget | null>(null);
    const [loading, setLoading] = useState(true);
    const [activeDoc, setActiveDoc] = useState<BudgetDocument | null>(null);
    const [editingDoc, setEditingDoc] = useState(false);
    const [docTitle, setDocTitle] = useState('');
    const [docContent, setDocContent] = useState('');
    const [showNewDoc, setShowNewDoc] = useState(false);
    const [success, setSuccess] = useState('');

    const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

    useEffect(() => {
        fetchBudget();
    }, [id]);

    const getAuthHeaders = () => {
        const token = localStorage.getItem('token');
        return {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
        };
    };

    const fetchBudget = async () => {
        try {
            const response = await fetch(`${API_URL}/api/budget/${id}`, {
                headers: getAuthHeaders(),
            });
            if (response.ok) {
                const data = await response.json();
                setBudget(data);
                if (data.documents?.length > 0) {
                    setActiveDoc(data.documents[0]);
                }
            }
        } catch (error) {
            console.error('Failed to fetch budget:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleSaveDocument = async () => {
        if (!docTitle) return;

        try {
            if (activeDoc && editingDoc) {
                const response = await fetch(`${API_URL}/api/budget/${id}/documents/${activeDoc._id}`, {
                    method: 'PUT',
                    headers: getAuthHeaders(),
                    body: JSON.stringify({ title: docTitle, content: docContent }),
                });
                if (response.ok) {
                    const data = await response.json();
                    setBudget(data);
                    setActiveDoc(data.documents.find((d: BudgetDocument) => d._id === activeDoc._id));
                    setEditingDoc(false);
                    setSuccess('Document saved!');
                    setTimeout(() => setSuccess(''), 2000);
                }
            } else {
                const response = await fetch(`${API_URL}/api/budget/${id}/documents`, {
                    method: 'POST',
                    headers: getAuthHeaders(),
                    body: JSON.stringify({ title: docTitle, content: docContent }),
                });
                if (response.ok) {
                    const data = await response.json();
                    setBudget(data);
                    setActiveDoc(data.documents[data.documents.length - 1]);
                    setShowNewDoc(false);
                    setSuccess('Document created!');
                    setTimeout(() => setSuccess(''), 2000);
                }
            }
        } catch (error) {
            console.error('Failed to save document:', error);
        }
    };

    const handleDeleteDocument = async (docId: string) => {
        if (!confirm('Delete this document?')) return;
        try {
            const response = await fetch(`${API_URL}/api/budget/${id}/documents/${docId}`, {
                method: 'DELETE',
                headers: getAuthHeaders(),
            });
            if (response.ok) {
                setBudget((prev) => prev ? {
                    ...prev,
                    documents: prev.documents.filter(d => d._id !== docId),
                } : null);
                setActiveDoc(null);
            }
        } catch (error) {
            console.error('Failed to delete document:', error);
        }
    };

    const handleDownload = () => {
        if (!activeDoc) return;
        const blob = new Blob([activeDoc.content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${activeDoc.title}.txt`;
        a.click();
        URL.revokeObjectURL(url);
    };

    const handleShare = () => {
        if (!activeDoc) return;
        navigator.clipboard.writeText(window.location.href);
        setSuccess('Link copied to clipboard!');
        setTimeout(() => setSuccess(''), 2000);
    };

    const openDoc = (doc: BudgetDocument) => {
        setActiveDoc(doc);
        setDocTitle(doc.title);
        setDocContent(doc.content);
        setEditingDoc(false);
    };

    if (loading) {
        return (
            <DashboardLayout>
                <div className="flex items-center justify-center h-64">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
                </div>
            </DashboardLayout>
        );
    }

    if (!budget) {
        return (
            <DashboardLayout>
                <div className="text-center py-16">Budget not found</div>
            </DashboardLayout>
        );
    }

    return (
        <DashboardLayout>
            <div className="p-6 space-y-6">
                {success && (
                    <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">
                        {success}
                    </div>
                )}

                {/* Header */}
                <div className="flex items-center gap-4">
                    <Button variant="ghost" size="sm" onClick={() => router.push('/budget')}>
                        <ArrowLeft className="h-4 w-4 mr-2" />
                        Back
                    </Button>
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900">{budget.name}</h1>
                        <p className="text-gray-500">Budget Details & Documents</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                    {/* Document List Sidebar */}
                    <div className="lg:col-span-1">
                        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="font-semibold text-gray-900">Documents</h2>
                                <Button size="sm" onClick={() => { setShowNewDoc(true); setDocTitle(''); setDocContent(''); setEditingDoc(false); }}>
                                    <Plus className="h-4 w-4" />
                                </Button>
                            </div>
                            <div className="space-y-1">
                                {budget.documents?.map((doc) => (
                                    <button
                                        key={doc._id}
                                        onClick={() => openDoc(doc)}
                                        className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${activeDoc?._id === doc._id
                                            ? 'bg-indigo-50 text-indigo-700 font-medium'
                                            : 'hover:bg-gray-50 text-gray-700'
                                            }`}
                                    >
                                        <FileText className="h-4 w-4 inline mr-2" />
                                        {doc.title}
                                    </button>
                                ))}
                                {(!budget.documents || budget.documents.length === 0) && !showNewDoc && (
                                    <p className="text-sm text-gray-400 text-center py-4">No documents yet</p>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Document Editor */}
                    <div className="lg:col-span-3">
                        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
                            {showNewDoc || activeDoc ? (
                                <div className="p-6">
                                    <div className="flex items-center justify-between mb-4">
                                        <input
                                            type="text"
                                            className="text-xl font-bold text-gray-900 border-0 border-b-2 border-transparent focus:border-indigo-500 focus:outline-none w-full"
                                            value={docTitle}
                                            onChange={(e) => setDocTitle(e.target.value)}
                                            placeholder="Document title..."
                                        />
                                        <div className="flex gap-2 ml-4">
                                            <Button size="sm" variant="ghost" onClick={handleDownload}>
                                                <Download className="h-4 w-4" />
                                            </Button>
                                            <Button size="sm" variant="ghost" onClick={handleShare}>
                                                <Share2 className="h-4 w-4" />
                                            </Button>
                                            {activeDoc && (
                                                <Button size="sm" variant="ghost" onClick={() => handleDeleteDocument(activeDoc._id)}>
                                                    <Trash2 className="h-4 w-4 text-red-500" />
                                                </Button>
                                            )}
                                        </div>
                                    </div>

                                    {editingDoc || showNewDoc ? (
                                        <div>
                                            <textarea
                                                className="w-full min-h-[400px] border border-gray-200 rounded-lg p-4 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
                                                value={docContent}
                                                onChange={(e) => setDocContent(e.target.value)}
                                                placeholder="Start writing your budget details here..."
                                            />
                                            <div className="flex justify-end gap-3 mt-4">
                                                <Button variant="outline" onClick={() => {
                                                    setEditingDoc(false);
                                                    setShowNewDoc(false);
                                                    if (activeDoc) {
                                                        setDocTitle(activeDoc.title);
                                                        setDocContent(activeDoc.content);
                                                    }
                                                }}>
                                                    Cancel
                                                </Button>
                                                <Button onClick={handleSaveDocument}>
                                                    <Save className="h-4 w-4 mr-2" />
                                                    Save
                                                </Button>
                                            </div>
                                        </div>
                                    ) : (
                                        <div>
                                            <div className="flex items-center justify-between mb-4 text-sm text-gray-500">
                                                <span>
                                                    Created by {activeDoc?.createdBy?.name} on {new Date(activeDoc?.createdAt || '').toLocaleDateString()}
                                                </span>
                                                <span>
                                                    Last edited: {activeDoc?.lastEditedAt ? new Date(activeDoc.lastEditedAt).toLocaleString() : 'N/A'}
                                                </span>
                                            </div>
                                            <div
                                                className="prose max-w-none min-h-[400px] border border-gray-100 rounded-lg p-4 bg-gray-50 whitespace-pre-wrap text-sm"
                                            >
                                                {activeDoc?.content || 'No content. Click edit to start writing.'}
                                            </div>
                                            <div className="flex justify-end mt-4">
                                                <Button onClick={() => {
                                                    setEditingDoc(true);
                                                    setDocTitle(activeDoc?.title || '');
                                                    setDocContent(activeDoc?.content || '');
                                                }}>
                                                    <Edit className="h-4 w-4 mr-2" />
                                                    Edit Document
                                                </Button>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            ) : (
                                <div className="text-center py-16 text-gray-400">
                                    <FileText className="mx-auto h-12 w-12 mb-4" />
                                    <p className="text-lg font-medium">No document selected</p>
                                    <p className="text-sm mt-1">Create a new document or select one from the sidebar</p>
                                    <Button className="mt-4" onClick={() => setShowNewDoc(true)}>
                                        <Plus className="h-4 w-4 mr-2" />
                                        New Document
                                    </Button>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </DashboardLayout>
    );
}