'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { useAuth } from '@/hooks/useAuth';
import { ProtectedPage } from '@/components/auth/ProtectedPage';
import {
  CheckSquare, FileText, Users, Handshake, DollarSign,
  TrendingUp, Clock, AlertCircle, Lightbulb, Megaphone, BarChart3, ArrowRight
} from 'lucide-react';

interface Activity {
  user: string;
  action: string;
  target: string;
  time: string;
  type: string;
}

interface PendingTask {
  _id: string;
  title: string;
  priority: string;
  dueDate?: string;
  status: string;
}

interface DashboardData {
  stats: {
    totalTasks: number;
    completedTasks: number;
    pendingTasks: number;
    totalDocuments: number;
    totalTeamMembers: number;
    totalBrands: number;
    activeBrands: number;
    totalReports: number;
    pendingReports: number;
    totalAllocated: number;
    totalSpent: number;
    totalPolls: number;
    activePolls: number;
    totalIdeas: number;
    totalAnnouncements: number;
  };
  activities: Activity[];
  pendingTasks: PendingTask[];
}

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const router = useRouter();
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3002';

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/login');
      return;
    }
    // console.log('User permissions:', user?.permissions);
    // console.log('Can view polls:', user?.permissions?.find(p => p.page === 'polls'));
    // console.log('Can view announcements:', user?.permissions?.find(p => p.page === 'announcements'));
    fetchDashboard();
  }, []);

const fetchDashboard = async () => {
  try {
    const token = localStorage.getItem('token');
    const res = await fetch(`${API_URL}/api/dashboard`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.ok) {
      const dashboardData = await res.json();
      console.log('📊 Dashboard API Response:', {
        totalAllocated: dashboardData.stats.totalAllocated,
        totalSpent: dashboardData.stats.totalSpent,
        totalBudget: dashboardData.stats.totalBudget,
      });
      setData(dashboardData);
    }
  } catch (err) {
    console.error('Failed to fetch dashboard:', err);
  } finally {
    setLoading(false);
  }
};

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-700 border-red-300';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      default: return 'bg-green-100 text-green-700 border-green-300';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckSquare className="h-4 w-4 text-emerald-500" />;
      case 'in_progress': return <Clock className="h-4 w-4 text-amber-500" />;
      default: return <AlertCircle className="h-4 w-4 text-rose-500" />;
    }
  };

  const activityIcons: Record<string, { icon: any; bg: string; color: string }> = {
    task: { icon: CheckSquare, bg: 'bg-blue-100', color: 'text-blue-600' },
    document: { icon: FileText, bg: 'bg-emerald-100', color: 'text-emerald-600' },
    brand: { icon: Handshake, bg: 'bg-purple-100', color: 'text-purple-600' },
    report: { icon: TrendingUp, bg: 'bg-amber-100', color: 'text-amber-600' },
  };

  if (loading) {
    return (
      <ProtectedPage page="dashboard">
        <DashboardLayout>
          <div className="flex items-center justify-center h-[calc(100vh-200px)]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto"></div>
              <p className="mt-4 text-gray-500 font-medium">Loading dashboard...</p>
            </div>
          </div>
        </DashboardLayout>
      </ProtectedPage>
    );
  }

  const stats = data?.stats;

  return (
    <ProtectedPage page="dashboard">
      <DashboardLayout>
        <div className="p-4 lg:p-8 space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">
              Welcome back, {user?.name || 'User'}! 👋
            </h1>
            <p className="text-gray-500 mt-1 text-lg">Here's what's happening today.</p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Total Tasks */}
            <div className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-lg transition-all group cursor-pointer">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2.5 bg-blue-500 rounded-xl">
                  <CheckSquare className="h-5 w-5 text-white" />
                </div>
                <ArrowRight className="h-4 w-4 text-gray-300 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
              </div>
              <p className="text-3xl font-bold text-gray-900">{stats?.totalTasks || 0}</p>
              <p className="text-sm font-semibold text-gray-900 mt-1">Total Tasks</p>
              <p className="text-xs text-gray-500 mt-0.5">{stats?.pendingTasks || 0} pending</p>
            </div>

            {/* Documents */}
            <div className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-lg transition-all group cursor-pointer">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2.5 bg-emerald-500 rounded-xl">
                  <FileText className="h-5 w-5 text-white" />
                </div>
                <ArrowRight className="h-4 w-4 text-gray-300 group-hover:text-emerald-500 group-hover:translate-x-1 transition-all" />
              </div>
              <p className="text-3xl font-bold text-gray-900">{stats?.totalDocuments || 0}</p>
              <p className="text-sm font-semibold text-gray-900 mt-1">Documents</p>
              <p className="text-xs text-gray-500 mt-0.5">All documents</p>
            </div>

            {/* Team Members */}
            <div className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-lg transition-all group cursor-pointer">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2.5 bg-violet-500 rounded-xl">
                  <Users className="h-5 w-5 text-white" />
                </div>
                <ArrowRight className="h-4 w-4 text-gray-300 group-hover:text-violet-500 group-hover:translate-x-1 transition-all" />
              </div>
              <p className="text-3xl font-bold text-gray-900">{stats?.totalTeamMembers || 0}</p>
              <p className="text-sm font-semibold text-gray-900 mt-1">Team Members</p>
              <p className="text-xs text-gray-500 mt-0.5">Active users</p>
            </div>

            {/* Active Brands */}
            <div className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-lg transition-all group cursor-pointer">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2.5 bg-orange-500 rounded-xl">
                  <Handshake className="h-5 w-5 text-white" />
                </div>
                <ArrowRight className="h-4 w-4 text-gray-300 group-hover:text-orange-500 group-hover:translate-x-1 transition-all" />
              </div>
              <p className="text-3xl font-bold text-gray-900">{stats?.activeBrands || 0}</p>
              <p className="text-sm font-semibold text-gray-900 mt-1">Active Brands</p>
              <p className="text-xs text-gray-500 mt-0.5">{stats?.totalBrands || 0} total</p>
            </div>

{/* Budget */}
<div className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-lg transition-all group cursor-pointer">
  <div className="flex items-center justify-between mb-3">
    <div className="p-2.5 bg-teal-500 rounded-xl">
      <DollarSign className="h-5 w-5 text-white" />
    </div>
    <ArrowRight className="h-4 w-4 text-gray-300 group-hover:text-teal-500 group-hover:translate-x-1 transition-all" />
  </div>
  <p className="text-3xl font-bold text-gray-900">
    ${(stats?.totalAllocated || 0).toLocaleString()}
  </p>
  <p className="text-sm font-semibold text-gray-900 mt-1">Budget</p>
  <p className="text-xs text-gray-500 mt-0.5">
    ${(stats?.totalSpent || 0).toLocaleString()} spent
  </p>
</div>

            {/* Reports */}
            <div className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-lg transition-all group cursor-pointer">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2.5 bg-pink-500 rounded-xl">
                  <BarChart3 className="h-5 w-5 text-white" />
                </div>
                <ArrowRight className="h-4 w-4 text-gray-300 group-hover:text-pink-500 group-hover:translate-x-1 transition-all" />
              </div>
              <p className="text-3xl font-bold text-gray-900">{stats?.totalReports || 0}</p>
              <p className="text-sm font-semibold text-gray-900 mt-1">Reports</p>
              <p className="text-xs text-gray-500 mt-0.5">{stats?.pendingReports || 0} pending</p>
            </div>

            {/* Polls */}
            <div className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-lg transition-all group cursor-pointer">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2.5 bg-cyan-500 rounded-xl">
                  <Megaphone className="h-5 w-5 text-white" />
                </div>
                <ArrowRight className="h-4 w-4 text-gray-300 group-hover:text-cyan-500 group-hover:translate-x-1 transition-all" />
              </div>
              <p className="text-3xl font-bold text-gray-900">{stats?.activePolls || 0}</p>
              <p className="text-sm font-semibold text-gray-900 mt-1">Active Polls</p>
              <p className="text-xs text-gray-500 mt-0.5">{stats?.totalPolls || 0} total</p>
            </div>

            {/* Ideas */}
            <div className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-lg transition-all group cursor-pointer">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2.5 bg-amber-500 rounded-xl">
                  <Lightbulb className="h-5 w-5 text-white" />
                </div>
                <ArrowRight className="h-4 w-4 text-gray-300 group-hover:text-amber-500 group-hover:translate-x-1 transition-all" />
              </div>
              <p className="text-3xl font-bold text-gray-900">{stats?.totalIdeas || 0}</p>
              <p className="text-sm font-semibold text-gray-900 mt-1">Ideas</p>
              <p className="text-xs text-gray-500 mt-0.5">Brainstorming</p>
            </div>
          </div>

          {/* Bottom Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Recent Activities - Takes 2 columns */}
            <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900">Recent Activities</h3>
              </div>
              <div className="p-6">
                {data?.activities && data.activities.length > 0 ? (
                  <div className="space-y-1">
                    {data.activities.map((activity, idx) => {
                      const iconData = activityIcons[activity.type] || activityIcons.document;
                      const Icon = iconData.icon;
                      return (
                        <div key={idx} className="flex items-start gap-4 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                          <div className={`p-2 rounded-lg ${iconData.bg} shrink-0`}>
                            <Icon className={`h-4 w-4 ${iconData.color}`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-gray-700">
                              <span className="font-semibold text-gray-900">{activity.user}</span>
                              {' '}{activity.action}{' '}
                              <span className="font-medium text-gray-900 truncate">{activity.target}</span>
                            </p>
                          </div>
                          <span className="text-xs text-gray-400 whitespace-nowrap shrink-0">{activity.time}</span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="p-3 bg-gray-100 rounded-full inline-block mb-3">
                      <TrendingUp className="h-6 w-6 text-gray-400" />
                    </div>
                    <p className="text-gray-500 font-medium">No recent activities</p>
                    <p className="text-sm text-gray-400 mt-1">Activities will appear here as your team works</p>
                  </div>
                )}
              </div>
            </div>

            {/* Pending Tasks - Takes 1 column */}
            <div className="bg-white rounded-xl border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Pending Tasks</h3>
                <span className="px-2.5 py-1 text-xs font-semibold bg-indigo-100 text-indigo-700 rounded-full">
                  {data?.pendingTasks?.length || 0}
                </span>
              </div>
              <div className="p-6">
                {data?.pendingTasks && data.pendingTasks.length > 0 ? (
                  <div className="space-y-3">
                    {data.pendingTasks.map((task) => (
                      <div key={task._id} className="p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group">
                        <div className="flex items-start gap-3">
                          <div className="shrink-0 mt-0.5">
                            {getStatusIcon(task.status)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold text-gray-900 group-hover:text-indigo-600 transition-colors">
                              {task.title}
                            </p>
                            <div className="flex items-center gap-2 mt-1.5">
                              {task.dueDate && (
                                <span className="text-xs text-gray-500 flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  {new Date(task.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                                </span>
                              )}
                            </div>
                          </div>
                          <span className={`px-2.5 py-1 text-xs font-semibold rounded-full border ${getPriorityColor(task.priority)} shrink-0`}>
                            {task.priority}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="p-3 bg-emerald-100 rounded-full inline-block mb-3">
                      <CheckSquare className="h-6 w-6 text-emerald-500" />
                    </div>
                    <p className="text-gray-500 font-medium">All caught up!</p>
                    <p className="text-sm text-gray-400 mt-1">No pending tasks right now</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedPage>
  );
}