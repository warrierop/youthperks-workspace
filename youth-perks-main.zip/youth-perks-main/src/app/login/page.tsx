'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Eye, EyeOff, Mail, Lock, ArrowRight, Sparkles } from 'lucide-react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setLoading(true);
  setError('');

  try {
    // Step 1: Login
    const res = await fetch(`${API_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();

    if (!res.ok) {
      setError(data.message || 'Invalid email or password');
      setLoading(false);
      return;
    }

    // Step 2: Store token
    localStorage.setItem('token', data.token);

    // Step 3: Build user data
    let userData: any = {
      _id: data._id,
      id: data._id,
      name: data.name,
      email: data.email,
      role: data.role,
      permissions: data.permissions || [],
      department: data.department || '',
      rank: data.rank || '',
      isActive: data.isActive !== undefined ? data.isActive : true,
    };

    // Step 4: If permissions missing, fetch from /api/users/me
    if (!data.permissions || data.permissions.length === 0) {
      try {
        const profileRes = await fetch(`${API_URL}/api/users/me`, {
          headers: {
            'Authorization': `Bearer ${data.token}`,
            'Content-Type': 'application/json',
          },
        });

        if (profileRes.ok) {
          const profileData = await profileRes.json();
          userData = {
            ...userData,
            name: profileData.name || userData.name,
            email: profileData.email || userData.email,
            permissions: profileData.permissions || [],
            department: profileData.department || '',
            rank: profileData.rank || '',
            avatar: profileData.avatar || '',
            phone: profileData.phone || '',
            bio: profileData.bio || '',
          };
        }
      } catch (err) {
        console.warn('Failed to fetch profile, using login data');
      }
    }

    // Step 5: For clients, fetch their assigned brand
    if (userData.role === 'client') {
      try {
        const clientsRes = await fetch(`${API_URL}/api/clients?accountManager=${userData._id}`, {
          headers: { 'Authorization': `Bearer ${data.token}` },
        });

        if (clientsRes.ok) {
          const clients = await clientsRes.json();
          const clientList = Array.isArray(clients) ? clients : (clients.clients || []);
          userData.assignedClientId = clientList.length > 0 ? clientList[0]._id : null;

          if (userData.assignedClientId) {
            console.log('✅ Client assigned to brand:', clientList[0].brandName);
          } else {
            console.warn('⚠️ No brand assigned to this client');
          }
        }
      } catch (err) {
        console.warn('Failed to fetch assigned client');
      }
    }

    // Step 6: Store user data
    localStorage.setItem('user', JSON.stringify(userData));
    console.log('✅ User data stored:', userData.role, userData.permissions?.length, 'permissions');

    // Step 7: Wait for storage to settle, then redirect
    await new Promise(resolve => setTimeout(resolve, 100));

    // Step 8: Redirect based on role
    if (userData.role === 'client' && userData.assignedClientId) {
      router.push(`/clients/${userData.assignedClientId}`);
    } else {
      router.push('/dashboard');
    }
  } catch (err) {
    console.error('Login error:', err);
    setError('Unable to connect. Please check your internet connection.');
  } finally {
    setLoading(false);
  }
};
  return (
    <div className="min-h-screen flex">
      {/* Left Panel - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-800 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-white rounded-full translate-x-1/2 translate-y-1/2" />
          <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-white rounded-full -translate-x-1/2 -translate-y-1/2" />
        </div>
        
        {/* Grid Pattern */}
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px)',
          backgroundSize: '30px 30px',
        }} />

        {/* Content */}
        <div className="relative flex flex-col justify-center px-16 w-full">
          <div className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-12 w-12 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <Sparkles className="h-7 w-7 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-white tracking-tight">YouthPerks</h1>
            </div>
            <p className="text-indigo-200 text-lg leading-relaxed max-w-md">
              Your all-in-one workspace for brand partnerships, team collaboration, and business growth.
            </p>
          </div>

          <div className="space-y-6">
            {[
              { title: 'Brand Management', desc: 'Track partnerships, deals, and brand relationships in one place.' },
              { title: 'Team Collaboration', desc: 'Assign tasks, share documents, and keep everyone aligned.' },
              { title: 'Smart Reporting', desc: 'Generate insights with automated reports and analytics.' },
            ].map((feature, i) => (
              <div key={i} className="flex items-start gap-4">
                <div className="h-8 w-8 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center shrink-0 mt-0.5">
                  <div className="h-2 w-2 rounded-full bg-white" />
                </div>
                <div>
                  <h3 className="text-white font-semibold text-sm">{feature.title}</h3>
                  <p className="text-indigo-200 text-sm mt-0.5">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right Panel - Login Form */}
      <div className="flex-1 flex items-center justify-center px-6 py-12 bg-white">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center gap-3 mb-10 justify-center">
            <div className="h-10 w-10 rounded-xl bg-indigo-600 flex items-center justify-center">
              <Sparkles className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">YouthPerks</h1>
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900">Welcome back</h2>
            <p className="text-gray-500 mt-2">Sign in to your workspace to continue.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email Field */}
            <div>
              <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-1.5">
                Email address
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  id="email"
                  type="email"
                  autoComplete="email"
                  required
                  className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all"
                  placeholder="you@youthperks.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <label htmlFor="password" className="block text-sm font-semibold text-gray-700 mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  required
                  className="w-full pl-10 pr-12 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent focus:bg-white transition-all"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div className="bg-red-50 border border-red-100 rounded-xl px-4 py-3 text-sm font-medium text-red-700 flex items-center gap-2">
                <div className="h-5 w-5 rounded-full bg-red-100 flex items-center justify-center shrink-0">
                  <span className="text-red-500 text-xs font-bold">!</span>
                </div>
                {error}
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white text-sm font-semibold rounded-xl shadow-sm hover:shadow-md transition-all duration-200 disabled:cursor-not-allowed"
            >
              {loading ? (
                <>
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Signing in...
                </>
              ) : (
                <>
                  Sign in
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </button>
          </form>

          {/* Footer */}
          <p className="mt-8 text-center text-xs text-gray-400">
            By signing in, you agree to our Terms of Service and Privacy Policy.
          </p>
        </div>
      </div>
    </div>
  );
}