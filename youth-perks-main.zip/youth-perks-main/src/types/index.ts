export interface User {
  email: string;
  password: string;
  name: string;
  role: string;
  rank?: string;
  avatar?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  lastLogin?: Date;
  permissions?: string[];
}

export interface Role {
  name: string;
  permissions: Permission[];
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Permission {
  module: string;
  actions: ('view' | 'create' | 'edit' | 'delete')[];
  dataVisibility?: 'all' | 'team' | 'own';
}

export interface Task {
  title: string;
  description: string;
  assignedTo: string[];
  assignedBy: string;
  dueDate?: Date;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'in_progress' | 'completed';
  type: 'file_submission' | 'form_submission' | 'simple_completion';
  formFields?: FormField[];
  submission?: TaskSubmission;
  createdAt: Date;
  updatedAt: Date;
}

export interface FormField {
  name: string;
  label: string;
  type: 'text' | 'textarea' | 'number' | 'date' | 'file';
  required: boolean;
}

export interface TaskSubmission {
  submittedBy: string;
  submittedAt: Date;
  files?: string[];
  formData?: Record<string, any>;
  notes?: string;
}

export interface Document {
  title: string;
  description: string;
  fileUrl: string;
  fileType: string;
  category: 'mou' | 'agreement' | 'budget' | 'report' | 'internal';
  uploadedBy: string;
  visibility: {
    roles: string[];
    users: string[];
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface Budget {
  name: string;
  description: string;
  allocatedAmount: number;
  spentAmount: number;
  department?: string;
  project?: string;
  campaign?: string;
  allocatedBy: string;
  startDate: Date;
  endDate: Date;
  status: 'active' | 'completed' | 'paused';
  createdAt: Date;
  updatedAt: Date;
}

export interface Brand {
  name: string;
  description: string;
  contactEmail?: string;
  contactPhone?: string;
  website?: string;
  status: 'to_pitch' | 'pitched' | 'in_progress' | 'closed' | 'failed';
  assignedTo?: string;
  notes: string;
  nextFollowUp?: Date;
  value?: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface Report {
  title: string;
  content: string;
  submittedBy: string;
  month: string;
  year: number;
  type: 'monthly' | 'quarterly' | 'annual';
  status: 'draft' | 'submitted' | 'reviewed';
  reviewedBy?: string;
  reviewedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface Announcement {
  title: string;
  content: string;
  postedBy: string;
  visibility: {
    roles: string[];
    users: string[];
  };
  priority: 'low' | 'medium' | 'high';
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Poll {
  question: string;
  options: string[];
  targetRoles: string[];
  targetUsers?: string[];
  createdBy: string;
  isActive: boolean;
  endDate?: Date;
  responses: PollResponse[];
  createdAt: Date;
  updatedAt: Date;
}

export interface PollResponse {
  userId: string;
  selectedOption: number;
  submittedAt: Date;
}

export interface Notification {
  title: string;
  message: string;
  type: 'task' | 'deadline' | 'reminder' | 'brand' | 'announcement';
  targetUsers: string[];
  targetRoles?: string[];
  readBy: string[];
  createdBy?: string;
  createdAt: Date;
}

export interface Idea {
  title: string;
  description: string;
  postedBy: string;
  status: 'open' | 'in_progress' | 'implemented';
  comments: IdeaComment[];
  reactions: IdeaReaction[];
  createdAt: Date;
  updatedAt: Date;
}

export interface IdeaComment {
  userId: string;
  content: string;
  createdAt: Date;
}

export interface IdeaReaction {
  userId: string;
  type: 'like' | 'love' | 'laugh' | 'wow' | 'sad' | 'angry';
  createdAt: Date;
}
