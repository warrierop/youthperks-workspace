import { DefaultSession } from 'next-auth';

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      role: string;
      rank?: string;
      permissions?: string[];
    } & DefaultSession['user'];
  }

  interface User {
    role: string;
    rank?: string;
    permissions?: string[];
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    role: string;
    rank?: string;
    permissions?: string[];
  }
}
