'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';

interface Permission {
    page: string;
    canView: boolean;
    canCreate: boolean;
    canEdit: boolean;
    canDelete: boolean;
}

interface User {
    _id?: string;
    id?: string;
    name?: string;
    email?: string;
    role: string;
    permissions?: Permission[];
    department?: string;
    rank?: string;
    isActive?: boolean;
    phone?: string;
    avatar?: string;
    bio?: string;
    assignedClientId?: string;
}

export function useAuth() {
    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);
    const router = useRouter();
    const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

    useEffect(() => {
        loadUser();
    }, []);

    const loadUser = async () => {
        const token = localStorage.getItem('token');
        const userData = localStorage.getItem('user');

        if (!token) {
            setLoading(false);
            return;
        }

        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            if (payload.exp && payload.exp * 1000 < Date.now()) {
                handleLogout();
                return;
            }

            if (userData) {
                const parsed = JSON.parse(userData);

                if (!parsed.permissions || parsed.permissions.length === 0) {
                    console.warn('Permissions missing, fetching from API...');
                    await refreshUserData(token);
                } else {
                    setUser(parsed);
                }
            } else {
                await refreshUserData(token);
            }
        } catch (error) {
            console.error('Error loading user:', error);
            handleLogout();
        } finally {
            setLoading(false);
        }
    };

    const refreshUserData = async (token: string) => {
        try {
            const res = await fetch(`${API_URL}/api/users/me`, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                }
            });

            if (res.ok) {
                const userData = await res.json();
                
                // ✅ For clients, fetch their assigned client
                if (userData.role === 'client') {
                    try {
                        const clientsRes = await fetch(`${API_URL}/api/clients?accountManager=${userData._id}`, {
                            headers: { 'Authorization': `Bearer ${token}` }
                        });
                        if (clientsRes.ok) {
                            const clients = await clientsRes.json();
                            const assignedClientId = Array.isArray(clients) && clients.length > 0 ? clients[0]._id : null;
                            userData.assignedClientId = assignedClientId;
                        }
                    } catch (e) {
                        console.error('Error fetching assigned client:', e);
                    }
                }
                
                localStorage.setItem('user', JSON.stringify(userData));
                setUser(userData);
            } else {
                handleLogout();
            }
        } catch (error) {
            console.error('Error refreshing user data:', error);
            handleLogout();
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        localStorage.removeItem('assignedClientId');
        setUser(null);
        router.push('/login');
    };

    const hasPermission = useCallback((page: string, action: 'canView' | 'canCreate' | 'canEdit' | 'canDelete' = 'canView') => {
        if (!user) return false;
        if (user.role === 'super_admin' || user.role === 'admin') return true;
        if (user.permissions && Array.isArray(user.permissions)) {
            const perm = user.permissions.find((p: Permission) => p.page === page);
            return perm?.[action] === true;
        }
        return false;
    }, [user]);

    const canView = useCallback((page: string) => hasPermission(page, 'canView'), [hasPermission]);
    const canCreate = useCallback((page: string) => hasPermission(page, 'canCreate'), [hasPermission]);
    const canEdit = useCallback((page: string) => hasPermission(page, 'canEdit'), [hasPermission]);
    const canDelete = useCallback((page: string) => hasPermission(page, 'canDelete'), [hasPermission]);

    // ✅ Helper flags
    const isClient = user?.role === 'client';
    const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';
    const isStaff = user?.role?.startsWith('staff_');
    const isSupport = user?.role === 'support';
    const isExecutive = user?.role === 'executive';

    return {
        user,
        loading,
        logout: handleLogout,
        hasPermission,
        canView,
        canCreate,
        canEdit,
        canDelete,
        loadUser,
        refreshUserData,
        isClient,
        isAdmin,
        isStaff,
        isSupport,
        isExecutive,
    };
}